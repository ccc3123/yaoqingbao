import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/data/drug_item.dart';
import 'package:yaoqingbao/data/medicine.dart';
import 'package:yaoqingbao/util/geo_utils.dart';

/// 核心纯函数与数据模型的单元测试。
///
/// 重点验证：坐标纠偏算法的数学正确性，以及模型层对服务端脏数据的健壮性。
void main() {
  group('GeoUtils 坐标纠偏', () {
    test('境外坐标原样返回，不做纠偏', () {
      final r = GeoUtils.wgs84ToGcj02(37.7749, -122.4194); // 旧金山
      expect(r[0], 37.7749);
      expect(r[1], -122.4194);
    });

    test('国内坐标纠偏后位移在 100~1500 米之间', () {
      const lat = 39.9042;
      const lng = 116.4074; // 北京
      final r = GeoUtils.wgs84ToGcj02(lat, lng);
      final d = GeoUtils.distanceMeter(lat, lng, r[0], r[1]);
      expect(d, greaterThan(100));
      expect(d, lessThan(1500));
    });

    test('WGS84 → GCJ02 → WGS84 往返误差小于 1 米', () {
      const lat = 31.2304;
      const lng = 121.4737; // 上海
      final g = GeoUtils.wgs84ToGcj02(lat, lng);
      final back = GeoUtils.gcj02ToWgs84(g[0], g[1]);
      expect(GeoUtils.distanceMeter(lat, lng, back[0], back[1]), lessThan(1.0));
    });

    test('距离计算与已知值一致（北京站→天安门约 2.4km）', () {
      final d = GeoUtils.distanceMeter(39.9027, 116.4253, 39.9087, 116.3975);
      expect(d, greaterThan(2200));
      expect(d, lessThan(2800));
    });

    test('同一坐标距离为 0', () {
      expect(GeoUtils.distanceMeter(39.9, 116.4, 39.9, 116.4), lessThan(0.001));
    });

    test('距离格式化边界', () {
      expect(GeoUtils.formatDistance(0), '--');
      expect(GeoUtils.formatDistance(-5), '--');
      expect(GeoUtils.formatDistance(999), '999m');
      expect(GeoUtils.formatDistance(1000), '1.0km');
      expect(GeoUtils.formatDistance(12345), '12.3km');
    });
  });

  group('DrugItem 模型健壮性', () {
    test('正常 JSON 往返一致', () {
      final item = DrugItem(
        medicineId: 'a1',
        medicineName: '阿莫西林',
        produceTime: '2025-01-01',
        addTime: '2025-02-01',
        countDown: 120,
        expDays: 365,
        recycled: 1,
        source: 'scan',
      );
      final back = DrugItem.fromJson(item.toJson());
      expect(back.medicineId, 'a1');
      expect(back.medicineName, '阿莫西林');
      expect(back.countDown, 120);
      expect(back.recycled, 1);
      expect(back.source, 'scan');
    });

    test('空 Map 走默认值，不抛错', () {
      final item = DrugItem.fromJson(<String, dynamic>{});
      expect(item.medicineId, '');
      expect(item.medicineName, '');
      expect(item.countDown, 999);
      expect(item.expDays, 0);
    });

    test('字段值为 null 不抛错', () {
      final item = DrugItem.fromJson(<String, dynamic>{
        'medicineId': null,
        'medicineName': null,
        'countDown': null,
        'expDays': null,
        'recycled': null,
      });
      expect(item.medicineName, '');
      expect(item.countDown, 999);
      expect(item.recycled, 0);
    });

    test('【脏数据】数值字段被传成字符串时不崩溃，回退默认值', () {
      // 后端 MySQL 字段变更或第三方接口返回 string 时会出现该情况
      final item = DrugItem.fromJson(<String, dynamic>{
        'medicineId': 12345,
        'countDown': '365天',
        'expDays': '730',
        'recycled': '1',
      });
      expect(item.countDown, isA<int>());
      expect(item.expDays, isA<int>());
      expect(item.recycled, isA<int>());
    });

    test('copyWith 保留未指定字段', () {
      final item = DrugItem(medicineName: '布洛芬', countDown: 30);
      final copied = item.copyWith(recycled: 1);
      expect(copied.medicineName, '布洛芬');
      expect(copied.countDown, 30);
      expect(copied.recycled, 1);
    });
  });

  group('Medicine 模型健壮性', () {
    test('空 Map 走默认值', () {
      final m = Medicine.fromJson(<String, dynamic>{});
      expect(m.drugName, '');
      expect(m.exp, 0);
      expect(m.isExpired, false);
    });

    test('【脏数据】数值字段被传成字符串时不崩溃', () {
      final m = Medicine.fromJson(<String, dynamic>{
        'drugName': '维生素C',
        'exp': '24个月',
        'price': 9.9,
      });
      expect(m.drugName, '维生素C');
      expect(m.exp, isA<int>());
    });

    test('【脏数据】非 String 字段被传成数字/对象时不崩溃', () {
      final m = Medicine.fromJson(<String, dynamic>{
        'drugName': 123,
        'manu': {'name': 'xx制药'},
        'ggxh': 0.5,
      });
      expect(m.drugName, isA<String>());
      expect(m.manu, isA<String>());
      expect(m.ggxh, isA<String>());
    });
  });
}
