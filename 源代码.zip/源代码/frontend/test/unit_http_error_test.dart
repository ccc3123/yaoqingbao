import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/util/http_utils.dart';

/// 网络错误分类回归测试：
/// 确保只有「真没网/连不上」才提示检查网络，服务端故障有独立文案
void main() {
  RequestOptions opts(String path) => RequestOptions(path: path);

  DioException dioErr(DioExceptionType type, {int? status}) => DioException(
        requestOptions: opts('/test'),
        type: type,
        response: status == null
            ? null
            : Response(requestOptions: opts('/test'), statusCode: status),
      );

  group('HttpUtils.describeError 错误分类', () {
    test('连接超时 → 提示连接超时，不误导用户检查网络', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.connectionTimeout));
      expect(msg, contains('超时'));
      expect(msg, isNot(contains('检查网络')));
    });

    test('接收超时 → 提示连接超时', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.receiveTimeout));
      expect(msg, contains('超时'));
    });

    test('连接失败（无网/端口不通）→ 明确提示检查网络', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.connectionError));
      expect(msg, contains('检查网络'));
    });

    test('服务端 500 → 提示服务器故障，不提示检查网络', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.badResponse, status: 500));
      expect(msg, contains('500'));
      expect(msg, contains('服务器'));
      expect(msg, isNot(contains('检查网络')));
    });

    test('服务端 404 → 提示接口不存在，不提示检查网络', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.badResponse, status: 404));
      expect(msg, contains('404'));
      expect(msg, isNot(contains('检查网络')));
    });

    test('请求取消 → 提示已取消', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.cancel));
      expect(msg, contains('取消'));
    });

    test('未知异常（常见于无网）→ 提示检查网络', () {
      final msg = HttpUtils.describeError(dioErr(DioExceptionType.unknown));
      expect(msg, contains('检查网络'));
    });

    test('非 Dio 异常 → 通用兜底文案，不崩溃', () {
      expect(HttpUtils.describeError(StateError('x')), isNotEmpty);
      expect(HttpUtils.describeError('随便什么'), isNotEmpty);
    });
  });
}
