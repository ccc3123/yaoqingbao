import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yaoqingbao/pages/yaoxia_page.dart';
import 'package:yaoqingbao/util/http_utils.dart';

import 'helpers/mock_adapter.dart';

const _prefKey = 'yaoqingbao_drug_list';

/// 预置数据：3 条正常药品记录
List<Map<String, dynamic>> sampleItems([int n = 3]) => List.generate(
      n,
      (i) => {
        'medicineId': 'id$i',
        'medicineName': '测试药品$i',
        'produceTime': '2025-01-0${i + 1}',
        'addTime': '2025-02-01',
        'countDown': 30 + i,
        'expDays': 365,
        'recycled': 0,
        'source': 'local',
      },
    );

/// 包一层 Scaffold：真实 App 中页面挂在 HomePage 的 Scaffold 下，
/// _snackbar 依赖祖先 Scaffold 才能展示，测试需还原这一层级。
Widget buildApp() => const MaterialApp(home: Scaffold(body: YaoXiaPage()));

/// 把 MockAdapter 装上，并记录每个请求路径的调用次数
Map<String, int> attachMock(
  Future<ResponseBody> Function(RequestOptions options) handler,
) {
  final calls = <String, int>{};
  HttpUtils().dio.httpClientAdapter = MockAdapter((options) {
    final key = '${options.method}:${options.path}';
    calls[key] = (calls[key] ?? 0) + 1;
    return handler(options);
  });
  return calls;
}

/// 默认后端：列表为空，删除成功
Future<ResponseBody> defaultBackend(RequestOptions options) async {
  if (options.path.contains('/medbox/list')) {
    return jsonBody(okEnvelope([]));
  }
  return jsonBody(okEnvelope(null));
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    HttpUtils().dio.httpClientAdapter = MockAdapter(defaultBackend);
  });

  group('药匣页 · 空数据与脏数据', () {
    testWidgets('本地无数据时展示空状态，不崩溃', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));

      expect(find.text('药箱为空'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });

    testWidgets('服务端返回含类型错误的记录时不崩溃', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode([
          {'medicineId': 12345, 'medicineName': '混乱数据', 'countDown': '三十天', 'expDays': null},
        ]),
      });
      // 服务端也返回一条脏数据，模拟后端字段漂移
      HttpUtils().dio.httpClientAdapter = MockAdapter((options) async {
        if (options.path.contains('/medbox/list')) {
          return jsonBody(okEnvelope([
            {'medicineId': 'srv1', 'medicineName': 8888, 'countDown': '未知', 'expDays': '两年'},
          ]));
        }
        return defaultBackend(options);
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));

      expect(tester.takeException(), isNull);
      expect(find.text('药箱为空'), findsNothing);
    });

    testWidgets('空药箱点击管理给出 toast 提示，不进入多选态', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));

      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 300));

      expect(find.text('药箱为空，暂无可管理的记录'), findsOneWidget);
      expect(find.text('全选'), findsNothing);
    });
  });

  group('药匣页 · 批量删除', () {
    testWidgets('全选后批量删除，服务端成功则列表清空', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      final calls = attachMock(defaultBackend);

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      expect(find.text('测试药品0'), findsOneWidget);

      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));
      expect(find.text('已选 3 条'), findsOneWidget);

      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      expect(find.text('确认删除已选中的 3 条药品记录吗？\n删除后将从药箱和云端同步移除，且不可恢复。'),
          findsOneWidget);

      await tester.tap(find.text('删除 3 条'));
      await tester.pumpAndSettle();

      expect(calls['DELETE:/medbox/deleteBatch'], 1);
      expect(find.text('已删除 3 条记录'), findsOneWidget);
      expect(find.text('测试药品0'), findsNothing);
      expect(tester.takeException(), isNull);
    });

    testWidgets('单条侧滑删除走 /medbox/delete 接口', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems(1)),
      });
      final calls = attachMock(defaultBackend);

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));

      // 从右向左滑动触发 endToStart 删除
      expect(find.byType(Dismissible), findsWidgets);
      await tester.dragFrom(
        tester.getCenter(find.byType(Dismissible).first),
        const Offset(-400, 0),
      );
      await tester.pumpAndSettle(const Duration(milliseconds: 100));
      // 侧滑同样要求二次确认
      expect(find.text('删除这条记录'), findsOneWidget);
      await tester.tap(find.text('确认删除').last);
      await tester.pumpAndSettle();

      expect(calls['DELETE:/medbox/delete'], 1);
      expect(find.text('测试药品0'), findsNothing);
      expect(tester.takeException(), isNull);
    });

    testWidgets('服务端返回 500 时记录保留并提示失败', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      attachMock((options) async {
        if (options.path.contains('deleteBatch')) {
          return jsonBody(errEnvelope(500, '删除失败，请稍后重试'));
        }
        return defaultBackend(options);
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('删除 3 条'));
      await tester.pumpAndSettle();

      expect(find.text('删除失败，请稍后重试'), findsOneWidget);
      // 记录应仍然存在
      expect(find.text('测试药品0'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });

    testWidgets('服务端返回 404 时按本地删除处理', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      attachMock((options) async {
        if (options.path.contains('deleteBatch')) {
          return jsonBody(errEnvelope(404, '该记录不存在或已删除'));
        }
        return defaultBackend(options);
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('删除 3 条'));
      await tester.pumpAndSettle();

      expect(find.text('已从药箱移除（云端无对应记录）'), findsOneWidget);
      expect(find.text('测试药品0'), findsNothing);
    });

    testWidgets('断网时给出明确失败提示，记录保留', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      attachMock((options) async {
        if (options.path.contains('deleteBatch')) {
          return networkError(options);
        }
        return defaultBackend(options);
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('删除 3 条'));
      await tester.pumpAndSettle();

      // V3：删除失败文案改为精确分类（unknown 类型 → 网络连接不可用）
      expect(find.text('删除失败：网络连接不可用，请检查网络'), findsOneWidget);
      expect(find.text('测试药品0'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });

    testWidgets('取消确认弹窗不发起任何请求', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      final calls = attachMock(defaultBackend);

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      // 弹窗里有两个「取消」，点第一个
      await tester.tap(find.text('取消').first);
      await tester.pumpAndSettle();

      expect(calls['DELETE:/medbox/deleteBatch'], isNull);
      expect(find.text('测试药品0'), findsOneWidget);
    });
  });

  group('药匣页 · 交互健壮性', () {
    testWidgets('快速重复点击删除只发起一次请求', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      // 让删除请求慢一点，放大并发窗口
      final calls = attachMock((options) async {
        if (options.path.contains('deleteBatch')) {
          await Future<void>.delayed(const Duration(milliseconds: 500));
          return jsonBody(okEnvelope(null));
        }
        return defaultBackend(options);
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));

      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('删除 3 条'));
      // 立刻再点两次（此时第一次请求在飞行中）
      await tester.pump(const Duration(milliseconds: 50));
      if (find.text('批量删除').evaluate().isNotEmpty) {
        await tester.tap(find.text('批量删除').first);
        await tester.pump(const Duration(milliseconds: 50));
      }
      await tester.pumpAndSettle();

      expect(calls['DELETE:/medbox/deleteBatch'], lessThanOrEqualTo(1));
      expect(tester.takeException(), isNull);
    });

    testWidgets('横竖屏切换后布局重建无异常', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      await tester.binding.setSurfaceSize(const Size(390, 844));
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      expect(find.text('测试药品0'), findsOneWidget);

      // 旋转到横屏
      await tester.binding.setSurfaceSize(const Size(844, 390));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);

      // 再转回来，并进入多选模式后旋转
      await tester.binding.setSurfaceSize(const Size(390, 844));
      await tester.pumpAndSettle();
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.binding.setSurfaceSize(const Size(844, 390));
      await tester.pumpAndSettle();

      expect(tester.takeException(), isNull);
      await tester.binding.setSurfaceSize(null);
    });

    testWidgets('页面销毁后异步回调不报错（前后台切换场景）', (tester) async {
      SharedPreferences.setMockInitialValues(<String, Object>{
        _prefKey: jsonEncode(sampleItems()),
      });
      attachMock((options) async {
        if (options.path.contains('deleteBatch')) {
          await Future<void>.delayed(const Duration(seconds: 1));
          return jsonBody(okEnvelope(null));
        }
        return defaultBackend(options);
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 600));
      await tester.tap(find.text('管理'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('全选'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('批量删除'));
      await tester.pump(const Duration(milliseconds: 200));
      await tester.tap(find.text('删除 3 条'));
      await tester.pump(const Duration(milliseconds: 100));

      // 删除请求在飞行中时把整个页面移除（模拟用户切走/页面出栈）
      await tester.pumpWidget(const MaterialApp(home: Scaffold(body: SizedBox())));
      await tester.pump(const Duration(seconds: 2));

      expect(tester.takeException(), isNull);
    });
  });
}
