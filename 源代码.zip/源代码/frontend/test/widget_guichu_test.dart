import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:yaoqingbao/pages/guichu_page.dart';
import 'package:yaoqingbao/util/http_utils.dart';

import 'helpers/mock_adapter.dart';

const MethodChannel _geoChannel = MethodChannel('flutter.baseflow.com/geolocator');

/// LocationPermission 枚举在 native 侧映射：[denied, deniedForever, whileInUse, always]
const int _denied = 0;
const int _deniedForever = 1;
const int _whileInUse = 2;

Map<String, dynamic> fakePosition() => {
      'latitude': 39.9042,
      'longitude': 116.4074,
      'timestamp': 1700000000000,
      'accuracy': 20.0,
      'altitude': 43.0,
      'heading': 0.0,
      'speed': 0.0,
      'speed_accuracy': 1.0,
      'altitude_accuracy': 1.5,
    };

void mockGeo({
  bool serviceEnabled = true,
  int permission = _whileInUse,
  bool throwMissingPlugin = false,
}) {
  TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
      .setMockMethodCallHandler(_geoChannel, (call) async {
    if (throwMissingPlugin) throw MissingPluginException('no impl');
    switch (call.method) {
      case 'isLocationServiceEnabled':
        return serviceEnabled;
      case 'checkPermission':
        return permission;
      case 'requestPermission':
        return permission;
      case 'getCurrentPosition':
        if (!serviceEnabled || permission == _denied) {
          throw PlatformException(code: 'PERMISSION_DENIED', message: 'denied');
        }
        return fakePosition();
      case 'getLastKnownPosition':
        return null;
      case 'getLocationAccuracy':
        return 3;
      default:
        return null;
    }
  });
}

Widget buildApp() => const MaterialApp(home: Scaffold(body: GuiChuPage()));

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_geoChannel, null);
  });

  group('归处页 · 定位权限分支', () {
    testWidgets('定位服务未开启时给出明确引导文案', (tester) async {
      mockGeo(serviceEnabled: false);
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 500));

      expect(find.textContaining('请开启手机定位服务'), findsWidgets);
      expect(tester.takeException(), isNull);
    });

    testWidgets('权限被拒绝且二次请求仍被拒时降级到城市选择', (tester) async {
      mockGeo(serviceEnabled: true, permission: _denied);
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 500));

      expect(find.textContaining('定位权限被拒绝'), findsWidgets);
      expect(tester.takeException(), isNull);
    });

    testWidgets('权限永久拒绝时提示到系统设置开启', (tester) async {
      mockGeo(serviceEnabled: true, permission: _deniedForever);
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 500));

      expect(find.textContaining('定位权限已永久拒绝'), findsWidgets);
      expect(tester.takeException(), isNull);
    });

    testWidgets('原生插件缺失（MissingPluginException）时不崩溃', (tester) async {
      mockGeo(throwMissingPlugin: true);
      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 800));

      // 页面不应抛到框架层
      expect(tester.takeException(), isNull);
    });
  });

  group('归处页 · 附近点位数据', () {
    testWidgets('服务端超时不阻塞界面，且无崩溃', (tester) async {
      mockGeo();
      HttpUtils().dio.httpClientAdapter = MockAdapter((options) => timeoutError(options));

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 1500));

      expect(tester.takeException(), isNull);
    });

    testWidgets('服务端返回缺字段的脏数据时不崩溃', (tester) async {
      mockGeo();
      HttpUtils().dio.httpClientAdapter = MockAdapter((options) async {
        if (options.path.contains('/position')) {
          // data 是 JSON 字符串（后端包一层），内部缺 title/location
          return jsonBody({
            'code': 200,
            'msg': 'ok',
            'data': '[]',
          });
        }
        return jsonBody(okEnvelope(null));
      });

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 1200));

      expect(tester.takeException(), isNull);
    });

    testWidgets('后端返回非法 JSON（HTML 错误页）时不崩溃', (tester) async {
      mockGeo();
      HttpUtils().dio.httpClientAdapter = MockAdapter((options) async => garbageBody(status: 502));

      await tester.pumpWidget(buildApp());
      await tester.pump(const Duration(milliseconds: 1200));

      expect(tester.takeException(), isNull);
    });
  });
}
