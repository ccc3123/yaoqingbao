import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yaoqingbao/main.dart';
import 'package:yaoqingbao/routes/home_page.dart';
import 'package:yaoqingbao/util/http_utils.dart';
import 'package:yaoqingbao/util/drug_db.dart';

import 'helpers/mock_adapter.dart';

const MethodChannel _geoChannel = MethodChannel('flutter.baseflow.com/geolocator');

/// 全应用冒烟：启动页 → 主页 → 三 tab 切换 → 旋屏 → 页面退出
///
/// 目标是把用户真实会走的路径全部跑一遍，任何一处的异常都会被
/// tester.takeException() 捕获，而不是等到真机才发现。
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    // 离线条码库 29MB，只在真机才有意义。
    // 测试环境加载它会把整轮测试从 1 分钟拖到十几分钟，这里直接关掉，
    // 让 DrugDb 走「未命中」分支，验证降级链仍然可用。
    DrugDb.enabled = false;
  });

  setUp(() {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    HttpUtils().dio.httpClientAdapter = MockAdapter((options) async {
      if (options.path.contains('/position')) {
        return jsonBody({'code': 200, 'msg': 'ok', 'data': '[]'});
      }
      if (options.path.contains('/medbox/list')) {
        return jsonBody(okEnvelope([]));
      }
      return jsonBody(okEnvelope(null));
    });
    // 定位一律返回"权限被拒"，顺带验证主页首屏在定位不可用时的表现
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_geoChannel, (call) async {
      switch (call.method) {
        case 'isLocationServiceEnabled':
          return false;
        case 'checkPermission':
          return 0;
        case 'requestPermission':
          return 0;
        case 'getLastKnownPosition':
          return null;
        default:
          return null;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(_geoChannel, null);
  });

  /// 启动页 2 秒后跳转主页。主页带常驻循环动效，pumpAndSettle 永远收敛不了，
  /// 所以这里用固定帧推进代替（这也是为什么不能用 pumpAndSettle 的原因）。
  Future<void> enterHome(WidgetTester tester) async {
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(seconds: 2));
    await tester.pump(const Duration(milliseconds: 500));
    await tester.pump(const Duration(milliseconds: 500));
  }

  testWidgets('应用启动：启动页展示品牌，随后自动进入主页', (tester) async {
    await tester.pumpWidget(const YaoQingBaoApp());
    // 启动页阶段
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('药清宝'), findsOneWidget);
    expect(find.text('零账户 · 零交易 · 纯公益'), findsOneWidget);

    // 启动页 2 秒后跳转主页
    await enterHome(tester);

    // 已进入主页（"寻 源" 同时出现在标题栏和底部导航，故用 findsWidgets）
    expect(find.byType(HomePage), findsOneWidget);
    expect(find.text('寻 源'), findsWidgets);
    expect(tester.takeException(), isNull);
  });

  testWidgets('主页三节点切换不崩溃', (tester) async {
    await tester.pumpWidget(const YaoQingBaoApp());
    await enterHome(tester);

    expect(find.byType(HomePage), findsOneWidget);
    final homeState = tester.state<HomePageState>(find.byType(HomePage));

    for (final tab in [1, 2, 0]) {
      homeState.switchToTab(tab);
      await tester.pump(const Duration(milliseconds: 400));
      await tester.pump(const Duration(milliseconds: 400));
      expect(tester.takeException(), isNull);
    }
  });

  testWidgets('主页旋转横竖屏后重建无异常', (tester) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    await tester.pumpWidget(const YaoQingBaoApp());
    await enterHome(tester);

    await tester.binding.setSurfaceSize(const Size(844, 390));
    await tester.pump(const Duration(milliseconds: 500));
    expect(tester.takeException(), isNull);

    await tester.binding.setSurfaceSize(const Size(390, 844));
    await tester.pump(const Duration(milliseconds: 500));
    expect(tester.takeException(), isNull);
    await tester.binding.setSurfaceSize(null);
  });

  testWidgets('应用被移出 widget 树（切后台/退出）后异步任务不报错', (tester) async {
    await tester.pumpWidget(const YaoQingBaoApp());
    await enterHome(tester);

    // 页面还在加载服务端数据时直接卸载整棵树
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 2));
    await tester.pump(const Duration(seconds: 2));

    expect(tester.takeException(), isNull);
  });
}
