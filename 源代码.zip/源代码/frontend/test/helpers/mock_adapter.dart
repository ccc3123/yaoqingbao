import 'dart:convert';
import 'dart:typed_data';

import 'package:dio/dio.dart';

/// 用于测试的 Dio 适配器：把请求拦在 HTTP 层，模拟各种后端行为。
///
/// 覆盖场景：正常 200、业务失败码（404/500）、连接超时、网络不可达、非法 JSON。
class MockAdapter implements HttpClientAdapter {
  MockAdapter(this._handler);

  final Future<ResponseBody> Function(RequestOptions options) _handler;

  @override
  Future<ResponseBody> fetch(
    RequestOptions options,
    Stream<Uint8List>? requestStream,
    Future<void>? cancelFuture,
  ) =>
      _handler(options);

  @override
  void close({bool force = false}) {}
}

/// 构造一个 JSON 响应体
ResponseBody jsonBody(Object data, {int status = 200}) {
  final bytes = utf8.encode(jsonEncode(data));
  return ResponseBody(
    Stream<Uint8List>.value(Uint8List.fromList(bytes)),
    status,
    headers: const {
      Headers.contentTypeHeader: [Headers.jsonContentType],
    },
  );
}

/// 构造非法 JSON 响应（模拟后端返回 HTML 错误页）
ResponseBody garbageBody({int status = 200}) {
  final bytes = utf8.encode('<html><body>502 Bad Gateway</body></html>');
  return ResponseBody(
    Stream<Uint8List>.value(Uint8List.fromList(bytes)),
    status,
    headers: const {
      Headers.contentTypeHeader: ['text/html; charset=utf-8'],
    },
  );
}

/// 模拟连接超时：Dio 收到的异常类型必须为 connectionTimeout，降级文案依赖它
Never timeoutError(RequestOptions options) {
  throw DioException(
    requestOptions: options,
    type: DioExceptionType.connectionTimeout,
    message: 'simulated connect timeout',
  );
}

/// 模拟网络不可达（DNS 失败 / 飞行模式）
Never networkError(RequestOptions options) {
  throw DioException(
    requestOptions: options,
    type: DioExceptionType.unknown,
    message: 'simulated network unreachable',
  );
}

/// 后端标准返回：{"code":200,"msg":"ok","data":...}
Map<String, dynamic> okEnvelope([dynamic data]) =>
    {'code': 200, 'msg': 'ok', 'data': data};

Map<String, dynamic> errEnvelope(int code, String msg) =>
    {'code': code, 'msg': msg, 'data': null};
