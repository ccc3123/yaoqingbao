import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:yaoqingbao/data/drug_item.dart';
import 'package:yaoqingbao/util/agent_scheduler.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('AgentScheduler 主动巡检', () {
    tearDown(() {
      AgentScheduler.instance.stop();
    });

    test('空药箱静默，不产生警报', () async {
      SharedPreferences.setMockInitialValues({});
      final scheduler = AgentScheduler.instance;
      AgentAlert? alert;
      scheduler.start(onAlert: (a) => alert = a);
      await scheduler.checkNow();
      expect(alert, isNull);
      expect(scheduler.unreadCount, 0);
    });

    test('存在过期药时产生警报并置未读', () async {
      final item = DrugItem(medicineId: '1', medicineName: '过期药', countDown: -3).toJson();
      SharedPreferences.setMockInitialValues({
        'yaoqingbao_drug_list': jsonEncode([item]),
      });
      final scheduler = AgentScheduler.instance;
      AgentAlert? alert;
      scheduler.start(onAlert: (a) => alert = a);
      await scheduler.checkNow();
      expect(alert, isNotNull);
      expect(alert!.snapshot.hasAlert, isTrue);
      expect(scheduler.unreadCount, 1);

      scheduler.markRead();
      expect(scheduler.unreadCount, 0);
    });

    test('24h 节流：刚报过警则不再重复上报', () async {
      final item = DrugItem(medicineId: '1', medicineName: '过期药', countDown: -3).toJson();
      SharedPreferences.setMockInitialValues({
        'yaoqingbao_drug_list': jsonEncode([item]),
        'yaoqingbao_last_alert_ts': DateTime.now().millisecondsSinceEpoch,
      });
      final scheduler = AgentScheduler.instance;
      AgentAlert? alert;
      scheduler.start(onAlert: (a) => alert = a);
      await scheduler.checkNow();
      expect(alert, isNull); // 节流拦截，不上报
    });

    test('脏数据（非法 JSON）静默不崩', () async {
      SharedPreferences.setMockInitialValues({
        'yaoqingbao_drug_list': 'not-a-json{{{',
      });
      final scheduler = AgentScheduler.instance;
      AgentAlert? alert;
      scheduler.start(onAlert: (a) => alert = a);
      await scheduler.checkNow();
      expect(alert, isNull);
      expect(scheduler.unreadCount, 0);
    });
  });
}
