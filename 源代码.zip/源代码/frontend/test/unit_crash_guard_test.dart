import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/util/crash_guard.dart';

/// 启动崩溃问题的回归防护：确保全局异常兜底确实被安装，
/// 否则任何未捕获异常仍会导致静默闪退且无日志。
void main() {
  testWidgets('install 幂等且不抛异常', (tester) async {
    expect(() => CrashGuard.install(), returnsNormally);
    expect(() => CrashGuard.install(), returnsNormally);
  });

  testWidgets('install 后 ErrorWidget.builder 被替换为友好卡片', (tester) async {
    CrashGuard.install();
    final widget = ErrorWidget.builder(
      FlutterErrorDetails(exception: Exception('boom')),
    );

    await tester.pumpWidget(widget);
    await tester.pump();

    expect(tester.takeException(), isNull);
    expect(find.text('这块内容暂时没能显示出来'), findsOneWidget);
  });

  testWidgets('install 后 PlatformDispatcher.onError 吞掉异常并返回 true', (_) async {
    CrashGuard.install();
    final handled = PlatformDispatcher.instance.onError?.call(
      Exception('async boom'),
      StackTrace.current,
    );
    expect(handled, isTrue);
  });

  test('reportZoneError 不抛异常（日志旁路不能二次崩溃）', () {
    expect(() => CrashGuard.reportZoneError(Exception('x'), StackTrace.current),
        returnsNormally);
  });
}
