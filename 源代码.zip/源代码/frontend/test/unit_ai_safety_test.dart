import 'dart:convert';
import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/data/drug_item.dart';
import 'package:yaoqingbao/data/medicine.dart';
import 'package:yaoqingbao/util/expiry_rule.dart';
import 'package:yaoqingbao/util/ingredient.dart';
import 'package:yaoqingbao/util/zhipu_service.dart';
import 'package:yaoqingbao/widgets/medicine_safety.dart';
import 'package:yaoqingbao/widgets/source_badge.dart';

import 'helpers/mock_adapter.dart';

void main() {
  // ------------------------------------------------------------------ 有效期分级

  group('ExpiryRule 常规五级', () {
    test('边界值落在正确等级', () {
      expect(ExpiryRule.judge(remainDays: 200).level, ExpiryLevel.safe);
      expect(ExpiryRule.judge(remainDays: 91).level, ExpiryLevel.safe);
      expect(ExpiryRule.judge(remainDays: 90).level, ExpiryLevel.notice);
      expect(ExpiryRule.judge(remainDays: 31).level, ExpiryLevel.notice);
      expect(ExpiryRule.judge(remainDays: 30).level, ExpiryLevel.warn);
      expect(ExpiryRule.judge(remainDays: 8).level, ExpiryLevel.warn);
      expect(ExpiryRule.judge(remainDays: 7).level, ExpiryLevel.danger);
      expect(ExpiryRule.judge(remainDays: 1).level, ExpiryLevel.danger);
      expect(ExpiryRule.judge(remainDays: 0).level, ExpiryLevel.expired);
      expect(ExpiryRule.judge(remainDays: -5).level, ExpiryLevel.expired);
    });

    test('已过期文案带天数，且标记为紧急', () {
      final v = ExpiryRule.judge(remainDays: -3);
      expect(v.label, contains('3'));
      expect(v.isExpired, isTrue);
      expect(v.isUrgent, isTrue);
    });
  });

  group('ExpiryRule 差异化阈值', () {
    test('急救药与生物制品阈值前移：剩 30 天即预警', () {
      final rescue = ExpiryRule.judge(remainDays: 30, drugName: '硝酸甘油片');
      final normal = ExpiryRule.judge(remainDays: 30, drugName: '维生素C片');
      expect(rescue.level, ExpiryLevel.warn);
      expect(normal.level, ExpiryLevel.warn);
      // 差别在 45 天：常规药还算 notice，急救药已经提前 60 天关注
      expect(ExpiryRule.judge(remainDays: 45, drugName: '胰岛素注射液').level,
          ExpiryLevel.notice);
      expect(ExpiryRule.judge(remainDays: 45, drugName: '板蓝根颗粒').level,
          ExpiryLevel.notice);
      expect(ExpiryRule.judge(remainDays: 61, drugName: '硝酸甘油片').level,
          ExpiryLevel.safe);
      expect(ExpiryRule.judge(remainDays: 60, drugName: '硝酸甘油片').level,
          ExpiryLevel.notice);
    });

    test('开封敏感剂型按 28 天折算', () {
      // 未开封：剩 100 天本该是 safe
      expect(ExpiryRule.judge(remainDays: 100, drugName: '小儿止咳糖浆').level,
          ExpiryLevel.safe);
      // 开封 10 天，剩余窗口 18 天，仍在安全区（不降级）
      expect(
          ExpiryRule.judge(
                  remainDays: 100, drugName: '小儿止咳糖浆', openedDays: 10)
              .level,
          ExpiryLevel.safe);
      // 开封 25 天，只剩 3 天 → danger
      final d = ExpiryRule.judge(
          remainDays: 100, drugName: '小儿止咳糖浆', openedDays: 25);
      expect(d.level, ExpiryLevel.danger);
      // 开封超过 28 天 → danger
      expect(
          ExpiryRule.judge(
                  remainDays: 100, drugName: '氯霉素滴眼液', openedDays: 40)
              .level,
          ExpiryLevel.danger);
    });

    test('非敏感剂型即使记录了开封日期也不折算', () {
      final v = ExpiryRule.judge(
          remainDays: 100, drugName: '阿莫西林胶囊', openedDays: 40);
      expect(v.level, ExpiryLevel.safe);
    });
  });

  // ------------------------------------------------------------------ 成分检测

  group('IngredientDetector', () {
    test('商品名与英文通用名都能命中同一成分', () {
      final a = IngredientDetector.detect('芬必得布洛芬缓释胶囊');
      final b = IngredientDetector.detect('Ibuprofen Tablets');
      expect(a, contains('布洛芬'));
      expect(b, contains('布洛芬'));
    });

    test('无匹配时返回空集，不抛异常', () {
      expect(IngredientDetector.detect(''), isEmpty);
      expect(IngredientDetector.detect('一种完全不在词典里的药'), isEmpty);
    });
  });

  group('DuplicateChecker', () {
    test('同一成分出现在两种药品 → 强提醒', () {
      final out = DuplicateChecker.check([
        const MedicineEntry(name: '芬必得布洛芬缓释胶囊'),
        const MedicineEntry(name: '美林布洛芬混悬液'),
      ]);
      final strong = out.where((c) => c.level == ConflictLevel.strong).toList();
      expect(strong, hasLength(1));
      expect(strong.first.display, '布洛芬');
      expect(strong.first.drugNames, hasLength(2));
    });

    test('同名重复登记 → 弱提醒', () {
      final out = DuplicateChecker.check([
        const MedicineEntry(name: '板蓝根颗粒'),
        const MedicineEntry(name: '板蓝根颗粒'),
      ]);
      final weak = out.where((c) => c.level == ConflictLevel.weak).toList();
      expect(weak, hasLength(1));
      expect(weak.first.display, '板蓝根颗粒');
    });

    test('说明书主要成份原文也能作为判定依据', () {
      final out = DuplicateChecker.check([
        const MedicineEntry(name: '复方感冒灵颗粒', component: '含对乙酰氨基酚'),
        const MedicineEntry(name: '泰诺林', component: '对乙酰氨基酚'),
      ]);
      expect(out.any((c) => c.level == ConflictLevel.strong), isTrue);
    });

    test('空列表与空名称不产生结果', () {
      expect(DuplicateChecker.check([]), isEmpty);
      expect(DuplicateChecker.check([const MedicineEntry(name: '')]), isEmpty);
    });
  });

  // ------------------------------------------------------------------ 安全快照

  group('SafetySnapshot', () {
    test('分级计数与紧急数正确', () {
      final items = [
        DrugItem(medicineName: '过期药A', countDown: -3),
        DrugItem(medicineName: '紧急药B', countDown: 3),
        DrugItem(medicineName: '临近药C', countDown: 20),
        DrugItem(medicineName: '安全药D', countDown: 300),
      ];
      final s = SafetySnapshot.of(items);
      expect(s.total, 4);
      expect(s.count(ExpiryLevel.expired), 1);
      expect(s.count(ExpiryLevel.danger), 1);
      expect(s.count(ExpiryLevel.warn), 1);
      expect(s.count(ExpiryLevel.safe), 1);
      expect(s.urgent, 2);
      expect(s.hasAlert, isTrue);
      expect(s.headline, contains('1 种已过期'));
    });

    test('空药箱不拉响警报', () {
      final s = SafetySnapshot.of([]);
      expect(s.hasAlert, isFalse);
      expect(s.isClean, isTrue);
      expect(s.headline, '药箱为空');
    });

    test('快照会带上重复成分结论', () {
      final s = SafetySnapshot.of([
        DrugItem(medicineName: '芬必得布洛芬缓释胶囊', countDown: 300),
        DrugItem(medicineName: '美林布洛芬混悬液', countDown: 300),
      ]);
      expect(s.strongConflicts, 1);
      expect(s.hasAlert, isTrue);
    });

    test('脏数据（空名/未知字段）不导致崩溃', () {
      final s = SafetySnapshot.of([
        DrugItem(),
        DrugItem(medicineName: '阿司匹林肠溶片', countDown: 999),
      ]);
      expect(s.total, 2);
      expect(s.headline, isNotEmpty);
    });
  });

  // ------------------------------------------------------- 分级管控闸门（核心）

  group('ZhipuService 分级管控', () {
    ZhipuService serviceWith(String reply) {
      final dio = Dio(BaseOptions());
      dio.httpClientAdapter = MockAdapter((options) async {
        final body = jsonEncode({
          'choices': [
            {'message': {'content': reply}}
          ]
        });
        return ResponseBody(
          Stream<Uint8List>.value(Uint8List.fromList(utf8.encode(body))),
          200,
          headers: const {
            Headers.contentTypeHeader: [Headers.jsonContentType],
          },
        );
      });
      return ZhipuService(dio: dio);
    }

    test('模型"好心"多返回的医疗字段被丢弃', () async {
      // 模拟模型越界返回适应症/禁忌/用法用量 —— 这些必须由闸门拦掉
      final svc = serviceWith(jsonEncode({
        'drugName': '布洛芬缓释胶囊',
        'manu': '某制药有限公司',
        'syz': '用于缓解轻至中度疼痛', // 医疗字段
        'jj': '孕妇禁用', // 医疗字段
        'usage': '口服，一次 1 粒', // 医疗字段
        'zc': '密封保存', // 医疗字段
      }));

      final res = await svc.searchDrugByName('布洛芬');
      expect(res, isNotNull);
      expect(res!['drugName'], '布洛芬缓释胶囊');
      expect(res['manu'], '某制药有限公司');
      // 关键断言：医疗字段一个都不许进 UI
      expect(res.containsKey('syz'), isFalse);
      expect(res.containsKey('jj'), isFalse);
      expect(res.containsKey('usage'), isFalse);
      expect(res.containsKey('zc'), isFalse);
    });

    test('药箱报告只放行建议类字段', () async {
      final svc = serviceWith(jsonEncode({
        'summary': '药箱整体尚可',
        'suggestions': ['优先处理已过期药品', '分开存放外用与口服'],
        'storageTips': '置于阴凉干燥处',
        'relatedDrugs': ['阿莫西林'], // 报告场景不允许
      }));

      final res = await svc.medicineBoxReport(
        total: 3,
        expired: ['过期药'],
        nearExpiry: [],
        conflicts: [],
      );
      expect(res, isNotNull);
      expect(res!['summary'], '药箱整体尚可');
      expect(res['suggestions'], hasLength(2));
      expect(res.containsKey('relatedDrugs'), isFalse);
    });

    test('模型返回非法 JSON 时降级为 null，不向上抛', () async {
      final svc = serviceWith('抱歉，我无法回答这个问题');
      expect(await svc.searchDrugByName('随便什么'), isNull);
    });
  });

  // ------------------------------------------------------------------ 来源标记

  group('SourceBadge 来源分级', () {
    test('codedb 判为官方', () {
      expect(SourceBadge.tierOf('codedb'), SourceTier.official);
      expect(SourceBadge.labelOf('codedb'), '官方说明书');
    });

    test('ai / vision 判为 AI 参考', () {
      expect(SourceBadge.tierOf('ai'), SourceTier.ai);
      expect(SourceBadge.tierOf('vision'), SourceTier.ai);
      expect(SourceBadge.labelOf('ai'), 'AI 参考');
    });

    test('vision+codedb 判为混合来源', () {
      expect(SourceBadge.tierOf('vision+codedb'), SourceTier.mixed);
      expect(SourceBadge.labelOf('vision+codedb'), contains('官方说明书'));
    });
  });

  group('Medicine 官方说明书判定', () {
    test('hasOfficialInstruction 与 isExpired 不被误删', () {
      // isExpired 曾被误删导致编译失败，这里锁死它仍然存在
      final empty = Medicine();
      expect(empty.hasOfficialInstruction, isFalse);
      expect(empty.isExpired, isFalse);

      final withInstr = Medicine.fromDbRow(<String, dynamic>{
        'name': '布洛芬缓释胶囊',
        'ing': '布洛芬',
        'ind': '用于缓解轻至中度疼痛',
      });
      expect(withInstr.hasOfficialInstruction, isTrue);
      expect(withInstr.source, 'codedb');
    });
  });
}
