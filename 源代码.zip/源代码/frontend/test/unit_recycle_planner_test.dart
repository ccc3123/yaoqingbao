import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/data/drug_item.dart';
import 'package:yaoqingbao/util/expiry_rule.dart';
import 'package:yaoqingbao/util/recycle_planner.dart';

void main() {
  group('RecyclePlanner 回收规划', () {
    test('空列表返回空计划', () {
      final plan = RecyclePlanner.plan([]);
      expect(plan.isEmpty, isTrue);
      expect(plan.headline, contains('暂无'));
      expect(plan.categorySummary, isEmpty);
    });

    test('已回收条目被跳过，不进入回收清单', () {
      final plan = RecyclePlanner.plan([
        DrugItem(medicineId: '1', medicineName: '过期药', countDown: -3, recycled: 1),
        DrugItem(medicineId: '2', medicineName: '临期药', countDown: 10, recycled: 1),
      ]);
      expect(plan.isEmpty, isTrue);
      expect(plan.items, isEmpty);
    });

    test('过期 / 紧急 / 临近正确分级，安全级不纳入', () {
      final plan = RecyclePlanner.plan([
        DrugItem(medicineId: '1', medicineName: '过期药A', countDown: -5),
        DrugItem(medicineId: '2', medicineName: '紧急药B', countDown: 3),
        DrugItem(medicineId: '3', medicineName: '临近药C', countDown: 20),
        DrugItem(medicineId: '4', medicineName: '安全药D', countDown: 300),
      ]);
      expect(plan.items, hasLength(3)); // 过期 + 紧急 + 临近
      expect(plan.expiredCount, 1);
      expect(plan.nearExpiryCount, 2); // danger + warn
      expect(plan.categorySummary, contains('已过期 1 种'));
      expect(plan.categorySummary, contains('7天内到期 1 种'));
      expect(plan.categorySummary, contains('30天内到期 1 种'));
      expect(plan.headline, contains('3 种'));
    });

    test('回收项级别与原因文案对应', () {
      final plan = RecyclePlanner.plan([
        DrugItem(medicineId: '1', medicineName: '过期药', countDown: -1),
        DrugItem(medicineId: '2', medicineName: '临期药', countDown: 5),
      ]);
      final expired = plan.items.firstWhere((r) => r.item.medicineId == '1');
      final near = plan.items.firstWhere((r) => r.item.medicineId == '2');
      expect(expired.level, ExpiryLevel.expired);
      expect(expired.reason, contains('勿服用'));
      expect(near.level, ExpiryLevel.danger);
    });

    test('脏数据（空名/默认 countDown）不崩', () {
      final plan = RecyclePlanner.plan([
        DrugItem(medicineId: '1', medicineName: '正常过期药', countDown: -1),
        DrugItem(), // 全默认值
        DrugItem(medicineId: '3', medicineName: '安全药', countDown: 999),
      ]);
      expect(plan.expiredCount, 1);
      expect(plan.items, hasLength(1));
    });
  });
}
