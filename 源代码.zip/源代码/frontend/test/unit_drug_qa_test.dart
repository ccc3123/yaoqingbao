import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/util/drug_db.dart';
import 'package:yaoqingbao/util/drug_qa_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    // 单测里关闭 29MB 资产库，避免拖垮测试；此时检索一律返回空，
    // 正好覆盖「检索未命中」与「降级」分支。
    DrugDb.enabled = false;
  });

  group('DrugQaService 红线', () {
    test('空问题直接提示，不进 AI', () async {
      final a = await DrugQaService().answer('   ');
      expect(a.fromAi, isFalse);
      expect(a.answer, contains('请输入'));
    });

    test('诊疗类问题被本地拦截，不调 AI', () async {
      final a = await DrugQaService().answer('布洛芬和阿莫西林能一起吃吗');
      expect(a.fromAi, isFalse);
      expect(a.answer, contains('咨询药师或医师'));
    });

    test('剂量类问题被本地拦截', () async {
      final a = await DrugQaService().answer('阿莫西林一次吃多少');
      expect(a.fromAi, isFalse);
      expect(a.answer, contains('咨询药师或医师'));
    });

    test('检索未命中时给出降级提示，不崩', () async {
      final a = await DrugQaService().answer('一个完全不存在的药名XYZABC');
      expect(a.fromAi, isFalse);
      expect(a.answer, isNotEmpty);
    });
  });
}
