import 'package:flutter_test/flutter_test.dart';
import 'package:yaoqingbao/util/drug_db.dart';
import 'package:yaoqingbao/util/fuzzy_drug_matcher.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    // 关闭资产库：模糊匹配三级策略均落到「返回空」，验证降级路径不崩。
    DrugDb.enabled = false;
  });

  group('FuzzyDrugMatcher 边界', () {
    test('空关键词返回空，不抛异常', () async {
      final out = await FuzzyDrugMatcher.instance.match('  ');
      expect(out, isEmpty);
    });

    test('库不可用时返回空，不抛异常', () async {
      final out = await FuzzyDrugMatcher.instance.match('阿莫西林');
      expect(out, isEmpty);
    });

    test('limit 非法值回落到默认 10', () async {
      final out = await FuzzyDrugMatcher.instance.match('阿莫西林', limit: 0);
      expect(out, isEmpty); // 库关闭，但不应因 limit=0 崩溃
    });
  });
}
