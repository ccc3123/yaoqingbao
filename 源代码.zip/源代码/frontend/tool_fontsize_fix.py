#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把低于可读下限的字号提到 12px，并归并孤立字号。

  fontSize: 9 / 10 / 11 → AppText.sizeCaption (12)   移动端可读下限
  fontSize: 17          → AppText.sizeTitle   (18)   孤立值，归并到 scale

用法：
    python tool_fontsize_fix.py          # dry-run
    python tool_fontsize_fix.py --apply
"""
import os
import re
import sys

LIB = "lib"
SKIP = {"lib/theme/app_text.dart", "lib/theme/app_colors.dart", "lib/theme/app_dimens.dart"}

RULES = [
    (re.compile(r"fontSize: (?:9|10|11)\b"), "fontSize: AppText.sizeCaption"),
    (re.compile(r"fontSize: 17\b"), "fontSize: AppText.sizeTitle"),
]


def norm(p):
    return p.replace(os.sep, "/")


def ensure_import(text, rel):
    if "theme/app_text.dart" in text:
        return text, False
    depth = rel.count("/") - 1
    stmt = "import '%stheme/app_text.dart';" % ("../" * depth if depth > 0 else "")
    lines = text.split("\n")
    last = -1
    for i, line in enumerate(lines):
        if line.startswith("import "):
            last = i
    if last < 0:
        return text, False
    lines.insert(last + 1, stmt)
    return "\n".join(lines), True


def main():
    apply = "--apply" in sys.argv
    files = changed = added = 0
    for root, _d, fns in os.walk(LIB):
        for fn in sorted(fns):
            if not fn.endswith(".dart"):
                continue
            path = os.path.join(root, fn)
            rel = norm(path)
            if rel in SKIP:
                continue
            with open(path, encoding="utf-8") as fh:
                original = fh.read()
            text = original
            n = 0
            for pat, repl in RULES:
                text, k = pat.subn(repl, text)
                n += k
            if not n:
                continue
            text, imp = ensure_import(text, rel)
            files += 1
            changed += n
            if imp:
                added += 1
            print("  %-44s %2d 处 %s" % (rel, n, "+import" if imp else ""))
            if apply:
                with open(path, "w", encoding="utf-8", newline="\n") as fh:
                    fh.write(text)

    print()
    print("%s | %d 个文件 | %d 处字号 | 补 import %d"
          % ("APPLY 已写入" if apply else "DRY-RUN", files, changed, added))


if __name__ == "__main__":
    main()
