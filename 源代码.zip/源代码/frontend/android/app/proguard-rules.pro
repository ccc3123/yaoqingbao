# Flutter ProGuard 规则
-keep class io.flutter.app.** { *; }
-keep class io.flutter.plugin.**  { *; }
-keep class io.flutter.util.**  { *; }
-keep class io.flutter.view.**  { *; }
-keep class io.flutter.**  { *; }
-keep class io.flutter.plugins.**  { *; }

# Dio
-keepattributes Signature
-keepattributes *Annotation*
-keep class cn.edu.ppsuc.yaoqingbao.** { *; }
