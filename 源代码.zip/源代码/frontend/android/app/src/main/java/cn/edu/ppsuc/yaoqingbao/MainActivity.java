package cn.edu.ppsuc.yaoqingbao;

import io.flutter.embedding.android.FlutterActivity;

/**
 * 药清宝主入口 Activity。
 *
 * 该文件在包名迁移（com.sduonline.shiyo.yaoqingbao → cn.edu.ppsuc.yaoqingbao）时
 * 被遗漏，导致 AndroidManifest 中声明的 .MainActivity 在运行时找不到类，
 * 表现为冷启动/热启动立刻闪退（ClassNotFoundException）。
 */
public class MainActivity extends FlutterActivity {
}
