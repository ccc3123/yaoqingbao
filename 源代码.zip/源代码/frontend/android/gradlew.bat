@rem Gradle wrapper bootstrap
@if "%DEBUG%"=="" @echo off
@rem Set project home
set DIRNAME=%~dp0
if "%DIRNAME%" == "" set DIRNAME=.
set APP_HOME=%DIRNAME%
@rem Find Java
if "%JAVA_HOME%"=="" set JAVA_EXE=java
if not "%JAVA_HOME%"=="" set JAVA_EXE=%JAVA_HOME%\bin\java
@rem Gradle wrapper jar location
set GRADLEW_JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%GRADLEW_JAR%" (
    echo Gradle wrapper JAR not found at: %GRADLEW_JAR%
    echo Downloading Gradle wrapper...
    mkdir "%APP_HOME%gradle\wrapper" 2>nul
)
@rem Run Gradle
"%JAVA_EXE%" -classpath "%GRADLEW_JAR%" org.gradle.wrapper.GradleWrapperMain %*
