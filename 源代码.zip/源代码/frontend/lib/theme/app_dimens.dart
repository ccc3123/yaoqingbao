/// 间距与圆角 token。
///
/// 原状况：圆角散落 12 种值（2/3/4/8/10/12/14/16/18/20/24/28），
/// 相邻档位同时在用，导致"每个卡片圆角都不太一样"。现收敛为 5 档。
library;

import 'package:flutter/material.dart';

/// 8pt 网格间距。页面内一律用这些常量，不写裸数字。
abstract final class AppSpacing {
  AppSpacing._();

  static const xs = 4.0; // 图标与文字之间
  static const sm = 8.0; // 紧凑元素间隔
  static const md = 12.0; // 卡片内行间隔
  static const lg = 16.0; // 卡片内边距 / 页面左右边距
  static const xl = 24.0; // 区块之间
  static const xxl = 32.0; // 大区块 / 空状态留白

  /// 页面统一左右边距。
  static const pagePadding = EdgeInsets.symmetric(horizontal: lg);

  /// 卡片统一内边距。
  static const cardPadding = EdgeInsets.all(lg);
}

/// 圆角 5 档。
abstract final class AppRadius {
  AppRadius._();

  static const xs = 4.0; // 标记条 / 进度条
  static const sm = 8.0; // 小标签 / 输入框内元素
  static const md = 12.0; // 按钮 / 输入框 / SnackBar
  static const lg = 16.0; // 卡片
  static const xl = 24.0; // 大卡片 / BottomSheet / 弹层

  static const pill = 999.0; // 胶囊（Chip / 徽标）

  static BorderRadius get rSm => BorderRadius.circular(sm);
  static BorderRadius get rMd => BorderRadius.circular(md);
  static BorderRadius get rLg => BorderRadius.circular(lg);
  static BorderRadius get rXl => BorderRadius.circular(xl);
  static BorderRadius get rPill => BorderRadius.circular(pill);

  /// BottomSheet 顶部圆角。
  static const sheetTop = BorderRadius.vertical(top: Radius.circular(xl));
}

/// 触控目标最小尺寸 —— 移动端可访问性硬指标。
abstract final class AppTouch {
  AppTouch._();

  /// WCAG / Material 最小可点区域 44×44。
  static const minSize = 44.0;

  static const minConstraints = BoxConstraints(
    minWidth: minSize,
    minHeight: minSize,
  );
}
