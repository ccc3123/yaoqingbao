/// 字号阶梯（type scale）。
///
/// 原状况：281 处硬编码 fontSize，用了 17 种字号
/// （9/10/11/12/13/14/15/16/17/18/20/22/24/26/28/34/36），无层级规律；
/// 其中 9-11px 低于移动端可读下限。现收敛为 8 档，最小 12px。
///
/// 药清宝面向老年与慢病用户，正文基准定在 15-16px 而非常见的 14px。
library;

import 'package:flutter/material.dart';

import 'app_colors.dart';

abstract final class AppText {
  AppText._();

  // ── 字号常量（需要裸数字时用这些，勿写字面量） ──
  static const sizeCaption = 12.0; // 辅助说明 / 徽标（下限）
  static const sizeFootnote = 13.0; // 次级说明
  static const sizeBody = 15.0; // 正文基准
  static const sizeBodyLarge = 16.0; // 重点正文 / 列表主文案
  static const sizeTitle = 18.0; // 卡片标题
  static const sizeHeadline = 20.0; // 页面标题 / AppBar
  static const sizeDisplay = 26.0; // 统计数值
  static const sizeDisplayLarge = 34.0; // 启动页 / 大数字

  // ── 文字样式 ──
  static const caption = TextStyle(
    fontSize: sizeCaption,
    height: 1.4,
    color: AppColors.muted,
  );

  static const footnote = TextStyle(
    fontSize: sizeFootnote,
    height: 1.45,
    color: AppColors.ink3,
  );

  static const body = TextStyle(
    fontSize: sizeBody,
    height: 1.55,
    color: AppColors.ink,
  );

  static const bodyLarge = TextStyle(
    fontSize: sizeBodyLarge,
    height: 1.55,
    color: AppColors.ink,
  );

  static const bodyMuted = TextStyle(
    fontSize: sizeBody,
    height: 1.55,
    color: AppColors.ink3,
  );

  static const title = TextStyle(
    fontSize: sizeTitle,
    height: 1.35,
    fontWeight: FontWeight.w600,
    color: AppColors.ink,
  );

  static const headline = TextStyle(
    fontSize: sizeHeadline,
    height: 1.3,
    fontWeight: FontWeight.w700,
    color: AppColors.ink,
  );

  static const display = TextStyle(
    fontSize: sizeDisplay,
    height: 1.1,
    fontWeight: FontWeight.w800,
    color: AppColors.ink,
  );

  // ── 深底之上（深绿头部 / 河流导航栏） ──
  static const onDarkHeadline = TextStyle(
    fontSize: sizeHeadline,
    fontWeight: FontWeight.w800,
    letterSpacing: 3,
    color: AppColors.onDark,
  );

  static const onDarkSubtitle = TextStyle(
    fontSize: sizeCaption,
    letterSpacing: 2,
    color: Color(0xE6FFFFFF), // 90% 白，深绿底上仍 ≥4.5:1
  );

  static const onDarkDisplay = TextStyle(
    fontSize: sizeDisplay,
    fontWeight: FontWeight.w900,
    letterSpacing: 2,
    color: AppColors.onDark,
  );

  static const onDarkLabel = TextStyle(
    fontSize: sizeCaption,
    fontWeight: FontWeight.w500,
    letterSpacing: 1,
    color: Color(0xD9FFFFFF), // 85% 白
  );
}
