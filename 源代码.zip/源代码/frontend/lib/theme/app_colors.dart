/// 药清宝设计 token —— 单一真相源。
///
/// 三层结构，页面只允许引用第 2、3 层：
///   1. [AppPalette]  原始色板（阶梯值，不带语义，勿在页面直接用）
///   2. [AppColors]   语义 token（文字 / 品牌 / 状态 / 表面）
///   3. [AppSemantic] 功能语义（AI 标识 / 知识分类 / 数据来源）
///
/// 对比度约定（白底实测，括号内为比值）：
///   · 凡用于**文字**的 token 均 ≥4.5:1，满足 WCAG AA 正文；
///   · 标注「装饰」的仅可用于图形、分隔线或 ≥18pt 大字（≥3:1）；
///   · `onDark*` 系列用于深绿底/图片底之上，反向取浅色。
library;

import 'package:flutter/material.dart';

/// 原始色板 —— 只给 [AppColors] / [AppSemantic] 取值用。
abstract final class AppPalette {
  AppPalette._();

  // ── 品牌绿 8 档 ──
  static const g900 = Color(0xFF0A3D12); // 12.43  渐变最深端 / 启动页
  static const g800 = Color(0xFF0D5018); //  9.64  顶栏 / AppBar
  static const g700 = Color(0xFF1B5E20); //  7.87  强调文字
  static const g600 = Color(0xFF2E7D32); //  5.13  ★主色（白字达 AA）
  static const g500 = Color(0xFF43A047); //  3.30  装饰
  static const g300 = Color(0xFF81C784); //  2.01  装饰
  static const g100 = Color(0xFFC8E6C9); //  1.34  tint
  static const g50 = Color(0xFFE8F5E9); //   1.12  最浅 tint

  // ── 中性灰（slate 冷灰，全项目唯一一套） ──
  static const n900 = Color(0xFF1F2937); // 14.68
  static const n700 = Color(0xFF374151); // 10.31
  static const n600 = Color(0xFF4B5563); //  7.56
  static const n500 = Color(0xFF6B7280); //  4.83
  static const n200 = Color(0xFFE5E7EB); //  1.24  分隔线
  static const n100 = Color(0xFFF3F4F6); //  1.10  浅块底
  static const n50 = Color(0xFFF7FAF8); //   1.05  页面底
  static const white = Color(0xFFFFFFFF);

  // ── 状态色 ──
  static const red700 = Color(0xFFB42318); //   6.57
  static const red50 = Color(0xFFFFEBEE); //    1.14
  static const amber800 = Color(0xFF8A5300); //  6.33
  static const amber50 = Color(0xFFFFF8E1); //   1.06
  static const blue800 = Color(0xFF1565C0); //   5.75
  static const blue400 = Color(0xFF42A5F5); //   2.65  装饰
  static const blue50 = Color(0xFFE3F2FD); //    1.14

  // ── 功能语义原色 ──
  static const indigo400 = Color(0xFF5C6BC0); //  4.86  AI
  static const indigo900 = Color(0xFF283593); // 10.39  AI 深
  static const indigo50 = Color(0xFFDCE3FF); //   1.27  AI tint
  static const purple700 = Color(0xFF7B1FA2); //  8.20  科普分类
  static const purple50 = Color(0xFFF3E5F5); //   1.21
  static const brown400 = Color(0xFF8D6E63); //   4.62  本地库来源

  // ── 深底之上的浅色 ──
  static const onDarkRed = Color(0xFFFF8A80);
  static const onDarkAmber = Color(0xFFFFD54F);
  static const onDarkMint = Color(0xFFA8E8B0);
}

/// 语义 token —— 页面写 UI 时的首选入口。
abstract final class AppColors {
  AppColors._();

  // ── 文字层级（全部 ≥4.5:1） ──
  static const ink = AppPalette.n900; // 正文 / 标题
  static const ink2 = AppPalette.n700; // 次级强调
  static const ink3 = AppPalette.n600; // 次级文字 / 说明
  static const muted = AppPalette.n500; // 提示 / 占位 / 禁用
  static const onPrimary = AppPalette.white; // 主色底上的文字

  // ── 品牌 ──
  static const primary = AppPalette.g600; // 按钮底 / 主要图标
  static const primaryDark = AppPalette.g800; // 顶栏 / 深色区
  static const primaryDeepest = AppPalette.g900; // 渐变最深端
  static const primaryStrong = AppPalette.g700; // 品牌色文字（正文可用）
  static const primaryLight = AppPalette.g500; // 装饰
  static const primaryPale = AppPalette.g300; // 装饰 / 深底上的浅元素
  static const primaryTint = AppPalette.g100; // 浅底块
  static const primaryTintWeak = AppPalette.g50; // 最浅底块

  // ── 状态 ──
  static const danger = AppPalette.red700;
  static const dangerTint = AppPalette.red50;
  static const warning = AppPalette.amber800;
  static const warningTint = AppPalette.amber50;
  static const info = AppPalette.blue800;
  static const infoLight = AppPalette.blue400; // 装饰 / 渐变
  static const infoTint = AppPalette.blue50;
  static const success = AppPalette.g600;

  // ── 表面 / 描边 ──
  static const surface = AppPalette.n50; // 页面底
  static const card = AppPalette.white; // 卡片
  static const subtleBg = AppPalette.n100; // 浅块底
  static const divider = AppPalette.n200; // 分隔线 / 边框

  // ── 深底之上（深绿头部、河流导航栏） ──
  static const onDark = AppPalette.white;
  static const onDarkMint = AppPalette.onDarkMint; // 激活态文字
  static const onDarkDanger = AppPalette.onDarkRed; // 深底上的危险图标
  static const onDarkWarning = AppPalette.onDarkAmber; // 深底上的警告图标
}

/// 功能语义 token —— 承载"这个颜色代表什么信息"，不可随意换色。
///
/// 改动这里会改变用户对信息类型的判断，等同于改产品逻辑。
abstract final class AppSemantic {
  AppSemantic._();

  // ── AI 标识 ──
  // 凡「AI 生成 / AI 建议 / AI 查询」一律用这一族，与官方原文形成视觉区分。
  // 原先 #7C4DFF（艳紫）与 #5C6BC0（靛蓝）混用表达同一概念，现统一为靛蓝：
  // 医疗场景下更沉稳，且避开"AI 紫/粉渐变"这一削弱专业感的通用反模式。
  static const ai = AppPalette.indigo400; // AI 功能主色（4.86）
  static const aiStrong = AppPalette.indigo900; // AI 深色 / 渐变端（10.39）
  static const aiTint = AppPalette.indigo50; // AI 浅底块

  // ── 知识分类 ──
  // 原先在 guichu_page / knowledge_page / knowledge_detail_page 三处重复定义，
  // 现收敛到这里，改分类配色只需动一处。
  static const categoryPolicy = AppPalette.blue800; // 政策法规（5.75）
  static const categoryGuide = AppPalette.g600; // 操作指南（5.13）
  static const categoryScience = AppPalette.purple700; // 科普知识（8.20）
  static const categoryScienceTint = AppPalette.purple50;

  /// 按后端分类 key 取色，未知分类回落到次级文字色。
  static Color category(String? key) => switch (key) {
        'policy' => categoryPolicy,
        'guide' => categoryGuide,
        'science' => categoryScience,
        _ => AppColors.ink3,
      };

  // ── 数据来源标识（诚信溯源：让用户看得出内容出处） ──
  // 对应 source_badge.dart 的 SourceTier，三档颜色即三种可信度。
  static const sourceOfficial = AppPalette.g600; // 官方说明书原文
  static const sourceAi = AppPalette.purple700; // AI 参考
  static const sourceMixed = AppPalette.indigo900; // AI 识别 + 官方说明书
  static const sourceLocal = AppPalette.brown400; // 本机离线库（4.62）

  // ── 用药风险标记 ──
  // 与知识分类 / 来源标识值相同但语义独立：日后单独调色不会互相牵连。
  static const conflict = AppPalette.purple700; // 重复成分 / 相互作用
  static const conflictStrong = AppPalette.red700; // 强相互作用（升级为红）
}

/// 渐变 token。
///
/// 顶栏渐变原先以字面量散落在 home_page / splash_page，两处一旦漂移就会
/// 出现"同一个头部两种绿"。收敛到这里后，二级页 AppBar 用的纯色
/// [AppColors.primaryDark] 正是本渐变的中间色，切换页面时色系连贯。
abstract final class AppGradients {
  AppGradients._();

  /// 深绿头部（主页 / 启动页）：左上最深 → 右下略亮。
  static const header = LinearGradient(
    colors: [
      AppColors.primaryDeepest,
      AppColors.primaryDark,
      AppColors.primaryStrong,
    ],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  /// 统计条（药匣页顶部数据区）。
  static const stat = LinearGradient(
    colors: [AppColors.primaryStrong, AppColors.primaryLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
