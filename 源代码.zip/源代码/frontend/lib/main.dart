import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'routes/splash_page.dart';
import 'theme/app_colors.dart';
import 'theme/app_dimens.dart';
import 'theme/app_text.dart';
import 'util/crash_guard.dart';

/// 药清宝 V3 — 药品公益回收平台
/// 零账户 · 零交易 · 零个人信息收集
/// 三节点河流导航：寻源 → 药匣 → 归处
///
/// 入口用 runZonedGuarded 包一层：启动期的任何异步异常都不会导致静默闪退，
/// 而是被 CrashGuard 记录并在界面上给出可见反馈。
void main() {
  runZonedGuarded(_bootstrap, CrashGuard.reportZoneError);
}

Future<void> _bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();
  CrashGuard.install();

  // 系统级初始化失败不应阻断启动：失败时只降级掉"强制竖屏/沉浸式状态栏"
  try {
    await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
    );
  } catch (e, s) {
    CrashGuard.reportZoneError(e, s);
  }

  try {
    runApp(const YaoQingBaoApp());
  } catch (e, s) {
    // 兜底：连主 widget 都构建不了时，至少给用户一个可读的错误页而不是黑屏
    CrashGuard.reportZoneError(e, s);
    runApp(const _StartupFailApp());
  }
}

/// 启动失败降级页
class _StartupFailApp extends StatelessWidget {
  const _StartupFailApp();

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.error_outline, size: 56, color: AppColors.danger),
                SizedBox(height: 16),
                Text(
                  '应用启动失败',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                ),
                SizedBox(height: 8),
                Text(
                  '请重启应用；若持续出现，请卸载重装或联系开发者。',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class YaoQingBaoApp extends StatelessWidget {
  const YaoQingBaoApp({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.primary,
      primary: AppColors.primaryDark,
      onPrimary: AppColors.onPrimary,
      secondary: AppColors.primaryPale,
      surface: AppColors.surface,
      error: AppColors.danger,
      brightness: Brightness.light,
    );

    return MaterialApp(
      title: '药清宝',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: colorScheme,
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.surface,
        // 不指定 fontFamily：交给系统选中文字体（Android → Noto Sans CJK，
        // iOS → PingFang SC）。原先硬写 'PingFang SC' 在 Android 上并不存在，
        // 属无效配置，反而让各家 ROM 的回退结果不一致。
        textTheme: const TextTheme(
          bodyLarge: AppText.bodyLarge,
          bodyMedium: AppText.body,
          bodySmall: AppText.caption,
          titleMedium: AppText.title,
          titleLarge: AppText.headline,
          labelLarge: TextStyle(
            color: AppColors.ink,
            fontSize: AppText.sizeBody,
            fontWeight: FontWeight.w600,
          ),
        ),
        disabledColor: AppColors.muted,

        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
          scrolledUnderElevation: 1,
          backgroundColor: AppColors.primaryDark,
          foregroundColor: AppColors.onDark,
          titleTextStyle: TextStyle(
            color: AppColors.onDark,
            fontSize: AppText.sizeHeadline,
            fontWeight: FontWeight.w700,
          ),
        ),

        cardTheme: CardThemeData(
          elevation: 1,
          shadowColor: Colors.black26,
          shape: RoundedRectangleBorder(borderRadius: AppRadius.rLg),
          margin: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: AppSpacing.sm,
          ),
        ),

        chipTheme: ChipThemeData(
          backgroundColor: AppColors.primary.withAlpha(20),
          selectedColor: AppColors.primaryPale,
          labelStyle: const TextStyle(fontSize: AppText.sizeFootnote),
          padding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.sm,
            vertical: 2,
          ),
          shape: RoundedRectangleBorder(borderRadius: AppRadius.rPill),
        ),

        bottomSheetTheme: const BottomSheetThemeData(
          shape: RoundedRectangleBorder(borderRadius: AppRadius.sheetTop),
        ),

        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.card,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: AppSpacing.lg,
            vertical: AppSpacing.md,
          ),
          border: OutlineInputBorder(
            borderRadius: AppRadius.rLg,
            borderSide: const BorderSide(color: AppColors.divider),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: AppRadius.rLg,
            borderSide: const BorderSide(color: AppColors.divider),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: AppRadius.rLg,
            borderSide: const BorderSide(
              color: AppColors.primaryDark,
              width: 2,
            ),
          ),
          hintStyle: const TextStyle(color: AppColors.ink3),
          labelStyle: const TextStyle(color: AppColors.ink3),
          errorStyle: const TextStyle(
            color: AppColors.danger,
            fontWeight: FontWeight.w600,
          ),
        ),

        // 按钮最小高度 48 ≥ 44×44 触控下限（老年用户为主，取偏大值）。
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: AppColors.primaryDark,
            foregroundColor: AppColors.onPrimary,
            disabledBackgroundColor: AppColors.divider,
            disabledForegroundColor: AppColors.muted,
            minimumSize: const Size(0, 48),
            shape: RoundedRectangleBorder(borderRadius: AppRadius.rMd),
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.xl,
              vertical: AppSpacing.md,
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.primaryDark,
            disabledForegroundColor: AppColors.muted,
            side: const BorderSide(color: AppColors.primaryDark),
            minimumSize: const Size(0, 48),
            shape: RoundedRectangleBorder(borderRadius: AppRadius.rMd),
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.lg,
              vertical: AppSpacing.md,
            ),
          ),
        ),

        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: AppRadius.rMd),
        ),

        pageTransitionsTheme: PageTransitionsTheme(
          builders: const {
            TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
            TargetPlatform.iOS: FadeUpwardsPageTransitionsBuilder(),
          },
        ),
      ),
      home: const SplashPage(),
    );
  }
}
