import '../util/safe_cast.dart';

/// 用户药品清单条目
/// 本地存 SharedPreferences，同时按设备标识同步到服务端 /medbox，
/// 便于家庭成员之间查看（子女远程看父母药箱）。
class DrugItem {
  final String medicineId;
  final String medicineName;
  final String produceTime;
  final String addTime;
  final int countDown;
  final int expDays;
  /// 是否已投递回收（0 未回收 / 1 已回收）
  final int recycled;
  /// 录入来源：local 手动 / scan 扫码（离线库）/ ai 搜索 / vision 拍照
  final String source;

  // ===== 溯源字段（AI 分级管控：这些只允许来自官方说明书原文）=====

  /// 主要成份（说明书原文）。重复用药检测的唯一依据，
  /// **禁止**由 AI 生成 —— 成份猜错会直接导致用药安全风险。
  final String component;

  /// 生产厂家
  final String manu;

  /// 规格
  final String spec;

  /// 命中该药品的条码，没有则为空
  final String barcode;

  /// 开封日期（yyyy-MM-dd），为空表示未记录。
  /// 糖浆/滴眼液等剂型开封后有效期大幅缩短，需要单独折算。
  final String openedAt;

  // ===== 科学计量字段（V3：总量 + 单位 + 余量）=====

  /// 总量（按单位计量，支持小数如半片 0.5）
  final double total;

  /// 计量单位：片/颗/粒/瓶/袋/支/包/盒/mg/ml/g
  final String unit;

  /// 剩余量（服药后递减；0 且未录入时视为未记）
  final double remaining;

  /// 最近一次服药时间 yyyy-MM-dd HH:mm，为空表示未记录
  final String lastTakenAt;

  DrugItem({
    this.medicineId = '',
    this.medicineName = '',
    this.produceTime = '',
    this.addTime = '',
    this.countDown = 999,
    this.expDays = 0,
    this.recycled = 0,
    this.source = 'local',
    this.component = '',
    this.manu = '',
    this.spec = '',
    this.barcode = '',
    this.openedAt = '',
    this.total = 0,
    this.unit = '',
    this.remaining = 0,
    this.lastTakenAt = '',
  });

  factory DrugItem.fromJson(Map<String, dynamic> json) {
    return DrugItem(
      medicineId: asStringSafe(json['medicineId']),
      medicineName: asStringSafe(json['medicineName']),
      produceTime: asStringSafe(json['produceTime']),
      addTime: asStringSafe(json['addTime']),
      countDown: asIntSafe(json['countDown'], 999),
      expDays: asIntSafe(json['expDays']),
      recycled: asIntSafe(json['recycled']),
      source: asStringSafe(json['source'], 'local'),
      component: asStringSafe(json['component']),
      manu: asStringSafe(json['manu']),
      spec: asStringSafe(json['spec']),
      barcode: asStringSafe(json['barcode']),
      openedAt: asStringSafe(json['openedAt']),
      total: asDoubleSafe(json['total']),
      unit: asStringSafe(json['unit']),
      remaining: asDoubleSafe(json['remaining']),
      lastTakenAt: asStringSafe(json['lastTakenAt']),
    );
  }

  Map<String, dynamic> toJson() => {
        'medicineId': medicineId,
        'medicineName': medicineName,
        'produceTime': produceTime,
        'addTime': addTime,
        'countDown': countDown,
        'expDays': expDays,
        'recycled': recycled,
        'source': source,
        'component': component,
        'manu': manu,
        'spec': spec,
        'barcode': barcode,
        'openedAt': openedAt,
        'total': total,
        'unit': unit,
        'remaining': remaining,
        'lastTakenAt': lastTakenAt,
      };

  /// 是否已记录开封日期
  bool get hasOpenedAt => openedAt.isNotEmpty;

  /// 距今天已开封多少天；未记录返回 null
  int? get openedDays {
    if (openedAt.isEmpty) return null;
    try {
      final d = DateTime.parse(openedAt);
      return DateTime.now().difference(d).inDays;
    } catch (_) {
      return null;
    }
  }

  DrugItem copyWith({
    String? medicineId,
    String? medicineName,
    String? produceTime,
    String? addTime,
    int? countDown,
    int? expDays,
    int? recycled,
    String? source,
    String? component,
    String? manu,
    String? spec,
    String? barcode,
    String? openedAt,
    double? total,
    String? unit,
    double? remaining,
    String? lastTakenAt,
  }) =>
      DrugItem(
        medicineId: medicineId ?? this.medicineId,
        medicineName: medicineName ?? this.medicineName,
        produceTime: produceTime ?? this.produceTime,
        addTime: addTime ?? this.addTime,
        countDown: countDown ?? this.countDown,
        expDays: expDays ?? this.expDays,
        recycled: recycled ?? this.recycled,
        source: source ?? this.source,
        component: component ?? this.component,
        manu: manu ?? this.manu,
        spec: spec ?? this.spec,
        barcode: barcode ?? this.barcode,
        openedAt: openedAt ?? this.openedAt,
        total: total ?? this.total,
        unit: unit ?? this.unit,
        remaining: remaining ?? this.remaining,
        lastTakenAt: lastTakenAt ?? this.lastTakenAt,
      );
}
