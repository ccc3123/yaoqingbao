import '../util/safe_cast.dart';

/// 服药记录
///
/// 记录「谁在什么时候服用了多少药」，家庭共享后家人互相可见，实现异地照护。
class MedRecord {
  /// 服务端主键；0 表示本地新建尚未同步
  final int id;

  /// 药箱条目 ID（关联 DrugItem.medicineId）
  final String medicineId;

  /// 药品名称
  final String medicineName;

  /// 本次服用剂量
  final double dose;

  /// 单位：片/颗/粒/瓶/袋/支/包/盒/mg/ml/g
  final String unit;

  /// 服药时间 yyyy-MM-dd HH:mm
  final String takenAt;

  /// 记录人称谓（成员名/昵称）
  final String memberName;

  MedRecord({
    this.id = 0,
    this.medicineId = '',
    this.medicineName = '',
    this.dose = 0,
    this.unit = '',
    this.takenAt = '',
    this.memberName = '',
  });

  factory MedRecord.fromJson(Map<String, dynamic> json) {
    return MedRecord(
      id: asIntSafe(json['id']),
      medicineId: asStringSafe(json['medicineId']),
      medicineName: asStringSafe(json['medicineName']),
      dose: asDoubleSafe(json['dose']),
      unit: asStringSafe(json['unit']),
      takenAt: asStringSafe(json['takenAt']),
      memberName: asStringSafe(json['memberName']),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'medicineId': medicineId,
        'medicineName': medicineName,
        'dose': dose,
        'unit': unit,
        'takenAt': takenAt,
        'memberName': memberName,
      };
}
