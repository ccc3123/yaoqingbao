import '../util/safe_cast.dart';

/// 服药计划
///
/// 计划含每日服药时间点，客户端据此把闹钟写入系统日历；
/// 家庭共享后各成员在自己手机日历看到相同的服药提醒。
class MedPlan {
  /// 服务端主键；0 表示本地新建尚未同步
  final int id;

  /// 药品名称
  final String medicineName;

  /// 剂量说明，如：1片 / 10ml
  final String dosage;

  /// 每日服药时间点，如 ['08:00','12:00','20:00']
  final List<String> times;

  /// 开始日期 yyyy-MM-dd
  final String startDate;

  /// 结束日期（空=长期）
  final String endDate;

  /// 是否启用
  final bool enabled;

  /// 已写入系统日历的事件 ID（用于增删改闹钟）
  final List<String> calendarEventIds;

  MedPlan({
    this.id = 0,
    this.medicineName = '',
    this.dosage = '',
    this.times = const [],
    this.startDate = '',
    this.endDate = '',
    this.enabled = true,
    this.calendarEventIds = const [],
  });

  factory MedPlan.fromJson(Map<String, dynamic> json) {
    final List<String> t = <String>[];
    final raw = json['times'];
    if (raw is List) {
      for (final e in raw) {
        final s = asStringSafe(e).trim();
        if (s.isNotEmpty) t.add(s);
      }
    } else {
      // 兼容逗号分隔字符串
      for (final s in asStringSafe(json['times']).split(',')) {
        final v = s.trim();
        if (v.isNotEmpty) t.add(v);
      }
    }
    final List<String> ev = <String>[];
    final rawEv = json['calendarEventIds'];
    if (rawEv is List) {
      for (final e in rawEv) {
        final s = asStringSafe(e).trim();
        if (s.isNotEmpty) ev.add(s);
      }
    }
    return MedPlan(
      id: asIntSafe(json['id']),
      medicineName: asStringSafe(json['medicineName']),
      dosage: asStringSafe(json['dosage']),
      times: t,
      startDate: asStringSafe(json['startDate']),
      endDate: asStringSafe(json['endDate']),
      enabled: asIntSafe(json['enabled'], 1) != 0,
      calendarEventIds: ev,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'medicineName': medicineName,
        'dosage': dosage,
        'times': times,
        'startDate': startDate,
        'endDate': endDate,
        'enabled': enabled ? 1 : 0,
        'calendarEventIds': calendarEventIds,
      };

  /// 时间点摘要，如「早 08:00 · 中 12:00 · 晚 20:00」
  String get timesLabel => times.join(' · ');

  MedPlan copyWith({
    int? id,
    String? medicineName,
    String? dosage,
    List<String>? times,
    String? startDate,
    String? endDate,
    bool? enabled,
    List<String>? calendarEventIds,
  }) =>
      MedPlan(
        id: id ?? this.id,
        medicineName: medicineName ?? this.medicineName,
        dosage: dosage ?? this.dosage,
        times: times ?? this.times,
        startDate: startDate ?? this.startDate,
        endDate: endDate ?? this.endDate,
        enabled: enabled ?? this.enabled,
        calendarEventIds: calendarEventIds ?? this.calendarEventIds,
      );
}
