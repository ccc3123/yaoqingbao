import '../util/safe_cast.dart';

/// 药品数据模型
class Medicine {
  final String id;
  final String drugName;
  final String ggxh;
  final String manu;
  final String price;
  final String blfy;
  final String jj;
  final String pzwh;
  final String syz;
  final String type;
  final String yxq;
  final String zc;
  final String zysx;
  final String zzjb;
  final int exp;

  /// 用法用量（来自药品说明书官方原文）
  final String usage;

  /// 主要成份（来自药品说明书官方原文，用于重复用药检测）
  final String component;

  /// 商品名 / 别名，如「金戈」
  final String brand;

  /// 命中的条码，便于追溯与缓存
  final String barcode;

  /// 数据来源标记： codedb=开源条码库  local=本地精选库  ai=文本AI  vision=视觉AI
  /// 分级管控据此决定是否打「AI 参考」标。
  final String source;

  Medicine({
    this.id = '',
    this.drugName = '',
    this.ggxh = '',
    this.manu = '',
    this.price = '',
    this.blfy = '',
    this.jj = '',
    this.pzwh = '',
    this.syz = '',
    this.type = '',
    this.yxq = '',
    this.zc = '',
    this.zysx = '',
    this.zzjb = '',
    this.exp = 0,
    this.usage = '',
    this.component = '',
    this.brand = '',
    this.barcode = '',
    this.source = '',
  });

  factory Medicine.fromJson(Map<String, dynamic> json) {
    return Medicine(
      id: asStringSafe(json['id']),
      drugName: asStringSafe(json['drugName']),
      ggxh: asStringSafe(json['ggxh']),
      manu: asStringSafe(json['manu']),
      price: asStringSafe(json['price']),
      blfy: asStringSafe(json['blfy']),
      jj: asStringSafe(json['jj']),
      pzwh: asStringSafe(json['pzwh']),
      syz: asStringSafe(json['syz']),
      type: asStringSafe(json['type']),
      yxq: asStringSafe(json['yxq']),
      zc: asStringSafe(json['zc']),
      zysx: asStringSafe(json['zysx']),
      zzjb: asStringSafe(json['zzjb']),
      exp: asIntSafe(json['exp']),
      usage: asStringSafe(json['usage']),
      component: asStringSafe(json['component']),
      brand: asStringSafe(json['brand']),
      barcode: asStringSafe(json['barcode']),
      source: asStringSafe(json['source']),
    );
  }

  /// 从离线条码库 `drug` 表的一行构造。
  ///
  /// 列 -> 字段 映射：name/spec/manu/pzwh/form 是识别类字段；
  /// ing/ind/dos/con/sto/usage 全部来自说明书官方原文，
  /// 分级管控要求这些字段只能取官方来源，AI 返回的同类内容必须丢弃。
  factory Medicine.fromDbRow(Map<String, dynamic> row) {
    final String ing = asStringSafe(row['ing']);
    return Medicine(
      id: asStringSafe(row['id']),
      drugName: asStringSafe(row['name']),
      brand: asStringSafe(row['alias']),
      barcode: asStringSafe(row['barcode']),
      ggxh: asStringSafe(row['spec']),
      manu: asStringSafe(row['manu']),
      pzwh: asStringSafe(row['pzwh']),
      type: asStringSafe(row['form']),
      syz: asStringSafe(row['ind']).isNotEmpty
          ? asStringSafe(row['ind'])
          : asStringSafe(row['indication']),
      component: ing,
      usage: asStringSafe(row['dos']),
      jj: asStringSafe(row['con']),
      zc: asStringSafe(row['sto']),
      source: 'codedb',
    );
  }

  /// 是否拥有至少一段说明书官方原文。
  /// 用于决定详情页是否展示「来源：药品说明书」以及 AI 是否可以介入补全。
  bool get hasOfficialInstruction =>
      component.isNotEmpty ||
      syz.isNotEmpty ||
      usage.isNotEmpty ||
      jj.isNotEmpty ||
      zc.isNotEmpty;

  /// 说明书是否标注了有效期说明。离线库基本不含该字段，
  /// 真实效期由用户在药匣里手填，两者不可混用。
  bool get isExpired => yxq.isNotEmpty;
}
