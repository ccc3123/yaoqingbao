import '../util/safe_cast.dart';

/// 个人健康档案（进入软件前的问卷）
///
/// **仅存本机**（SharedPreferences），不上传后端 —— 延续「数据最小化」隐私定位。
/// AI 服药助理据此做个性化用药评估；家庭共享的是药箱，健康档案仍按个人隔离
/// （每个成员的年龄/疾病史/身体状况不同）。
class UserProfile {
  final String name;

  /// 性别：男 / 女 / 其他
  final String gender;

  /// 出生年份（据此算年龄，避免每年需要更新）
  final int birthYear;

  /// 疾病史（多选 + 自定义），如：高血压、糖尿病
  final List<String> diseaseHistory;

  /// 当前身体状况描述，如：近期感冒、术后恢复
  final String condition;

  /// 过敏史 / 过敏药物，如：青霉素过敏
  final String allergies;

  UserProfile({
    this.name = '',
    this.gender = '',
    this.birthYear = 0,
    this.diseaseHistory = const [],
    this.condition = '',
    this.allergies = '',
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    final List<String> diseases = <String>[];
    final raw = json['diseaseHistory'];
    if (raw is List) {
      for (final e in raw) {
        final s = asStringSafe(e).trim();
        if (s.isNotEmpty) diseases.add(s);
      }
    }
    return UserProfile(
      name: asStringSafe(json['name']),
      gender: asStringSafe(json['gender']),
      birthYear: asIntSafe(json['birthYear']),
      diseaseHistory: diseases,
      condition: asStringSafe(json['condition']),
      allergies: asStringSafe(json['allergies']),
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'gender': gender,
        'birthYear': birthYear,
        'diseaseHistory': diseaseHistory,
        'condition': condition,
        'allergies': allergies,
      };

  /// 年龄（今年 - 出生年份）；未填返回 null
  int? get age {
    if (birthYear <= 0) return null;
    final y = DateTime.now().year;
    final a = y - birthYear;
    return a >= 0 && a < 150 ? a : null;
  }

  /// 是否已填写基本档案（姓名 + 性别 + 出生年份都填才算完成）
  bool get isCompleted =>
      name.trim().isNotEmpty && gender.trim().isNotEmpty && birthYear > 0;

  /// 生成给 AI 的结构化描述文本
  String toDescription() {
    final buf = StringBuffer();
    if (name.isNotEmpty) buf.write('姓名：$name');
    if (gender.isNotEmpty) buf.write('，性别：$gender');
    final a = age;
    if (a != null) buf.write('，年龄：$a 岁');
    if (diseaseHistory.isNotEmpty) {
      buf.write('，疾病史：${diseaseHistory.join('、')}');
    }
    if (condition.isNotEmpty) buf.write('，当前身体状况：$condition');
    if (allergies.isNotEmpty) buf.write('，过敏史：$allergies');
    return buf.toString();
  }

  UserProfile copyWith({
    String? name,
    String? gender,
    int? birthYear,
    List<String>? diseaseHistory,
    String? condition,
    String? allergies,
  }) =>
      UserProfile(
        name: name ?? this.name,
        gender: gender ?? this.gender,
        birthYear: birthYear ?? this.birthYear,
        diseaseHistory: diseaseHistory ?? this.diseaseHistory,
        condition: condition ?? this.condition,
        allergies: allergies ?? this.allergies,
      );
}
