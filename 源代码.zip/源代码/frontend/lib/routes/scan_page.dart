import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../util/http_utils.dart';
import '../util/scanner.dart';
import '../data/medicine.dart';
import 'app_routes.dart';
import 'home_page.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// Tab 1: 智能查药助手 — 搜索历史 + 扫码 + 科普卡片 + 回收点跳转
class ScanPage extends StatefulWidget {
  const ScanPage({super.key});
  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> with SingleTickerProviderStateMixin {
  final _searchController = TextEditingController();
  Medicine? _medicine;
  bool _loading = false;
  String? _error;
  late final AnimationController _pulseCtrl;
  List<String> _searchHistory = [];
  static const _historyKey = 'yaoqingbao_search_history';
  static const _maxHistory = 10;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000));
    _pulseCtrl.repeat(reverse: true);
    _loadHistory();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString(_historyKey);
    if (jsonStr != null) {
      setState(() => _searchHistory = List<String>.from(jsonDecode(jsonStr)));
    }
  }

  Future<void> _saveHistory(String keyword) async {
    _searchHistory.remove(keyword);
    _searchHistory.insert(0, keyword);
    if (_searchHistory.length > _maxHistory) {
      _searchHistory = _searchHistory.sublist(0, _maxHistory);
    }
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_historyKey, jsonEncode(_searchHistory));
    setState(() {});
  }

  Future<void> _clearHistory() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_historyKey);
    setState(() => _searchHistory = []);
  }

  Future<void> _scanBarcode() async {
    setState(() { _loading = true; _error = null; _medicine = null; });
    final code = await Scanner.scanBarcode();
    if (code.isEmpty) { setState(() { _loading = false; _error = '扫描取消'; }); return; }
    await _lookupCode(code);
  }

  Future<void> _lookupCode(String code) async {
    try {
      final resp = await HttpUtils().post('/med/CodeSearch?code=$code');
      if (resp.data['code'] == 200 && resp.data['data'] != null) {
        final med = Medicine.fromJson(resp.data['data']);
        _saveHistory(med.drugName);
        setState(() { _medicine = med; _loading = false; });
      } else {
        setState(() { _error = resp.data['msg'] ?? '未识别该条码，请尝试手动搜索'; _loading = false; });
      }
    } on DioException catch (e) {
      setState(() { _error = '网络错误: ${e.message}'; _loading = false; });
    }
  }

  void _showMedicineDetail(Medicine m) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _MedicineDetailSheet(medicine: m),
    );
  }

  void _goSearch(String kw) {
    if (kw.trim().isNotEmpty) {
      _saveHistory(kw.trim());
      AppRoutes.toSearch(context, kw.trim());
    }
  }

  /// 跳转到附近网点 Tab
  void _goToMapTab() {
    HomePage.homeKey.currentState?.switchToTab(2);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          // ── Hero 区域（品牌标识） ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primaryStrong, AppColors.primary],
                begin: Alignment.topLeft,
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
            ),
            child: Column(
              children: [
                // 品牌标识 — 简洁
                const Row(children: [
                  Icon(Icons.eco_rounded, color: Colors.white, size: 28),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('药清宝', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                      Text('让每一粒药都有归处', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ]),
                const SizedBox(height: 20),
                // 搜索框
                Container(
                  decoration: BoxDecoration(
                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.15), blurRadius: 12, offset: const Offset(0, 4))],
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: TextField(
                    controller: _searchController,
                    style: const TextStyle(fontSize: 15),
                    decoration: InputDecoration(
                      hintText: '输入药品名称或症状搜索',
                      hintStyle: TextStyle(color: AppColors.muted),
                      prefixIcon: const Icon(Icons.search, color: AppColors.primary),
                      suffixIcon: IconButton(
                        icon: const Icon(Icons.arrow_forward_ios, size: 18),
                        onPressed: () => _goSearch(_searchController.text),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    textInputAction: TextInputAction.search,
                    onSubmitted: _goSearch,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── 搜索历史 ──
          if (_searchHistory.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(children: [
                    Icon(Icons.history, size: 18, color: AppColors.ink),
                    SizedBox(width: 6),
                    Text('最近搜索', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.ink)),
                  ]),
                  GestureDetector(
                    onTap: _clearHistory,
                    child: const Text('清除历史', style: TextStyle(fontSize: 13, color: AppColors.muted)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _searchHistory.map((kw) => ActionChip(
                  avatar: const Icon(Icons.history, size: 14, color: AppColors.primary),
                  label: Text(kw, style: const TextStyle(fontSize: 13)),
                  backgroundColor: AppColors.primaryTintWeak,
                  side: const BorderSide(color: AppColors.primaryTint),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  onPressed: () => _goSearch(kw),
                )).toList(),
              ),
            ),
            const SizedBox(height: 20),
          ],

          // ── 扫码核心区 ──
          AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, child) {
              final scale = 1.0 + _pulseCtrl.value * 0.04;
              return Transform.scale(scale: scale, child: child);
            },
            child: GestureDetector(
              onTap: _scanBarcode,
              child: Container(
                width: 170,
                height: 170,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppColors.primaryTintWeak, AppColors.primaryTint],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withValues(alpha: 0.2),
                      blurRadius: 30,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8)],
                          ),
                        ),
                        const Icon(Icons.qr_code_scanner_rounded, size: 40, color: AppColors.primaryStrong),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Text('扫码识药', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.primaryStrong)),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(height: 10),
          Text('扫描药品包装条形码，自动识别药品信息', style: TextStyle(color: AppColors.ink3, fontSize: 13)),

          const SizedBox(height: 28),

          // ── 知识卡片 ──
          _sectionTitle('你知道吗', icon: Icons.lightbulb_outline),
          SizedBox(
            height: 150,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _knowledgeCard(Icons.inventory_2_outlined, '过期药品属于危险废物', '《国家危险废物名录(2021年版)》明确列入', AppColors.warningTint, AppColors.warning),
                _knowledgeCard(Icons.local_hospital_outlined, '全国共 131 家药店', '参与家庭过期药品回收公益活动', AppColors.primaryTintWeak, AppColors.primary),
                _knowledgeCard(Icons.water_outlined, '一粒药可污染', '数十吨水源，请勿冲入下水道', AppColors.infoTint, AppColors.info),
              ],
            ),
          ),

          const SizedBox(height: 28),

          // ── 结果区 ──
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(32),
              child: Column(children: [
                CircularProgressIndicator(color: AppColors.primary),
                SizedBox(height: 12),
                Text('正在识别药品...', style: TextStyle(color: AppColors.ink3)),
              ]),
            ),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: AppColors.warningTint, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.warningTint)),
                child: Row(children: [
                  const Icon(Icons.info_outline, color: AppColors.warning, size: 20),
                  const SizedBox(width: 10),
                  Expanded(child: Text(_error!, style: const TextStyle(color: AppColors.warning, fontSize: 14))),
                  TextButton(onPressed: () => _goSearch(_searchController.text.isNotEmpty ? _searchController.text : _error!.replaceAll('未识别该条码，请尝试手动搜索', '')), child: const Text('手动搜索', style: TextStyle(fontSize: 13))),
                ]),
              ),
            ),
          if (_medicine != null) ...[
            const SizedBox(height: 8),
            _medicineCard(_medicine!),
          ],

          // ── 免责声明 ──
          Container(
            margin: const EdgeInsets.fromLTRB(24, 20, 24, 40),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey[200]!),
            ),
            child: const Row(children: [
              Icon(Icons.info_outline, size: 18, color: AppColors.ink3),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  '本 App 仅提供信息查询和回收点指引\n不参与任何药品交易，回收请前往线下正规机构',
                  style: TextStyle(fontSize: 12, color: AppColors.muted),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title, {IconData? icon}) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
    child: Align(
      alignment: Alignment.centerLeft,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 18, color: AppColors.primary),
            const SizedBox(width: 6),
          ],
          Text(title, style: const TextStyle(fontSize: AppText.sizeTitle, fontWeight: FontWeight.w700, color: AppColors.ink)),
        ],
      ),
    ),
  );

  Widget _medicineCard(Medicine m) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Card(
      elevation: 3,
      shadowColor: AppColors.primary.withValues(alpha: 0.15),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => _showMedicineDetail(m),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [AppColors.primaryLight, AppColors.primary]),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: const Icon(Icons.medication, color: Colors.white),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(m.drugName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                      if (m.manu.isNotEmpty)
                        Text(m.manu, style: TextStyle(color: AppColors.ink3, fontSize: 13)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.primaryTintWeak,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text('详情 →', style: TextStyle(color: AppColors.primary, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ]),
              const SizedBox(height: 14),
              // 附近回收点按钮
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _goToMapTab,
                  icon: const Icon(Icons.location_on_outlined, size: 18),
                  label: const Text('查看附近回收点'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side: const BorderSide(color: AppColors.primaryTint),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );

  Widget _knowledgeCard(IconData icon, String title, String sub, Color bg, Color accent) => Container(
    width: 220,
    margin: const EdgeInsets.only(right: 12),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
    padding: const EdgeInsets.all(16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, size: 28, color: accent),
        const Spacer(),
        Text(title, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: accent)),
        const SizedBox(height: 4),
        Text(sub, style: TextStyle(fontSize: 12, color: accent.withValues(alpha: 0.7))),
      ],
    ),
  );
}

// ── 药品详情 BottomSheet ──
class _MedicineDetailSheet extends StatelessWidget {
  final Medicine medicine;
  const _MedicineDetailSheet({required this.medicine});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 44,
              height: 5,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Row(children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [AppColors.primaryLight, AppColors.primaryStrong]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.medication, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(medicine.drugName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                  if (medicine.manu.isNotEmpty)
                    Text(medicine.manu, style: TextStyle(color: AppColors.ink3, fontSize: 14)),
                ],
              ),
            ),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            if (medicine.type.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.primaryTintWeak,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(medicine.type, style: const TextStyle(fontSize: 12, color: AppColors.primary)),
              ),
            if (medicine.pzwh.isNotEmpty) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(medicine.pzwh, style: TextStyle(fontSize: AppText.sizeCaption, color: Colors.grey[600])),
              ),
            ],
          ]),
          const SizedBox(height: 20),
          _section('功能主治', medicine.syz),
          _section('禁忌', medicine.jj),
          _section('有效期', medicine.yxq),
          _section('贮藏', medicine.zc),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                HomePage.homeKey.currentState?.switchToTab(2);
              },
              icon: const Icon(Icons.location_on),
              label: const Text('去附近回收点'),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _section(String label, String content) {
    if (content.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.ink)),
          const SizedBox(height: 6),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.subtleBg,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(content, style: const TextStyle(fontSize: 14, color: AppColors.ink3, height: 1.6)),
          ),
        ],
      ),
    );
  }
}
