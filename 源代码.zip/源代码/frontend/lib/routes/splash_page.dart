import 'package:flutter/material.dart';
import 'app_routes.dart';
import '../theme/app_colors.dart';
import '../util/drug_db.dart';
import '../theme/app_text.dart';

/// 启动页 — 品牌展示
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double> _fade;
  late final Animation<double> _scale;

  /// 药品库初始化进度。null 表示无需展示（已完成或已跳过）。
  double? _dbProgress;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800));
    _fade = Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(
        parent: _ctrl, curve: const Interval(0.0, 0.6, curve: Curves.easeOut)));
    _scale = Tween(begin: 0.8, end: 1.0).animate(CurvedAnimation(
        parent: _ctrl,
        curve: const Interval(0.0, 0.4, curve: Curves.easeOutBack)));
    _ctrl.forward();
    // 离线药品库首次需要从 assets 释放 29MB 到私有目录。
    // 这里故意**不 await**：启动页仍是 2 秒到点无条件跳首页，
    // 未完成的部分由 DrugDb.ready 在每次查询前兜底等待。
    DrugDb.instance.init(onProgress: (p) {
      if (!mounted) return;
      setState(() {
        _dbProgress = p >= 1.0 ? null : p;
      });
    });
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) _goNext();
    });
  }

  // 启动后直接进入主页；健康档案是可选功能，可从个人中心补充，
  // 避免首次启动被问卷阻断核心的寻源/药匣/归处流程。
  Future<void> _goNext() async {
    if (!mounted) return;
    AppRoutes.toHome(context);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.primaryDeepest, AppColors.primaryDark, AppColors.primaryStrong],
          ),
        ),
        child: Center(
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, child) => Opacity(
              opacity: _fade.value,
              child: Transform.scale(
                scale: _scale.value,
                child: child,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: Image.asset('assets/images/app-icon.png',
                      width: 56, height: 56),
                ),
                const SizedBox(height: 24),
                const Text(
                  '药清宝',
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    letterSpacing: 6,
                  ),
                ),
                const SizedBox(height: 32),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    '零账户 · 零交易 · 纯公益',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.white.withValues(alpha: 0.4),
                      letterSpacing: 4,
                    ),
                  ),
                ),
                if (_dbProgress != null) ...[
                  const SizedBox(height: 22),
                  SizedBox(
                    width: 180,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(2),
                      child: LinearProgressIndicator(
                        value: _dbProgress,
                        minHeight: 3,
                        backgroundColor: Colors.white.withValues(alpha: 0.12),
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Colors.white.withValues(alpha: 0.55),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    '药品库初始化 ${(_dbProgress! * 100).toInt()}%',
                    style: TextStyle(
                      fontSize: AppText.sizeCaption,
                      color: Colors.white.withValues(alpha: 0.45),
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
