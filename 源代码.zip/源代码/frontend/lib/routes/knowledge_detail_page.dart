import 'package:flutter/material.dart';
import '../widgets/design_icons.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 科普文章详情页
class KnowledgeDetailPage extends StatelessWidget {
  final Map article;
  const KnowledgeDetailPage({super.key, required this.article});

  @override
  Widget build(BuildContext context) {
    final catLabels = {'policy': '政策法规', 'guide': '回收指南', 'science': '科普知识', 'news': '行业资讯'};
    final catColors = {'policy': AppSemantic.categoryPolicy, 'guide': AppSemantic.categoryGuide, 'science': AppSemantic.categoryScience, 'news': AppColors.warning};
    final cat = article['category'] as String? ?? '';
    final catLabel = catLabels[cat] ?? '';
    final catColor = catColors[cat] ?? AppColors.muted;
    final title = article['title'] ?? '';
    final summary = article['summary'] ?? '';
    final content = article['content'] ?? summary;
    final references = article['references'] ?? '';
    final publishTime = article['publishTime'] ?? '';
    final viewCount = article['viewCount'] ?? 0;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // 顶部渐变Header
          SliverAppBar(
            expandedHeight: 160,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppColors.primaryStrong, AppSemantic.categoryGuide], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 60, 24, 24),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(title, style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold), maxLines: 2, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 8),
                      Row(children: [
                        Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(6)), child: Text(catLabel, style: const TextStyle(color: Colors.white, fontSize: AppText.sizeCaption))),
                        const SizedBox(width: 12),
                        Text(publishTime.toString().substring(0, 10), style: TextStyle(color: Colors.white.withValues(alpha: 0.7), fontSize: 12)),
                        const SizedBox(width: 12),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Icon(Icons.visibility_outlined, size: 12, color: Colors.white.withValues(alpha: 0.7)),
                          const SizedBox(width: 3),
                          Text('$viewCount', style: TextStyle(color: Colors.white.withValues(alpha: 0.7), fontSize: 12)),
                        ]),
                      ]),
                    ]),
                  ),
                ),
              ),
            ),
          ),

          // 正文
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
              margin: const EdgeInsets.only(top: 0),
              padding: const EdgeInsets.all(28),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                // 摘要
                if (summary.isNotEmpty && content != summary)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.only(bottom: 24),
                    decoration: BoxDecoration(color: AppColors.primaryTintWeak, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.primaryTint)),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      DesignIcons.formatQuote(size: 24, color: AppSemantic.categoryGuide),
                      const SizedBox(width: 10),
                      Expanded(child: Text(summary, style: const TextStyle(fontSize: 15, color: AppColors.ink, height: 1.6, fontStyle: FontStyle.italic))),
                    ]),
                  ),

                // 正文内容
                Text(content, style: const TextStyle(fontSize: 16, color: AppColors.ink2, height: 1.9)),

                const SizedBox(height: 40),

                // 参考文献
                if (references.isNotEmpty) ...[
                  const Text('参考文献', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Container(width: 32, height: 3, decoration: BoxDecoration(color: catColor, borderRadius: BorderRadius.circular(2))),
                  const SizedBox(height: 14),
                  Text(references, style: TextStyle(fontSize: 13, color: AppColors.ink3, height: 1.6)),
                ],

                const SizedBox(height: 40),

                // 底部提示
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppColors.primaryTintWeak, borderRadius: BorderRadius.circular(14)),
                  child: Row(children: [
                    DesignIcons.info(size: 18, color: AppSemantic.categoryGuide),
                    SizedBox(width: 12),
                    Expanded(child: Text('本 App 仅提供信息参考，不构成医疗建议。\n药品回收请前往正规回收点，线下完成核验签收。', style: TextStyle(fontSize: 13, color: AppSemantic.categoryGuide))),
                  ]),
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
