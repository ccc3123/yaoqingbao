import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import '../util/http_utils.dart';
import 'dart:convert';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// Tab 3: 找网点 — 一键唤起外部地图 + 定位兜底 + 城市选择 + 列表
class MapPage extends StatefulWidget {
  const MapPage({super.key});
  @override
  State<MapPage> createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  List _stations = [];
  bool _loading = false;
  bool _locating = true;
  String _statusText = '';
  Position? _position;
  String _radius = '3000';
  String _selectedCity = '';

  static const _cities = [
    '北京', '上海', '广州', '深圳',
    '成都', '杭州', '武汉', '南京',
    '西安', '重庆', '天津', '苏州',
    '长沙', '郑州', '青岛', '大连',
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryLocate());
  }

  Future<void> _tryLocate() async {
    setState(() { _locating = true; _statusText = '正在定位...'; });
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      ).timeout(const Duration(seconds: 3));
      setState(() { _position = pos; _locating = false; _statusText = ''; });
      await _searchNearby(pos.latitude, pos.longitude);
    } catch (_) {
      setState(() {
        _locating = false;
        _statusText = 'GPS 定位失败，请手动选择城市';
        _selectedCity = '北京';
      });
      if (_selectedCity.isNotEmpty) {
        await _searchByCity(_selectedCity);
      }
    }
  }

  Future<void> _searchNearby(double lat, double lng) async {
    setState(() => _loading = true);
    try {
      final resp = await HttpUtils().get('/position', params: {
        'latitude': lat.toString(),
        'longitude': lng.toString(),
        'radius': int.parse(_radius),
      });
      if (resp.data['code'] == 200 && resp.data['data'] != null) {
        try {
          final json = jsonDecode(resp.data['data']);
          setState(() {
            _stations = (json['data'] as List?) ?? [];
            _loading = false;
          });
        } catch (_) {
          setState(() { _stations = []; _loading = false; });
        }
      } else {
        setState(() { _stations = []; _loading = false; });
      }
    } on DioException {
      setState(() { _stations = []; _loading = false; _statusText = '网络错误，请下拉刷新重试'; });
    }
  }

  Future<void> _searchByCity(String city) async {
    setState(() { _loading = true; _statusText = '搜索 $city 的回收点...'; });
    try {
      final resp = await HttpUtils().get('/position/detail', params: {
        'keyword': '药品回收点 $city',
      });
      if (resp.data['code'] == 200 && resp.data['data'] != null) {
        try {
          final json = jsonDecode(resp.data['data']);
          setState(() {
            _stations = (json['data'] as List?) ?? [];
            _loading = false;
            _statusText = _stations.isEmpty ? '$city 暂无回收点数据' : '';
          });
        } catch (_) {
          setState(() { _stations = []; _loading = false; _statusText = ''; });
        }
      } else {
        setState(() { _stations = []; _loading = false; _statusText = '$city 暂无回收点数据'; });
      }
    } on DioException {
      setState(() { _stations = []; _loading = false; _statusText = '网络错误'; });
    }
  }

  Future<void> _openExternalMap({String? keyword}) async {
    final searchKeyword = keyword ?? '药品回收点';
    final urls = [
      {
        'name': '高德地图',
        'url': 'https://uri.amap.com/search?keyword=${Uri.encodeComponent(searchKeyword)}&callnative=1',
      },
      {
        'name': '百度地图',
        'url': 'baidumap://map/search?query=${Uri.encodeComponent(searchKeyword)}',
      },
      {
        'name': '腾讯地图',
        'url': 'qqmap://map/search?keyword=${Uri.encodeComponent(searchKeyword)}',
      },
    ];
    for (final map in urls) {
      final uri = Uri.parse(map['url'] as String);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        return;
      }
    }
    if (mounted) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Text('未安装地图 App'),
          content: const Text('请安装高德地图、百度地图或腾讯地图后重试。'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
          ],
        ),
      );
    }
  }

  Future<void> _navigateTo(double lat, double lng, String name) async {
    final uri = Uri.parse(
      'https://uri.amap.com/marker?position=$lng,$lat&name=${Uri.encodeComponent(name)}&callnative=1',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('请安装地图 App 进行导航')),
        );
      }
    }
  }

  IconData _typeIcon(String? tel, String? title) {
    final t = (title ?? '') + (tel ?? '');
    if (t.contains('医院')) return Icons.local_hospital;
    if (t.contains('社区') || t.contains('卫生')) return Icons.home_work;
    if (t.contains('慈善') || t.contains('红会')) return Icons.volunteer_activism;
    return Icons.medication;
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: () async {
        if (_position != null) {
          await _searchNearby(_position!.latitude, _position!.longitude);
        } else if (_selectedCity.isNotEmpty) {
          await _searchByCity(_selectedCity);
        } else {
          await _tryLocate();
        }
      },
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── 一键唤起外部地图卡片 ──
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.info, AppColors.infoLight],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppColors.info.withValues(alpha: 0.3),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(20),
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => _openExternalMap(),
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(children: [
                    Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(Icons.map_rounded, color: Colors.white, size: 30),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '打开地图 App 查找回收点',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            '一键跳转高德/百度/腾讯地图，自动搜索附近回收点',
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: const Text(
                        '打开 →',
                        style: TextStyle(
                          color: AppColors.info,
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ]),
                ),
              ),
            ),
          ),

          const SizedBox(height: 20),

          // ── 定位状态 ──
          if (_locating)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.primaryTintWeak,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(children: [
                const SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary),
                ),
                const SizedBox(width: 12),
                const Text('正在获取位置...', style: TextStyle(color: AppColors.primary, fontSize: 14)),
                const Spacer(),
                TextButton(
                  onPressed: () {
                    setState(() { _locating = false; _selectedCity = '北京'; });
                    _searchByCity('北京');
                  },
                  child: const Text('跳过', style: TextStyle(fontSize: 13)),
                ),
              ]),
            ),

          // ── 定位成功 → 半径调节 ──
          if (!_locating && _position != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.primaryTintWeak,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(children: [
                const Icon(Icons.tune, size: 18, color: AppColors.primary),
                const SizedBox(width: 8),
                const Text('搜索范围：', style: TextStyle(fontSize: 13, color: AppColors.primary)),
                for (final r in [['1km', '1000'], ['3km', '3000'], ['5km', '5000']])
                  Padding(
                    padding: const EdgeInsets.only(left: 6),
                    child: ChoiceChip(
                      selected: _radius == r[1],
                      label: Text(r[0], style: const TextStyle(fontSize: 12)),
                      selectedColor: AppColors.primary,
                      labelStyle: TextStyle(
                        color: _radius == r[1] ? Colors.white : Colors.grey[700],
                      ),
                      onSelected: (_) {
                        setState(() => _radius = r[1]);
                        if (_position != null) {
                          _searchNearby(_position!.latitude, _position!.longitude);
                        }
                      },
                      padding: EdgeInsets.zero,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                  ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _openExternalMap(),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: AppColors.info,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text('地图查看', style: TextStyle(color: Colors.white, fontSize: AppText.sizeCaption)),
                  ),
                ),
              ]),
            ),

          // ── 定位失败 → 城市选择器 ──
          if (!_locating && _position == null)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.warningTint,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.warningTint),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.gps_off, color: AppColors.warning, size: 18),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'GPS 定位失败，请选择所在城市',
                        style: TextStyle(color: AppColors.warning, fontSize: 14, fontWeight: FontWeight.w500),
                      ),
                    ),
                    GestureDetector(
                      onTap: _tryLocate,
                      child: const Icon(Icons.refresh, color: AppColors.warning, size: 20),
                    ),
                  ]),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: _cities.map((city) {
                      final selected = _selectedCity == city;
                      return GestureDetector(
                        onTap: () {
                          setState(() => _selectedCity = city);
                          _searchByCity(city);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: selected ? AppColors.primary : Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: selected ? AppColors.primary : AppColors.divider,
                            ),
                          ),
                          child: Text(
                            city,
                            style: TextStyle(
                              fontSize: 13,
                              fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                              color: selected ? Colors.white : AppColors.ink3,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),

          const SizedBox(height: 16),

          // ── 状态提示 ──
          if (_statusText.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                _statusText,
                style: TextStyle(color: AppColors.ink3, fontSize: 13),
                textAlign: TextAlign.center,
              ),
            ),

          // ── Loading ──
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(40),
              child: Center(child: CircularProgressIndicator(color: AppColors.primary)),
            ),

          // ── 空状态 ──
          if (!_loading && _stations.isEmpty && !_locating)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Column(children: [
                  Icon(Icons.location_off, size: 64, color: Colors.grey[400]),
                  const SizedBox(height: 12),
                  Text(
                    _position == null && _selectedCity.isEmpty
                        ? '请选择城市或打开地图搜索'
                        : '暂无回收点数据',
                    style: TextStyle(fontSize: 16, color: AppColors.ink3),
                  ),
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () => _openExternalMap(),
                    icon: const Icon(Icons.map_outlined),
                    label: const Text('在外置地图中搜索'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.info,
                      side: const BorderSide(color: AppColors.info),
                    ),
                  ),
                ]),
              ),
            ),

          // ── 列表项 ──
          ..._stations.map((s) {
            final title = s['title'] ?? '回收点';
            final address = s['address'] ?? '';
            final distance = (s['_distance'] is num) ? (s['_distance'] as num).toDouble() : 0.0;
            final lat = (s['location']?['lat'] ?? 0.0).toDouble();
            final lng = (s['location']?['lng'] ?? 0.0).toDouble();
            final km = (distance / 1000).toStringAsFixed(1);
            final tel = (s['tel'] ?? '').toString();

            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)],
              ),
              child: Material(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _showDetail(s),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(children: [
                      Container(
                        width: 48, height: 48,
                        decoration: BoxDecoration(
                          color: AppColors.primaryTintWeak,
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: Center(child: Icon(_typeIcon(tel, title), size: 24, color: AppColors.primary)),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 4),
                            Text(address, style: TextStyle(fontSize: 13, color: AppColors.ink3), maxLines: 2, overflow: TextOverflow.ellipsis),
                            if (tel.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Text(tel, style: TextStyle(fontSize: 12, color: AppColors.muted)),
                              ),
                          ],
                        ),
                      ),
                      Column(children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primaryTintWeak,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text('${km}km', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.primary)),
                        ),
                        const SizedBox(height: 8),
                        GestureDetector(
                          onTap: () => _navigateTo(lat, lng, title),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.navigation_rounded, color: Colors.white, size: 18),
                          ),
                        ),
                      ]),
                    ]),
                  ),
                ),
              ),
            );
          }),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  void _showDetail(Map s) {
    final lat = (s['location']?['lat'] ?? 0.0).toDouble();
    final lng = (s['location']?['lng'] ?? 0.0).toDouble();
    final title = s['title'] ?? '';
    final address = s['address'] ?? '';
    final tel = (s['tel'] ?? '').toString();
    final distance = (s['_distance'] is num) ? (s['_distance'] as num).toDouble() : 0.0;

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 44, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(3)))),
          const SizedBox(height: 20),
          Row(children: [
            Container(width: 56, height: 56, decoration: BoxDecoration(color: AppColors.primaryTintWeak, borderRadius: BorderRadius.circular(16)), child: Center(child: Icon(_typeIcon(tel, title), size: 28, color: AppColors.primary))),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
              Text('${(distance / 1000).toStringAsFixed(1)} 公里', style: TextStyle(color: AppColors.ink3, fontSize: 14)),
            ])),
          ]),
          const SizedBox(height: 20),
          _detailRow(Icons.location_on_outlined, address),
          if (tel.isNotEmpty) _detailRow(Icons.phone_outlined, tel),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => _navigateTo(lat, lng, title),
              icon: const Icon(Icons.navigation_rounded),
              label: const Text('开始导航'),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _detailRow(IconData icon, String text) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(children: [
      Icon(icon, size: 18, color: AppColors.ink3),
      const SizedBox(width: 10),
      Expanded(child: Text(text, style: const TextStyle(fontSize: 14, color: AppColors.ink3))),
    ]),
  );
}
