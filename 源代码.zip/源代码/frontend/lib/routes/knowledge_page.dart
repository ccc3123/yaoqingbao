import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import '../util/http_utils.dart';
import '../widgets/design_icons.dart';
import '../widgets/app_background.dart';
import 'app_routes.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// Tab 4: 学知识 — 分类Tab + 专题卡片 + 文章列表
class KnowledgePage extends StatefulWidget {
  const KnowledgePage({super.key});
  @override
  State<KnowledgePage> createState() => _KnowledgePageState();
}

class _KnowledgePageState extends State<KnowledgePage> {
  List _articles = [];
  bool _loading = true;
  String? _selectedCategory;
  final _scrollCtrl = ScrollController();

  List<Map<String, dynamic>> _categories = [];

  static const _featuredTopics = [
    {'icon': Icons.home_rounded, 'title': '家庭过期药品\n处理指南', 'color': AppSemantic.categoryGuide, 'category': 'guide'},
    {'icon': Icons.card_giftcard_rounded, 'title': '药品捐赠\n条件与流程', 'color': AppColors.info, 'category': 'guide'},
    {'icon': Icons.balance_rounded, 'title': '国家药品回收\n政策解读', 'color': AppColors.warning, 'category': 'policy'},
    {'icon': Icons.public_rounded, 'title': '药品污染\n环境危害', 'color': AppSemantic.categoryScience, 'category': 'science'},
  ];

  @override
  void initState() {
    super.initState();
    _initCategories();
    _loadArticles();
  }

  void _initCategories() {
    _categories = [
      {'label': '全部', 'value': null, 'icon': DesignIcons.menuBook(size: 18)},
      {'label': '政策法规', 'value': 'policy', 'icon': DesignIcons.info(size: 18, color: AppSemantic.categoryPolicy)},
      {'label': '回收指南', 'value': 'guide', 'icon': DesignIcons.recycling(size: 18, color: AppSemantic.categoryGuide)},
      {'label': '科普知识', 'value': 'science', 'icon': DesignIcons.lightbulb(size: 18, color: AppSemantic.categoryScience)},
      {'label': '行业资讯', 'value': 'news', 'icon': DesignIcons.chevronRight(size: 18, color: AppColors.warning)},
    ];
  }

  @override
  void dispose() { _scrollCtrl.dispose(); super.dispose(); }

  Future<void> _loadArticles() async {
    setState(() => _loading = true);
    try {
      final params = _selectedCategory != null ? <String, dynamic>{'category': _selectedCategory} : null;
      final resp = await HttpUtils().get('/knowledge/list', params: params);
      if (resp.data['code'] == 200) {
        setState(() { _articles = resp.data['data'] ?? []; _loading = false; });
      } else {
        setState(() => _loading = false);
      }
    } on DioException {
      setState(() { _articles = _fallbackArticles(); _loading = false; });
    }
  }

  List _fallbackArticles() => [
    {'id': 1, 'title': '家庭过期药品的正确处理方式', 'summary': '过期药品属于危险废物，不可随意丢弃。本文详细介绍科学的家庭药品处置方法。', 'category': 'guide', 'viewCount': 1280, 'publishTime': '2026-06-20 10:00'},
    {'id': 2, 'title': '国家药品回收政策解读（2021-2025）', 'summary': '梳理近年来国家层面出台的药品回收相关政策法规，了解政策导向。', 'category': 'policy', 'viewCount': 960, 'publishTime': '2026-06-18 14:30'},
    {'id': 3, 'title': '哪些药品可以捐赠再利用？', 'summary': '并非所有药品都适合捐赠。了解可捐赠药品的条件和完整流程。', 'category': 'guide', 'viewCount': 840, 'publishTime': '2026-06-15 09:00'},
    {'id': 4, 'title': '过期药品对环境的危害有多大？', 'summary': '一粒过期药品可能污染数十吨水源，了解药品不当处置的环境代价。', 'category': 'science', 'viewCount': 720, 'publishTime': '2026-06-10 16:20'},
    {'id': 5, 'title': '京东买药回收：家中过期药以旧换新', 'summary': '京东健康推出家庭过期药品回收服务，覆盖全国多个城市。', 'category': 'news', 'viewCount': 650, 'publishTime': '2026-06-08 11:00'},
  ];

  String _catLabel(String? cat) {
    const map = {'policy': '政策法规', 'guide': '回收指南', 'science': '科普知识', 'news': '行业资讯'};
    return map[cat] ?? cat ?? '';
  }

  Color _catColor(String? cat) {
    const map = {'policy': AppSemantic.categoryPolicy, 'guide': AppSemantic.categoryGuide, 'science': AppSemantic.categoryScience, 'news': AppColors.warning};
    return map[cat] ?? AppColors.muted;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('回收知识'),
        flexibleSpace: Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppColors.primaryStrong, AppSemantic.categoryGuide]))),
      ),
      body: AppBackground(
        overlayColor: Colors.white,
        overlayOpacity: 0.15,
        child: Column(
          children: [
        // 分类滑动Tab
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: _categories.map((c) {
                final selected = c['value'] == _selectedCategory;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    selected: selected,
                    label: Text(c['label'] as String, style: TextStyle(fontSize: 13, fontWeight: selected ? FontWeight.w600 : FontWeight.normal)),
                    selectedColor: AppColors.primaryTintWeak,
                    labelStyle: TextStyle(color: selected ? AppColors.primaryStrong : Colors.grey[600]),
                    avatar: c['icon'] as Widget,
                    onSelected: (_) { setState(() => _selectedCategory = c['value'] as String?); _loadArticles(); },
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  ),
                );
              }).toList(),
            ),
          ),
        ),

        // 专题卡片
        if (_selectedCategory == null) ...[
          const SizedBox(height: 12),
          SizedBox(
            height: 120,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: _featuredTopics.map((t) => Container(
                width: 150,
                margin: const EdgeInsets.only(right: 12),
                child: Material(
                  color: (t['color'] as Color).withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(20),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () {
                      final cat = t['category'] as String?;
                      if (cat != null) {
                        setState(() => _selectedCategory = cat);
                        _loadArticles();
                      }
                    },
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Icon(t['icon'] as IconData, size: 28, color: t['color'] as Color),
                        const Spacer(),
                        Text(t['title'] as String, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: t['color'] as Color)),
                      ]),
                    ),
                  ),
                ),
              )).toList(),
            ),
          ),
        ],

        const SizedBox(height: 8),

        // 文章列表
        Expanded(
          child: _loading
              ? ListView.builder(padding: const EdgeInsets.all(16), itemCount: 4, itemBuilder: (_, i) => _shimmerCard())
              : _articles.isEmpty
                  ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      DesignIcons.menuBook(size: 64, color: Colors.grey[400]!),
                      const SizedBox(height: 12),
                      Text('暂无文章', style: TextStyle(color: AppColors.ink3, fontSize: 16)),
                    ]))
                  : RefreshIndicator(
                      color: AppSemantic.categoryGuide,
                      onRefresh: _loadArticles,
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        itemCount: _articles.length,
                        itemBuilder: (ctx, i) {
                        final a = _articles[i];
                        final cat = a['category'] as String?;
                        final catLabel = _catLabel(cat);
                        final catColor = _catColor(cat);

                        return Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)]),
                          child: Material(
                            color: Colors.transparent,
                            borderRadius: BorderRadius.circular(18),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(18),
                              onTap: () => AppRoutes.toKnowledgeDetail(context, a),
                              child: Padding(
                                padding: const EdgeInsets.all(18),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: catColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(8)), child: Text(catLabel, style: TextStyle(fontSize: AppText.sizeCaption, color: catColor, fontWeight: FontWeight.w600))),
                                  const SizedBox(height: 10),
                                  Text(a['title'] ?? '', style: const TextStyle(fontSize: AppText.sizeTitle, fontWeight: FontWeight.w600, height: 1.4)),
                                  const SizedBox(height: 8),
                                  Text(a['summary'] ?? '', style: TextStyle(fontSize: 13, color: AppColors.ink3, height: 1.5), maxLines: 2, overflow: TextOverflow.ellipsis),
                                  const SizedBox(height: 12),
                                  Row(children: [
                                    DesignIcons.info(size: 14, color: AppColors.muted),
                                    const SizedBox(width: 4),
                                    Text('${a['viewCount'] ?? 0}', style: TextStyle(fontSize: 12, color: AppColors.muted)),
                                    const SizedBox(width: 16),
                                    DesignIcons.history(size: 14, color: AppColors.muted),
                                    const SizedBox(width: 4),
                                    Text((a['publishTime'] ?? '').toString().substring(0, 10), style: TextStyle(fontSize: 12, color: AppColors.muted)),
                                    const Spacer(),
                                    Text('阅读 →', style: TextStyle(fontSize: 12, color: catColor)),
                                  ]),
                                ]),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
        ),
      ],
        ),
      ),
    );
  }

  Widget _shimmerCard() => Container(
    height: 140,
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(width: 60, height: 22, decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(8))),
        const SizedBox(height: 12),
        Container(width: double.infinity, height: 18, decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(4))),
        const SizedBox(height: 8),
        Container(width: 200, height: 14, decoration: BoxDecoration(color: Colors.grey[50], borderRadius: BorderRadius.circular(4))),
        const SizedBox(height: 8),
        Container(width: 260, height: 14, decoration: BoxDecoration(color: Colors.grey[50], borderRadius: BorderRadius.circular(4))),
        const SizedBox(height: 12),
        Container(width: 100, height: 12, decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(4))),
      ]),
    ),
  );
}
