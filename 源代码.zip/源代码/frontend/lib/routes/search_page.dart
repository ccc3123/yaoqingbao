import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../util/drug_search_service.dart';
import '../util/zhipu_service.dart';
import '../util/drug_qa_service.dart';
import '../widgets/design_icons.dart';
import '../widgets/app_background.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 药品搜索结果列表页（内置库首屏 → 免费开放接口 → AI 降级）
///
/// 首屏不再等待后端慢查询：先用打包内置的常见药品库渲染，
/// 再异步请求免费药品查询开放接口补全，全部失败才走 AI，
/// 每级都有加载态与超时兜底，不会出现界面长时间卡死。
class SearchPage extends StatefulWidget {
  final String keyword;
  const SearchPage({super.key, required this.keyword});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  List _drugs = [];
  bool _loading = true;
  bool _aiLoading = false;
  /// 本地库已出结果、正在向免费接口请求更全数据
  bool _refreshing = false;
  /// 降级提示文案（接口超时/不可用/无结果时展示，不抛异常）
  String? _notice;
  Map<String, dynamic>? _aiResult;
  String? _error;

  @override
  void initState() {
    super.initState();
    _search();
  }

  /// 三级检索：内置库（毫秒级）→ 免费开放接口（4s 超时）→ AI
  Future<void> _search() async {
    setState(() {
      _loading = true;
      _aiResult = null;
      _error = null;
      _notice = null;
      _refreshing = false;
      _drugs = [];
    });

    // 第一级：内置常见药品库，先保证首屏立刻有内容
    await DrugSearchService().loadLocal();
    final local = DrugSearchService().searchLocal(widget.keyword);
    if (!mounted) return;
    if (local.isNotEmpty) {
      setState(() {
        _drugs = local;
        _loading = false;
        _refreshing = true;
      });
    }

    // 第二级：免费药品查询开放接口，带超时兜底
    final outcome = await DrugSearchService().searchRemote(widget.keyword);
    if (!mounted) return;
    setState(() => _refreshing = false);

    if (outcome.items.isNotEmpty) {
      setState(() {
        _drugs = outcome.items;
        _loading = false;
        _notice = null;
      });
      return;
    }

    if (_drugs.isNotEmpty) {
      // 已用内置库渲染，接口只是没补全，提示但不打断
      setState(() => _notice = outcome.reason ?? '药品查询服务暂时不可用，当前展示内置药品库结果');
      return;
    }

    // 第三级：AI 智能识别兜底
    await _tryAI(notice: outcome.reason ?? '未查询到「${widget.keyword}」相关的药品信息');
  }

  Future<void> _tryAI({String? notice}) async {
    setState(() {
      _loading = false;
      _aiLoading = true;
      _error = null;
      if (notice != null) _notice = notice;
    });
    final result = await ZhipuService().searchDrugByName(widget.keyword);
    if (!mounted) return;
    if (result != null && (result['drugName'] ?? '').toString().isNotEmpty) {
      setState(() { _aiLoading = false; _aiResult = result; });
    } else {
      setState(() { _aiLoading = false; _error = '未找到「${widget.keyword}」相关信息，可尝试更换关键词'; });
    }
  }

  /// 顶部状态条：加载中 / 降级提示
  Widget? _statusBanner() {
    if (_refreshing) {
      return _banner('正在从药品数据库获取更全的结果…', loading: true);
    }
    if (_notice != null && _drugs.isNotEmpty) {
      return _banner(_notice!);
    }
    return null;
  }

  Widget _banner(String text, {bool loading = false}) => Container(
        margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: loading ? AppColors.primaryTintWeak : AppColors.warningTint,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: loading ? AppColors.primaryTint : AppColors.warningTint),
        ),
        child: Row(children: [
          loading
              ? const SizedBox(
                  width: 16, height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primary))
              : const Icon(Icons.info_outline, size: 16, color: AppColors.warning),
          const SizedBox(width: 10),
          Expanded(
              child: Text(text,
                  style: TextStyle(
                      fontSize: 12,
                      color: loading ? AppColors.primaryStrong : AppSemantic.sourceLocal))),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('搜索: ${widget.keyword}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.chat_bubble_outline, color: Colors.white),
            tooltip: '问药',
            onPressed: _showQaDialog,
          ),
        ],
        flexibleSpace: Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [AppColors.primaryStrong, AppColors.primary]))),
      ),
      body: AppBackground(
        overlayColor: Colors.white,
        overlayOpacity: 0.15,
        child: _loading
          ? ListView.builder(padding: const EdgeInsets.all(16), itemCount: 5, itemBuilder: (_, __) => _shimmerCard())
          : _aiLoading
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const SizedBox(width: 44, height: 44, child: CircularProgressIndicator(strokeWidth: 3, color: AppSemantic.ai)),
                      const SizedBox(height: 20),
                      Text('AI 查询「${widget.keyword}」…', style: const TextStyle(fontSize: 15, color: AppColors.ink3)),
                      const SizedBox(height: 6),
                      const Text('数据库维护中，已切换智能查询', style: TextStyle(fontSize: 13, color: AppColors.muted)),
                    ]),
                  ),
                )
              : _aiResult != null
                  ? _aiPage()
                  : _drugs.isNotEmpty
                      ? RefreshIndicator(
                          color: AppColors.primary,
                          onRefresh: _search,
                          child: ListView.builder(
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                            itemCount: _drugs.length + (_statusBanner() != null ? 1 : 0),
                            itemBuilder: (_, i) {
                              final banner = _statusBanner();
                              final offset = banner == null ? 0 : 1;
                              if (banner != null && i == 0) return banner;
                              final d = _drugs[i - offset];
                              final name = (d['drugName'] ?? '未知药品').toString();
                              final manu = (d['manu'] ?? '').toString();
                              final spec = (d['ggxh'] ?? '').toString();
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(18),
                                    boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)],
                                  ),
                                  child: Material(
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(18),
                                    child: InkWell(
                                      borderRadius: BorderRadius.circular(18),
                                      onTap: () {
                                        HapticFeedback.lightImpact();
                                        _showDetail(d);
                                      },
                                      child: Padding(
                                        padding: const EdgeInsets.all(16),
                                        child: Row(children: [
                                          Container(
                                            width: 48, height: 48,
                                            decoration: BoxDecoration(
                                              gradient: const LinearGradient(colors: [AppColors.primaryLight, AppColors.primary]),
                                              borderRadius: BorderRadius.circular(14),
                                            ),
                                            child: DesignIcons.medication(size: 24, color: Colors.white),
                                          ),
                                          const SizedBox(width: 14),
                                          Expanded(
                                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                              Text(name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                                              if (manu.isNotEmpty) Text(manu, style: TextStyle(fontSize: 13, color: AppColors.ink3)),
                                              const SizedBox(height: 4),
                                              Row(children: [
                                                if (spec.isNotEmpty)
                                                  Flexible(
                                                    child: Text('规格 $spec',
                                                        style: const TextStyle(fontSize: 12, color: AppColors.primary),
                                                        overflow: TextOverflow.ellipsis),
                                                  ),
                                                if (spec.isNotEmpty) const SizedBox(width: 8),
                                                _sourceChip((d['source'] ?? '').toString()),
                                              ]),
                                            ]),
                                          ),
                                          DesignIcons.chevronRight(size: 18, color: AppColors.ink3),
                                        ]),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        )
                      : Center(
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            DesignIcons.searchOff(size: 56, color: Colors.grey[400]!),
                            const SizedBox(height: 12),
                            Text(_error ?? _notice ?? '未找到「${widget.keyword}」',
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 15, color: AppColors.ink3)),
                            const SizedBox(height: 8),
                            const Text('试试其他关键词搜索', style: TextStyle(fontSize: 13, color: AppColors.muted)),
                            const SizedBox(height: 20),
                            OutlinedButton.icon(
                              onPressed: () => _tryAI(),
                              icon: DesignIcons.autoAwesome(size: 16, color: AppSemantic.ai),
                              label: const Text('AI 智能查询', style: TextStyle(color: AppSemantic.ai)),
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: AppSemantic.ai),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                            ),
                          ]),
                        ),
      ),
    );
  }

  /// 数据来源标记，让用户知道结果来自内置库还是接口
  Widget _sourceChip(String source) {
    final text = source == 'local' ? '内置药品库' : source == 'free' ? '药品数据库' : '';
    if (text.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.primaryTintWeak,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.primaryTint),
      ),
      child: Text(text, style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.primary)),
    );
  }

  Widget _aiPage() {
    final r = _aiResult!;
    final name = (r['drugName'] ?? '').toString();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(color: AppSemantic.ai.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(10)),
              child: DesignIcons.autoAwesome(size: 17, color: AppSemantic.ai),
            ),
            const SizedBox(width: 12),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('AI 智能查询', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.ink)),
              Text('智谱 GLM · 数据库维护中', style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
            ])),
          ]),
          const SizedBox(height: 16),
          if (name.isNotEmpty && name != '未知')
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.subtleBg, borderRadius: BorderRadius.circular(12)),
              child: Row(children: [
                DesignIcons.medication(size: 18, color: AppColors.primary),
                const SizedBox(width: 10),
                Expanded(child: Text(name, style: const TextStyle(fontSize: AppText.sizeTitle, fontWeight: FontWeight.w700, color: AppColors.ink))),
              ]),
            ),
          const SizedBox(height: 12),
          ...[
              [Icons.factory_outlined, '企业', r['manu']],
              [Icons.category_outlined, '分类', r['type']],
              [Icons.numbers_outlined, '批号', r['pzwh']],
              [Icons.medication_outlined, '主治', r['syz']],
              [Icons.warning_amber_outlined, '禁忌', r['jj']],
              [Icons.event_outlined, '效期', r['yxq']],
              [Icons.thermostat_outlined, '贮藏', r['zc']],
            ]
            .where((e) => (e[2] ?? '').toString().isNotEmpty)
            .map((e) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(e[0] as IconData, size: 16, color: AppColors.ink3),
                  const SizedBox(width: 6),
                  Expanded(child: Text('${e[1]}：${e[2]}', style: const TextStyle(fontSize: 14, color: AppColors.ink3, height: 1.6))),
                ],
              ),
            )),
        ]),
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => _tryAI(),
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('重新查询', style: TextStyle(fontSize: 13)),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppSemantic.ai,
              side: const BorderSide(color: AppSemantic.ai),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.search, size: 16),
            label: const Text('返回重搜', style: TextStyle(fontSize: 13)),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.ink3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ),
      ]),
    ]);
  }

  /// 问药入口：输入自然语言问题 → RAG 检索本地库 → LLM 组织回答。
  Future<void> _showQaDialog() async {
    final ctrl = TextEditingController(text: widget.keyword);
    final question = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('问药'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: '如：阿莫西林有什么禁忌？',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text),
            style: FilledButton.styleFrom(backgroundColor: AppColors.primary),
            child: const Text('提问'),
          ),
        ],
      ),
    );
    if (question == null || question.trim().isEmpty || !mounted) return;

    final messenger = ScaffoldMessenger.of(context);
    messenger.showSnackBar(const SnackBar(content: Text('正在查询药品知识…'), duration: Duration(seconds: 30)));
    final answer = await DrugQaService().answer(question.trim());
    if (!mounted) return;
    messenger.hideCurrentSnackBar();
    _showQaAnswer(answer);
  }

  /// 展示问药回答。
  void _showQaAnswer(DrugQaAnswer answer) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40, height: 4,
                  decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
                ),
              ),
              const SizedBox(height: 14),
              Row(children: [
                const Icon(Icons.chat_bubble_outline, size: 20, color: AppColors.primary),
                const SizedBox(width: 8),
                const Expanded(child: Text('问药', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
                IconButton(icon: const Icon(Icons.close, size: 20), onPressed: () => Navigator.pop(ctx)),
              ]),
              const SizedBox(height: 6),
              // 来源标记：本地拦截/降级 vs AI 组织
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: answer.fromAi ? AppColors.primaryTintWeak : AppColors.warningTint,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  answer.fromAi ? 'AI 参考 · 仅引用官方说明书' : '本地安全拦截 / 降级',
                  style: TextStyle(fontSize: AppText.sizeCaption, color: answer.fromAi ? AppColors.primary : AppSemantic.sourceLocal),
                ),
              ),
              const SizedBox(height: 12),
              Text(answer.answer, style: const TextStyle(fontSize: 14, height: 1.6, color: AppColors.ink)),
              if (answer.drugNames.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text('涉及药品：${answer.drugNames.join('、')}',
                    style: const TextStyle(fontSize: 12, color: AppColors.primary)),
              ],
              const SizedBox(height: 12),
              const Text('用药安全提示：适应症/用法/禁忌等以药品官方说明书为准',
                  style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
            ],
          ),
        ),
      ),
    );
  }

  void _showDetail(Map d) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Center(child: Container(width: 44, height: 5, decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(3)))),
          const SizedBox(height: 20),
          Text(d['drugName'] ?? '', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
          if ((d['manu'] ?? '').toString().isNotEmpty) Text(d['manu'], style: TextStyle(color: AppColors.ink3, fontSize: 14)),
          const SizedBox(height: 20),
          _row('功能主治', d['syz']),
          _row('禁忌', d['jj']),
          _row('批准文号', d['pzwh']),
        ]),
      ),
    );
  }

  Widget _row(String label, dynamic value) {
    final s = value?.toString() ?? '';
    if (s.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.ink)),
        const SizedBox(height: 6),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: AppColors.subtleBg, borderRadius: BorderRadius.circular(12)),
          child: Text(s, style: const TextStyle(fontSize: 14, color: AppColors.ink3, height: 1.6)),
        ),
      ]),
    );
  }

  Widget _shimmerCard() => Container(
    height: 80,
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    padding: const EdgeInsets.all(16),
    child: Row(children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: Colors.grey[200], borderRadius: BorderRadius.circular(14))),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width: 200, height: 16, decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(4))),
        const SizedBox(height: 8),
        Container(width: 120, height: 12, decoration: BoxDecoration(color: Colors.grey[50], borderRadius: BorderRadius.circular(4))),
      ])),
    ]),
  );
}
