/// 集中式路由表 —— 所有页面跳转的单一入口。
///
/// 页面跳转原先散落在 13 处 `Navigator.push(MaterialPageRoute(...))`，
/// 每处都要重复拼 route 构造，且想一眼看清「这个 App 到底有哪些页面」很难。
/// 收敛到这里后：
///   · 全部页面入口一处可查；
///   · 传参走强类型方法签名，不再靠 builder 闭包隐式传参；
///   · 日后加转场动画 / 登录守卫 / 埋点只需改这一处。
library;

import 'package:flutter/material.dart';

import '../data/drug_item.dart';
import '../data/med_record.dart';
import '../data/user_profile.dart';
import '../pages/ai_settings_page.dart';
import '../pages/family_page.dart';
import '../pages/login_page.dart';
import '../pages/med_chat_page.dart';
import '../pages/med_plan_page.dart';
import '../pages/profile_setup_page.dart';
import 'home_page.dart';
import 'knowledge_detail_page.dart';
import 'knowledge_page.dart';
import 'search_page.dart';

abstract final class AppRoutes {
  AppRoutes._();

  /// 入栈。返回的 Future 在目标页 pop 时完成，供「返回后刷新」使用。
  static Future<void> push(BuildContext context, Widget page) async {
    await Navigator.push<dynamic>(
      context,
      MaterialPageRoute(builder: (_) => page),
    );
  }

  /// 替换当前页（用于启动页 → 主页、问卷完成 → 主页这类不可回退的跳转）。
  static Future<void> replace(BuildContext context, Widget page) async {
    await Navigator.pushReplacement<dynamic, dynamic>(
      context,
      MaterialPageRoute(builder: (_) => page),
    );
  }

  // ── 寻源 / 药匣 / 归处 ──

  static Future<void> toSearch(BuildContext context, String keyword) =>
      push(context, SearchPage(keyword: keyword));

  static Future<void> toMedPlan(BuildContext context, List<DrugItem> items) =>
      push(context, MedPlanPage(cabinetItems: items));

  static Future<void> toKnowledge(BuildContext context) =>
      push(context, const KnowledgePage());

  static Future<void> toKnowledgeDetail(BuildContext context, Map article) =>
      push(context, KnowledgeDetailPage(article: article));

  // ── 个人中心 / 账号 ──

  static Future<void> toProfileSetup(BuildContext context) =>
      push(context, const ProfileSetupPage());

  static Future<void> toFamily(BuildContext context) =>
      push(context, const FamilyPage());

  static Future<void> toLogin(BuildContext context) =>
      push(context, const LoginPage());

  static Future<void> toAiSettings(BuildContext context) =>
      push(context, const AiSettingsPage());

  // ── AI 服药助理 ──

  static Future<void> toMedChat(
    BuildContext context, {
    required UserProfile profile,
    required List<DrugItem> items,
    required List<MedRecord> records,
  }) =>
      push(context, MedChatPage(profile: profile, items: items, records: records));

  // ── 主页（用 GlobalKey 复位到首页，替换当前栈）──

  static Future<void> toHome(BuildContext context) =>
      replace(context, HomePage(key: HomePage.homeKey));
}
