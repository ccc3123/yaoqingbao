import 'package:flutter/material.dart';
import '../pages/xunyuan_page.dart';
import '../pages/yaoxia_page.dart';
import '../pages/guichu_page.dart';
import 'app_routes.dart';
import '../widgets/design_icons.dart';
import '../util/agent_scheduler.dart';
import '../util/med_box_store.dart';
import '../util/reminder_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_dimens.dart';
import '../theme/app_text.dart';

/// 药清宝 — 三节点河流导航主页
/// PageView + 自定义 RiverNav 底部栏 + 粒子/涟漪动效
class HomePage extends StatefulWidget {
  static final GlobalKey<HomePageState> homeKey = GlobalKey<HomePageState>();

  const HomePage({super.key});

  @override
  State<HomePage> createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  int _index = 0;
  late final PageController _pageCtrl;

  late final List<Widget> _pages;
  final _titles = const ['寻 源', '药 匣', '归 处'];
  final _labels = const ['追溯药品之源', '管理家庭药箱', '回收点 + 知识'];

  @override
  void initState() {
    super.initState();
    _pageCtrl = PageController();
    _pages = [
      const XunYuanPage(),
      const YaoXiaPage(),
      GuiChuPage(key: GuiChuPage.pageKey),
    ];
    // 家庭用药智能体：App 启动即巡检一次，回到前台时再巡检，
    // 发现过期/临期/重复成分时主动弹横幅提醒（详见 AgentScheduler）。
    AgentScheduler.instance.start(onAlert: _onAgentAlert);
    // 到期提醒：请求通知权限并按当前药箱排期
    ReminderService.instance.requestPermission().then((_) => _rescheduleReminders());
  }

  /// 按当前药箱重新排期到期通知
  Future<void> _rescheduleReminders() async {
    final items = await MedBoxStore.load();
    await ReminderService.instance.scheduleExpiryReminders(items);
  }

  /// 个人中心：健康档案 / 家庭 / 账号 / AI 设置
  void _showProfileMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(top: 10),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            _menuItem(ctx, Icons.assignment_ind_outlined, '个人健康档案', () {
              Navigator.pop(ctx);
              AppRoutes.toProfileSetup(context);
            }),
            _menuItem(ctx, Icons.group_outlined, '家庭药箱', () {
              Navigator.pop(ctx);
              AppRoutes.toFamily(context);
            }),
            _menuItem(ctx, Icons.phone_iphone, '账号登录', () {
              Navigator.pop(ctx);
              AppRoutes.toLogin(context);
            }),
            _menuItem(ctx, Icons.smart_toy_outlined, 'AI 接口设置', () {
              Navigator.pop(ctx);
              AppRoutes.toAiSettings(context);
            }),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _menuItem(BuildContext ctx, IconData icon, String title, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title, style: const TextStyle(fontSize: 15)),
      trailing: const Icon(Icons.chevron_right, size: 20, color: AppColors.muted),
      onTap: onTap,
    );
  }

  @override
  void dispose() {
    AgentScheduler.instance.stop();
    _pageCtrl.dispose();
    super.dispose();
  }

  /// 巡检警报回调：主动弹横幅，用户可一键跳转药匣查看详情。
  void _onAgentAlert(AgentAlert alert) {
    if (!mounted) return;
    final msg = alert.snapshot.headline;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('药清宝提醒：$msg'),
      action: SnackBarAction(label: '查看', onPressed: () => switchToTab(1)),
      duration: const Duration(seconds: 5),
    ));
    AgentScheduler.instance.markRead();
  }

  void switchToTab(int index) {
    if (index >= 0 && index < _pages.length) {
      _pageCtrl.animateToPage(index,
        duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
      setState(() => _index = index);
    }
  }

  void _onNodeTap(int i) {
    if (i == _index) return;
    setState(() => _index = i);
    _pageCtrl.animateToPage(i,
      duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          // ── 顶部标题栏 ──
          _buildHeader(),
          // ── 页面内容 ──
          Expanded(
            child: PageView(
              controller: _pageCtrl,
              onPageChanged: (i) {
                setState(() => _index = i);
              },
              children: _pages,
            ),
          ),
          // ── 河流导航栏 ──
          _buildRiverNav(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      decoration: const BoxDecoration(gradient: AppGradients.header),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(
            AppSpacing.lg,
            AppSpacing.md,
            AppSpacing.sm,
            AppSpacing.md,
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppColors.onDark.withValues(alpha: 0.16),
                  borderRadius: AppRadius.rMd,
                ),
                child: DesignIcons.eco(size: 22, color: AppColors.onDark),
              ),
              const SizedBox(width: AppSpacing.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_titles[_index], style: AppText.onDarkHeadline),
                    Text(_labels[_index], style: AppText.onDarkSubtitle),
                  ],
                ),
              ),
              // 个人中心入口：原为 36×36 的 GestureDetector，低于 44×44 触控下限
              // 且屏幕阅读器读不出用途。换成 IconButton 后两者都由框架保证。
              IconButton(
                onPressed: _showProfileMenu,
                tooltip: '个人中心',
                icon: const Icon(Icons.person_outline),
                color: AppColors.onDark,
                iconSize: 22,
                style: IconButton.styleFrom(
                  backgroundColor: AppColors.onDark.withValues(alpha: 0.16),
                  minimumSize: const Size(
                    AppTouch.minSize,
                    AppTouch.minSize,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRiverNav() {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/images/river-flow.png'),
          // cover 而非 fill：fill 会随屏幕宽高比拉伸河流纹样导致变形。
          fit: BoxFit.cover,
        ),
      ),
      // SafeArea 在外、固定高度在内：原先把 height 套在 SafeArea 外层，
      // 手势导航条的底部 inset 会从这 72px 里扣，内容区实际只剩 ~48px，
      // 迫使图标和文字被压到 38px / 10px。现在内容区稳定 64，inset 额外叠加。
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Stack(
            children: [
              // 压暗河流图，保证其上的白色图标与文字有足够对比度。
              Positioned.fill(
                child: Container(
                  color: AppColors.primaryDeepest.withValues(alpha: 0.55),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(3, (i) => _buildNode(i)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNode(int i) {
    final active = _index == i;
    // 非激活态原为 0.35（图标）/ 0.2（文字），在压暗后的河流底上远低于 4.5:1，
    // 用户看不出另外两个节点存在。提到 0.82 / 0.88 后可清晰辨认，
    // 同时仍与激活态（纯白 + 薄荷绿 + 光晕）保持明确区分。
    final iconColor =
        active ? AppColors.onDark : AppColors.onDark.withValues(alpha: 0.82);
    final icons = <Widget>[
      DesignIcons.nodeXunYuan(size: 22, color: iconColor),
      DesignIcons.nodeYaoXia(size: 22, color: iconColor),
      DesignIcons.nodeGuiChu(size: 22, color: iconColor),
    ];
    const names = ['寻 源', '药 匣', '归 处'];
    const hints = ['追溯药品之源', '管理家庭药箱', '回收点与用药知识'];

    return Semantics(
      button: true,
      selected: active,
      label: '${names[i].replaceAll(' ', '')}，${hints[i]}',
      hint: active ? '当前所在页' : '双击切换到此页',
      excludeSemantics: true,
      child: GestureDetector(
        onTap: () => _onNodeTap(i),
        behavior: HitTestBehavior.opaque,
        child: ConstrainedBox(
          constraints: AppTouch.minConstraints,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.symmetric(
              horizontal: AppSpacing.lg,
              vertical: AppSpacing.xs,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // 节点圆
                AnimatedContainer(
                  duration: const Duration(milliseconds: 350),
                  width: active ? 40 : 36,
                  height: active ? 40 : 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: active
                        ? const RadialGradient(
                            colors: [
                              AppColors.primaryPale,
                              AppColors.primaryDark,
                            ],
                          )
                        : null,
                    // 非激活底色与描边同步提亮，让"这里还有个可点的节点"看得见。
                    color: active
                        ? null
                        : AppColors.onDark.withValues(alpha: 0.14),
                    border: Border.all(
                      color: active
                          ? AppColors.primaryLight
                          : AppColors.onDark.withValues(alpha: 0.45),
                      width: active ? 2 : 1.5,
                    ),
                    boxShadow: active
                        ? [
                            BoxShadow(
                              color: AppColors.primaryLight.withValues(
                                alpha: 0.5,
                              ),
                              blurRadius: 24,
                              spreadRadius: 1,
                            ),
                          ]
                        : null,
                  ),
                  child: Center(child: icons[i]),
                ),
                const SizedBox(height: 2),
                // 节点名
                AnimatedDefaultTextStyle(
                  duration: const Duration(milliseconds: 300),
                  style: TextStyle(
                    fontSize: AppText.sizeCaption,
                    height: 1.1,
                    fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                    color: active
                        ? AppColors.onDarkMint
                        : AppColors.onDark.withValues(alpha: 0.88),
                    letterSpacing: 1.5,
                  ),
                  child: Text(names[i]),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


