import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/drug_item.dart';
import 'home_page.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// Tab 2: 回收行动中心 — 统计卡 + 分类筛选 + 侧滑删除 + 立即回收指引
class RecyclePage extends StatefulWidget {
  const RecyclePage({super.key});
  @override
  State<RecyclePage> createState() => _RecyclePageState();
}

class _RecyclePageState extends State<RecyclePage> {
  List<DrugItem> _items = [];
  String _filter = 'all'; // all / reusable / disposable
  static const _key = 'yaoqingbao_drug_list';

  @override
  void initState() {
    super.initState();
    _loadItems();
  }

  Future<void> _loadItems() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonStr = prefs.getString(_key);
    if (jsonStr != null) {
      final list = jsonDecode(jsonStr) as List;
      setState(() {
        _items = list.map((e) => DrugItem.fromJson(e)).toList();
        _refreshAll();
      });
    }
  }

  Future<void> _saveItems() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(_items.map((e) => e.toJson()).toList()));
  }

  void _refreshAll() {
    final now = DateTime.now();
    for (int i = 0; i < _items.length; i++) {
      if (_items[i].expDays > 0 && _items[i].produceTime.isNotEmpty) {
        try {
          final produce = DateTime.parse(_items[i].produceTime);
          final expire = produce.add(Duration(days: _items[i].expDays));
          final remaining = expire.difference(now).inDays;
          _items[i] = DrugItem(
            medicineId: _items[i].medicineId,
            medicineName: _items[i].medicineName,
            produceTime: _items[i].produceTime,
            addTime: _items[i].addTime,
            countDown: remaining,
            expDays: _items[i].expDays,
          );
        } catch (_) {}
      }
    }
  }

  List<DrugItem> get _filtered =>
      _filter == 'all'
          ? _items
          : _filter == 'disposable'
              ? _items.where((e) => e.countDown <= 0).toList()
              : _items.where((e) => e.countDown > 0).toList();

  int get _expiredCount => _items.where((e) => e.countDown <= 0).length;
  int get _warningCount =>
      _items.where((e) => e.countDown > 0 && e.countDown <= 30).length;

  /// 跳转到地图 Tab
  void _goToMapTab() {
    HomePage.homeKey.currentState?.switchToTab(2);
  }

  Future<void> _addItem() async {
    final nameCtrl = TextEditingController();
    final dateCtrl = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(DateTime.now()));
    final expCtrl = TextEditingController(text: '24');

    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: EdgeInsets.fromLTRB(
            24, 24, 24, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('添加药品',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 20),
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(
                labelText: '药品名称',
                hintText: '如：阿莫西林胶囊',
                prefixIcon: const Icon(Icons.medication),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: dateCtrl,
              decoration: InputDecoration(
                labelText: '生产日期',
                hintText: 'yyyy-MM-dd',
                prefixIcon: const Icon(Icons.calendar_today),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: expCtrl,
              decoration: InputDecoration(
                labelText: '有效期（月）',
                prefixIcon: const Icon(Icons.timer),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 24),
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('取消'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: const Text('添加到药箱'),
                ),
              ),
            ]),
          ],
        ),
      ),
    );

    if (result == true && nameCtrl.text.isNotEmpty) {
      final expMonths = int.tryParse(expCtrl.text) ?? 24;
      final item = DrugItem(
        medicineId: DateTime.now().millisecondsSinceEpoch.toString(),
        medicineName: nameCtrl.text,
        produceTime: dateCtrl.text,
        addTime: DateFormat('yyyy-MM-dd').format(DateTime.now()),
        countDown: expMonths * 30,
        expDays: expMonths * 30,
      );
      setState(() => _items.add(item));
      _refreshAll();
      await _saveItems();
    }
  }

  Future<void> _deleteItem(int index) async {
    setState(() => _items.removeAt(index));
    await _saveItems();
  }

  /// 标记药品已回收（弹窗确认后移除）
  Future<void> _markRecycled(int index) async {
    final item = _items[index];
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Row(children: [
          Icon(Icons.recycling, color: AppColors.primary),
          SizedBox(width: 10),
          Text('确认回收', style: TextStyle(fontSize: 18)),
        ]),
        content: Text('「${item.medicineName}」已投递到回收点了吗？\n确认后将移出药箱。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.primary,
            ),
            child: const Text('确认已回收'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await _deleteItem(index);
    }
  }

  @override
  Widget build(BuildContext context) {
    final total = _items.length;
    final expired = _expiredCount;
    final warning = _warningCount;

    return Stack(
      children: [
        Column(
          children: [
        // ── 弧形统计卡 ──
        Container(
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.withValues(alpha: 0.25),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 8),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.primaryStrong, AppColors.primaryLight],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _statItem('$total', '在册', Icons.medication),
                  Container(width: 1, height: 40, color: Colors.white24),
                  _statItem('$expired', '已过期', Icons.dangerous),
                  Container(width: 1, height: 40, color: Colors.white24),
                  _statItem('$warning', '即将到期', Icons.warning_amber_rounded),
                ],
              ),
            ),
          ),
        ),

        // ── 过期警告 + 行动入口 ──
        if (expired > 0)
          GestureDetector(
            onTap: _goToMapTab,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppColors.dangerTint,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppColors.dangerTint),
              ),
              child: Row(children: [
                const Icon(Icons.warning_amber_rounded, color: AppColors.danger),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '您有 $expired 种药品已过期，请尽快前往回收点处理',
                    style: const TextStyle(
                      color: AppColors.danger,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.danger,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Text('立即回收 →',
                      style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                ),
              ]),
            ),
          ),

        const SizedBox(height: 12),

        // ── 分类筛选 ──
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            _filterTab('全部 ($total)', 'all'),
            const SizedBox(width: 8),
            _filterTab('有效期内', 'reusable', icon: Icons.check_circle_outline),
            const SizedBox(width: 8),
            _filterTab('已过期', 'disposable', icon: Icons.cancel_outlined),
          ]),
        ),

        const SizedBox(height: 8),

        // ── 药品列表 ──
        Expanded(
          child: _filtered.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: AppColors.primaryTintWeak,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: const Icon(Icons.medication_outlined,
                            size: 52, color: AppColors.primaryPale),
                      ),
                      const SizedBox(height: 20),
                      const Text('药箱为空',
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: AppColors.ink3)),
                      const SizedBox(height: 6),
                      Text('点击下方 + 添加家中药品',
                          style: TextStyle(color: AppColors.ink3, fontSize: 14)),
                      const SizedBox(height: 16),
                      OutlinedButton.icon(
                        onPressed: () =>
                            HomePage.homeKey.currentState?.switchToTab(3),
                        icon: const Icon(Icons.menu_book_outlined, size: 18),
                        label: const Text('先学回收知识'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.primary,
                          side: const BorderSide(color: AppColors.primaryTint),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 80),
                  itemCount: _filtered.length,
                  itemBuilder: (ctx, i) {
                    final item = _filtered[i];
                    final isExpired = item.countDown <= 0;
                    final isWarning = !isExpired && item.countDown <= 30;
                    final barColor = isExpired
                        ? AppColors.danger
                        : isWarning
                            ? AppColors.warning
                            : AppColors.primaryLight;
                    final realIndex = _items.indexOf(item);

                    return Dismissible(
                      key: Key(item.medicineId),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 24),
                        decoration: BoxDecoration(
                          color: Colors.red[400],
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: const Icon(Icons.delete, color: Colors.white),
                      ),
                      confirmDismiss: (_) async =>
                          await showDialog<bool>(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: const Text('移出药箱'),
                              content: Text('确认移除「${item.medicineName}」？'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(ctx, false),
                                  child: const Text('取消'),
                                ),
                                TextButton(
                                  onPressed: () => Navigator.pop(ctx, true),
                                  child: const Text('移除',
                                      style: TextStyle(color: Colors.red)),
                                ),
                              ],
                            ),
                          ),
                      onDismissed: (_) => _deleteItem(realIndex),
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(18),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.04),
                              blurRadius: 8,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: IntrinsicHeight(
                            child: Row(children: [
                              Container(width: 5, color: barColor),
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Row(children: [
                                    Container(
                                      width: 44,
                                      height: 44,
                                      decoration: BoxDecoration(
                                        color: barColor.withValues(alpha: 0.1),
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Icon(
                                        isExpired
                                            ? Icons.dangerous
                                            : Icons.medication,
                                        color: barColor,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(item.medicineName,
                                              style: const TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w600)),
                                          const SizedBox(height: 4),
                                          Row(children: [
                                            Text('生产: ${item.produceTime}',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    color: AppColors.muted)),
                                            const SizedBox(width: 12),
                                            Text(
                                              isExpired
                                                  ? '已过期 ${-item.countDown} 天'
                                                  : '剩余 ${item.countDown} 天',
                                              style: TextStyle(
                                                fontSize: 12,
                                                fontWeight: FontWeight.w600,
                                                color: barColor,
                                              ),
                                            ),
                                          ]),
                                        ],
                                      ),
                                    ),
                                    // 操作按钮区
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        if (isExpired)
                                          // 过期药品：立即回收按钮
                                          GestureDetector(
                                            onTap: _goToMapTab,
                                            child: Container(
                                              padding: const EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                color: AppColors.primary,
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                              child: const Icon(
                                                Icons.navigation_rounded,
                                                color: Colors.white,
                                                size: 20,
                                              ),
                                            ),
                                            // tooltip via semantic label
                                          )
                                        else
                                          // 未过期：标记已回收按钮
                                          GestureDetector(
                                            onTap: () =>
                                                _markRecycled(realIndex),
                                            child: Container(
                                              padding: const EdgeInsets.all(10),
                                              decoration: BoxDecoration(
                                                color: AppColors.primaryTintWeak,
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                              child: const Icon(
                                                Icons.recycling,
                                                color: AppColors.primary,
                                                size: 20,
                                              ),
                                            ),
                                          ),
                                        const SizedBox(height: 4),
                                        Text(
                                          isExpired ? '导航回收' : '标记回收',
                                          style: TextStyle(
                                            fontSize: AppText.sizeCaption,
                                            color: isExpired
                                                ? AppColors.primary
                                                : AppColors.primary,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ]),
                                ),
                              ),
                            ]),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
      ),
      Positioned(
        right: 16,
        bottom: 16,
        child: FloatingActionButton.extended(
          onPressed: _addItem,
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add),
          label: const Text('添加药品'),
        ),
      ),
    ],
    );
  }

  Widget _statItem(String value, String label, IconData icon) => Column(children: [
        Icon(icon, color: Colors.white70, size: 22),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold)),
        Text(label,
            style: const TextStyle(color: Colors.white70, fontSize: 12)),
      ]);

  Widget _filterTab(String label, String value, {IconData? icon}) {
    final active = _filter == value;
    return GestureDetector(
      onTap: () => setState(() => _filter = value),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.primaryTintWeak : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? AppColors.primary : Colors.grey[200]!,
            width: active ? 2 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (icon != null) ...[
              Icon(
                icon,
                size: 15,
                color: active ? AppColors.primaryStrong : Colors.grey[600],
              ),
              const SizedBox(width: 4),
            ],
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                fontWeight: active ? FontWeight.w600 : FontWeight.normal,
                color: active ? AppColors.primaryStrong : Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
