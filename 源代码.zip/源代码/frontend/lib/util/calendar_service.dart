import 'package:device_calendar/device_calendar.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../data/med_plan.dart';

/// 服药计划闹钟服务 —— 把计划写入手机系统日历。
///
/// 用户要求「闹钟还给原生日历」：计划保存后，每个每日时间点生成一条日历事件
/// （带提前提醒 + 每日重复），即使 App 未运行，系统日历也会按时闹钟。
/// 事件 ID 存回计划，便于修改/删除时同步更新日历。
class CalendarService {
  CalendarService._();

  static final CalendarService instance = CalendarService._();

  final DeviceCalendarPlugin _plugin = DeviceCalendarPlugin();
  bool _inited = false;
  String? _calendarId;

  Future<void> init() async {
    if (_inited) return;
    try {
      tzdata.initializeTimeZones();
      try {
        final name = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(name));
      } catch (_) {
        tz.setLocalLocation(tz.getLocation('Asia/Shanghai'));
      }
      _calendarId = await _ensureCalendar();
      _inited = true;
    } catch (_) {
      // 日历不可用：静默，同步方法全部 try 兜底
    }
  }

  /// 请求日历读写权限
  Future<bool> requestPermission() async {
    try {
      final result = await _plugin.requestPermissions();
      return result.data ?? false;
    } catch (_) {
      return false;
    }
  }

  /// 找到/创建「药清宝」日历，返回日历 ID
  Future<String?> _ensureCalendar() async {
    try {
      final calendarsResult = await _plugin.retrieveCalendars();
      final calendars = calendarsResult.data ?? [];
      for (final c in calendars) {
        if (c.name == '药清宝') return c.id;
      }
      // 未找到则创建
      final created = await _plugin.createCalendar('药清宝');
      return created.data;
    } catch (_) {
      return null;
    }
  }

  /// 把全部启用计划同步到系统日历（先清旧事件再重排）。
  ///
  /// 返回带日历事件 ID 的计划列表（供回写持久化）。
  Future<List<MedPlan>> syncPlans(List<MedPlan> plans) async {
    await init();
    if (_calendarId == null) return plans;

    // 1. 删除全部旧事件
    for (final p in plans) {
      for (final eventId in p.calendarEventIds) {
        try {
          await _plugin.deleteEvent(_calendarId!, eventId);
        } catch (_) {}
      }
    }

    // 2. 为启用计划重排
    final out = <MedPlan>[];
    for (final plan in plans) {
      final eventIds = <String>[];
      if (plan.enabled) {
        for (final time in plan.times) {
          final eventId = await _createDailyEvent(plan, time);
          if (eventId != null) eventIds.add(eventId);
        }
      }
      out.add(plan.copyWith(calendarEventIds: eventIds));
    }
    return out;
  }

  Future<String?> _createDailyEvent(MedPlan plan, String time) async {
    try {
      final parts = time.split(':');
      if (parts.length != 2) return null;
      final hour = int.tryParse(parts[0]);
      final minute = int.tryParse(parts[1]);
      if (hour == null || minute == null) return null;

      final now = tz.TZDateTime.now(tz.local);
      final start = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour, minute);
      final end = start.add(const Duration(minutes: 30));

      final event = Event(
        _calendarId!,
        title: '服药提醒：${plan.medicineName}',
        description: '剂量：${plan.dosage}',
        start: start,
        end: end,
        recurrenceRule: RecurrenceRule(RecurrenceFrequency.Daily, interval: 1),
        reminders: [Reminder(minutes: 0)],
      );
      final result = await _plugin.createOrUpdateEvent(event);
      return result?.data;
    } catch (_) {
      return null;
    }
  }
}
