import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../data/user_profile.dart';

/// 个人健康档案服务（仅存本机，不上传）
class ProfileService {
  ProfileService._();

  static const String _key = 'yaoqingbao_user_profile';

  static Future<UserProfile> load() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_key);
    if (s == null || s.isEmpty) return UserProfile();
    try {
      final decoded = jsonDecode(s);
      if (decoded is Map<String, dynamic>) return UserProfile.fromJson(decoded);
      return UserProfile();
    } catch (_) {
      return UserProfile();
    }
  }

  static Future<void> save(UserProfile profile) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(profile.toJson()));
  }

  /// 是否已完成问卷（首次启动据此决定是否先进入问卷页）
  static Future<bool> isCompleted() async {
    return (await load()).isCompleted;
  }
}
