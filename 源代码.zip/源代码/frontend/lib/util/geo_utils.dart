import 'dart:math' as math;

/// 坐标系工具 — WGS84（GPS 原始坐标）与 GCJ02（国内地图加密坐标）互转
///
/// 手机 GPS / geolocator 拿到的是 WGS84，而高德等国内底图使用 GCJ02，
/// 不纠偏会出现约 300~500 米的整体偏移，回收点会标注到错误的街道上。
class GeoUtils {
  static const double _pi = math.pi;
  static const double _a = 6378245.0;
  static const double _ee = 0.00669342162296594323;

  GeoUtils._();

  static bool _outOfChina(double lat, double lng) {
    return lng < 72.004 || lng > 137.8347 || lat < 0.8293 || lat > 55.8271;
  }

  static double _transformLat(double x, double y) {
    double ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y +
        0.1 * x * y + 0.2 * math.sqrt(x.abs());
    ret += (20.0 * math.sin(6.0 * x * _pi) + 20.0 * math.sin(2.0 * x * _pi)) * 2.0 / 3.0;
    ret += (20.0 * math.sin(y * _pi) + 40.0 * math.sin(y / 3.0 * _pi)) * 2.0 / 3.0;
    ret += (160.0 * math.sin(y / 12.0 * _pi) + 320 * math.sin(y * _pi / 30.0)) * 2.0 / 3.0;
    return ret;
  }

  static double _transformLng(double x, double y) {
    double ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y +
        0.1 * math.sqrt(x.abs());
    ret += (20.0 * math.sin(6.0 * x * _pi) + 20.0 * math.sin(2.0 * x * _pi)) * 2.0 / 3.0;
    ret += (20.0 * math.sin(x * _pi) + 40.0 * math.sin(x / 3.0 * _pi)) * 2.0 / 3.0;
    ret += (150.0 * math.sin(x / 12.0 * _pi) + 300.0 * math.sin(x / 30.0 * _pi)) * 2.0 / 3.0;
    return ret;
  }

  /// WGS84 → GCJ02，返回 [lat, lng]
  static List<double> wgs84ToGcj02(double lat, double lng) {
    if (_outOfChina(lat, lng)) return [lat, lng];
    double dLat = _transformLat(lng - 105.0, lat - 35.0);
    double dLng = _transformLng(lng - 105.0, lat - 35.0);
    final radLat = lat / 180.0 * _pi;
    double magic = math.sin(radLat);
    magic = 1 - _ee * magic * magic;
    final sqrtMagic = math.sqrt(magic);
    dLat = (dLat * 180.0) / ((_a * (1 - _ee)) / (magic * sqrtMagic) * _pi);
    dLng = (dLng * 180.0) / (_a / sqrtMagic * math.cos(radLat) * _pi);
    return [lat + dLat, lng + dLng];
  }

  /// GCJ02 → WGS84（反向纠偏，用于把地图上点到的坐标还原给后端）
  ///
  /// GCJ02 加密不可逆，这里用不动点迭代逼近：单次反解会残留约 2 米误差，
  /// 迭代 3 次后往返误差可降到毫米级，保证用户点选的位置回传给后端不漂移。
  static List<double> gcj02ToWgs84(double lat, double lng) {
    if (_outOfChina(lat, lng)) return [lat, lng];
    double wLat = lat;
    double wLng = lng;
    for (int i = 0; i < 3; i++) {
      final g = wgs84ToGcj02(wLat, wLng);
      wLat += lat - g[0];
      wLng += lng - g[1];
    }
    return [wLat, wLng];
  }

  /// Haversine 距离（米）
  static double distanceMeter(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371000.0;
    final dLat = (lat2 - lat1) * math.pi / 180.0;
    final dLon = (lon2 - lon1) * math.pi / 180.0;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180.0) *
            math.cos(lat2 * math.pi / 180.0) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  /// 距离展示：小于 1km 用米，否则用公里
  static String formatDistance(double meters) {
    if (meters <= 0) return '--';
    if (meters < 1000) return '${meters.toInt()}m';
    return '${(meters / 1000).toStringAsFixed(1)}km';
  }
}
