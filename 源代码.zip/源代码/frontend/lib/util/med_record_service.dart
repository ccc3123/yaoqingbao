import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../data/drug_item.dart';
import '../data/med_record.dart';
import 'device_utils.dart';
import 'http_utils.dart';
import 'med_box_store.dart';

/// 服药记录服务（本地 + 家庭共享同步 + 药箱余量联动）
class MedRecordService {
  MedRecordService._();

  static final MedRecordService instance = MedRecordService._();

  static const String _key = 'yaoqingbao_med_records';

  /// 拉取服药记录（家庭共享）
  Future<List<MedRecord>> list() async {
    try {
      final familyCode = await DeviceUtils.familyCode();
      final devId = await DeviceUtils.deviceId();
      final resp = await HttpUtils().get('/medrecord/list', params: {
        if (familyCode.isNotEmpty) 'familyCode': familyCode else 'deviceId': devId,
      });
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is List) {
        return (body['data'] as List)
            .whereType<Map>()
            .map((e) => MedRecord.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
    } catch (_) {
      // 服务端不可用，读本地缓存
    }
    return _loadLocal();
  }

  /// 记录一次服药，并联动递减药箱对应药品的余量、更新最近服用时间。
  ///
  /// [medicineId] 药箱条目 ID；[dose] 本次剂量；[unit] 单位；[takenAt] 时间。
  Future<MedRecord> record({
    required String medicineId,
    required String medicineName,
    required double dose,
    required String unit,
    String? takenAt,
  }) async {
    final memberName = await DeviceUtils.memberName();
    final record = MedRecord(
      medicineId: medicineId,
      medicineName: medicineName,
      dose: dose,
      unit: unit,
      takenAt: takenAt ?? _nowStr(),
      memberName: memberName,
    );

    // 1. 本地缓存记录
    final local = await _loadLocal();
    local.insert(0, record);
    await _saveLocal(local);

    // 2. 联动药箱：递减余量 + 更新最近服用（经 MedBoxStore，触发药匣页刷新）
    final items = await MedBoxStore.load();
    var changed = false;
    for (int i = 0; i < items.length; i++) {
      if (items[i].medicineId == medicineId) {
        final item = items[i];
        final newRemaining =
            item.remaining > 0 ? (item.remaining - dose).clamp(0.0, item.remaining) : item.remaining;
        items[i] = item.copyWith(
          remaining: newRemaining,
          lastTakenAt: record.takenAt,
        );
        changed = true;
        break;
      }
    }
    if (changed) await MedBoxStore.save(items);

    // 3. 服务端尽力同步
    try {
      final familyCode = await DeviceUtils.familyCode();
      final devId = await DeviceUtils.deviceId();
      await HttpUtils().post('/medrecord/save', data: {
        'familyCode': familyCode,
        'deviceId': devId,
        'memberName': memberName,
        'medicineId': medicineId,
        'medicineName': medicineName,
        'dose': dose,
        'unit': unit,
        'takenAt': record.takenAt,
      });
    } catch (_) {
      // 静默：下次进入时补传
    }

    return record;
  }

  /// 删除服药记录（纠错）
  Future<void> delete(MedRecord record) async {
    final local = await _loadLocal();
    local.removeWhere((e) => e.id == record.id);
    await _saveLocal(local);
    try {
      if (record.id > 0) {
        await HttpUtils().delete('/medrecord/delete', params: {'id': record.id});
      }
    } catch (_) {}
  }

  /// 手动调整药箱某药品余量（加/减，补药或纠错）
  Future<void> adjustRemaining(DrugItem item, double delta) async {
    final items = await MedBoxStore.load();
    for (int i = 0; i < items.length; i++) {
      if (items[i].medicineId == item.medicineId) {
        final cur = items[i].remaining;
        final next = (cur + delta).clamp(0.0, items[i].total > 0 ? items[i].total : double.infinity);
        items[i] = items[i].copyWith(remaining: next);
        break;
      }
    }
    await MedBoxStore.save(items);
  }

  Future<List<MedRecord>> _loadLocal() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_key);
    if (s == null || s.isEmpty) return <MedRecord>[];
    try {
      final list = jsonDecode(s);
      if (list is List) {
        return list
            .whereType<Map>()
            .map((e) => MedRecord.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
      return <MedRecord>[];
    } catch (_) {
      return <MedRecord>[];
    }
  }

  Future<void> _saveLocal(List<MedRecord> records) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _key, jsonEncode(records.map((e) => e.toJson()).toList()));
  }

  String _nowStr() {
    final now = DateTime.now();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${now.year}-${two(now.month)}-${two(now.day)} ${two(now.hour)}:${two(now.minute)}';
  }
}
