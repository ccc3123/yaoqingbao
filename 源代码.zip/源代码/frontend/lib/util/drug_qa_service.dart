import '../data/medicine.dart';
import 'drug_db.dart';
import 'safe_cast.dart';
import 'zhipu_service.dart';

/// 问药回答结果。
///
/// [answer] 组织好的回答；[drugNames] 涉及药品名；[fromAi] 是否来自 AI。
/// fromAi 为 false 时表示该答案来自本地拦截 / 检索兜底，未经过模型。
class DrugQaAnswer {
  final String answer;
  final List<String> drugNames;
  final bool fromAi;

  const DrugQaAnswer({
    required this.answer,
    required this.drugNames,
    required this.fromAi,
  });
}

/// RAG 问药服务：用户自然语言问题 -> 本地检索命中药 -> 官方说明书作上下文 -> LLM 只组织措辞。
///
/// 严格不做诊疗判断。整条链路的红线只有一条：**适应症 / 用法用量 / 禁忌 / 贮藏 / 成分**
/// 这五类医疗字段只允许来自本地官方说明书原文（`Medicine` 里的 syz/usage/jj/zc/component），
/// 模型只被允许输出「回答 + 药品名」两个字段（见 `ZhipuService._qaKeys`），
/// 任何 AI 生成的医疗字段都会被 `_sanitize` 丢弃，绝不进入 UI。
class DrugQaService {
  DrugQaService();

  /// 检索命中条数上限。
  static const int _topK = 5;

  /// 疑问语气词。多字词排在前面，避免「能」把「能不能」提前拆坏。
  static const List<String> _questionWords = [
    '能不能',
    '可不可以',
    '可以',
    '吗',
    '呢',
    '吧',
    '能',
  ];

  /// 连接词，剥掉后剩下的较长片段更可能是药名。
  static const List<String> _connectiveWords = [
    '一起',
    '和',
    '与',
    '跟',
    '同',
  ];

  /// 诊疗 / 用药安全类关键词。命中即本地拦截，不调 AI。
  ///
  /// 这类问题的答案关系到真实人身安全，模型幻觉的代价不可接受，
  /// 因此宁可在入口处一刀切，也不交给 LLM 自由发挥。
  static const List<String> _treatmentKeywords = [
    '能否同服',
    '一起吃',
    '混吃',
    '剂量',
    '吃多少',
    '停药',
    '能不能停',
    '诊断',
    '什么病',
    '替代',
    '换药',
  ];

  final ZhipuService _zhipu = ZhipuService();

  /// 问药入口。任何分支都不会抛异常，保证断网 / 无 Key / 插件缺失时不崩。
  Future<DrugQaAnswer> answer(String question) async {
    final q = question.trim();

    // 1. 空问题：不进入检索与 AI，直接提示。
    if (q.isEmpty) {
      return const DrugQaAnswer(
        answer: '请输入要咨询的药品问题',
        drugNames: [],
        fromAi: false,
      );
    }

    // 2. 诊疗问题本地拦截：一句话挡回，避免 AI 给出危险判断。
    if (_isTreatmentQuestion(q)) {
      return const DrugQaAnswer(
        answer: '涉及用药安全，请咨询药师或医师，本应用不提供诊疗建议。',
        drugNames: [],
        fromAi: false,
      );
    }

    // 检索结果先缓存起来，供异常分支与 AI 失败降级复用。
    List<Medicine> medicines = const <Medicine>[];
    List<String> names = const <String>[];

    try {
      // 3. 本地检索。
      medicines = await _search(q);
      names = _namesOf(medicines);

      // 4. 未命中：提示换说法，不进 AI。
      if (names.isEmpty) {
        return const DrugQaAnswer(
          answer: '未在本地药品库中检索到相关问题涉及药品，请换个说法或输入具体药名。',
          drugNames: [],
          fromAi: false,
        );
      }

      // 5. 拼接官方说明书字段作上下文。
      final context = _buildContext(medicines);

      // 6. 交给模型组织措辞。
      final result = await _zhipu.askQuestion(question: q, context: context);
      if (result != null) {
        final aiAnswer = asStringSafe(result['answer']).trim();
        final aiDrugs = _parseDrugNames(result['drugs']);
        if (aiAnswer.isNotEmpty) {
          return DrugQaAnswer(
            answer: aiAnswer,
            // AI 漏了 drugs 列表时回落到本地检索出的药名，保证前端有据可依。
            drugNames: aiDrugs.isEmpty ? names : aiDrugs,
            fromAi: true,
          );
        }
      }
    } catch (_) {
      // 7. 任何异常一律不外抛，落到下方降级分支。
    }

    // 走到这里说明 AI 未可用 / 返回空回答 / 中途异常，降级为本地检索结果。
    if (names.isEmpty) {
      return const DrugQaAnswer(
        answer: 'AI 暂不可用，且本地检索未命中，请换个说法或输入具体药名。',
        drugNames: [],
        fromAi: false,
      );
    }
    return DrugQaAnswer(
      answer: 'AI 暂不可用。已检索到相关药品：${names.join('、')}，可在详情页查看官方说明书。',
      drugNames: names,
      fromAi: false,
    );
  }

  /// 是否命中诊疗 / 用药安全关键词。
  bool _isTreatmentQuestion(String q) {
    return _treatmentKeywords.any(q.contains);
  }

  /// 本地检索：提炼关键词，按长度降序逐个尝试，合并去重后取 top [_topK]。
  ///
  /// 整句直接 LIKE 匹配几乎必空（疑问词 + 连接词干扰），
  /// 拆成多个候选药名多试几次能显著提高召回率。
  Future<List<Medicine>> _search(String question) async {
    final keywords = _extractKeywords(question);
    final seen = <String>{};
    final out = <Medicine>[];
    for (final kw in keywords) {
      if (out.length >= _topK) break;
      final hits = await DrugDb.instance.searchByName(kw, limit: _topK);
      for (final m in hits) {
        // 以药名为去重键，药名为空时退回条码；两者都空则跳过。
        final key = m.drugName.isNotEmpty ? m.drugName : m.barcode;
        if (key.isEmpty || !seen.add(key)) continue;
        out.add(m);
        if (out.length >= _topK) break;
      }
    }
    return out;
  }

  /// 从问题提炼候选关键词（按长度降序）。
  ///
  /// 先剥掉疑问词与连接词，再按标点 / 空白切段；越长越像药名，越靠前。
  /// 过滤单字噪声：单个汉字基本不是有效药名，反而拖慢检索。
  List<String> _extractKeywords(String question) {
    var s = question;
    for (final w in _questionWords) {
      s = s.replaceAll(w, ' ');
    }
    for (final w in _connectiveWords) {
      s = s.replaceAll(w, ' ');
    }
    final parts = s
        .split(RegExp(r'[\s，,。；;？?！!、：:（）()【】\[\]]+'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    parts.sort((a, b) => b.length.compareTo(a.length));

    final seen = <String>{};
    final out = <String>[];
    for (final p in parts) {
      if (p.length < 2) continue;
      if (!seen.add(p)) continue;
      out.add(p);
    }
    return out;
  }

  /// 拼接官方说明书字段作为模型上下文。只保留非空字段。
  ///
  /// 这里的五类医疗字段**全部取自本地库原文**，此处只是机械拼接，不做任何改写。
  String _buildContext(List<Medicine> medicines) {
    final buffer = StringBuffer();
    for (final m in medicines) {
      final lines = <String>[
        if (m.drugName.trim().isNotEmpty) '【药名】${m.drugName}',
        if (m.syz.trim().isNotEmpty) '【适应症】${m.syz}',
        if (m.usage.trim().isNotEmpty) '【用法用量】${m.usage}',
        if (m.jj.trim().isNotEmpty) '【禁忌】${m.jj}',
        if (m.zc.trim().isNotEmpty) '【贮藏】${m.zc}',
        if (m.component.trim().isNotEmpty) '【成分】${m.component}',
      ];
      if (lines.isEmpty) continue;
      buffer.writeln(lines.join('\n'));
      buffer.writeln(); // 药品之间空一行，方便模型区分条目
    }
    return buffer.toString().trim();
  }

  /// 提取检索结果的药品名（去重、去空）。
  List<String> _namesOf(List<Medicine> medicines) {
    final seen = <String>{};
    final out = <String>[];
    for (final m in medicines) {
      final n = m.drugName.trim();
      if (n.isEmpty) continue;
      if (seen.add(n)) out.add(n);
    }
    return out;
  }

  /// 安全解析 AI 返回的 drugs 列表，兼容非 List / 混合类型。
  List<String> _parseDrugNames(dynamic drugs) {
    if (drugs is! List) return const <String>[];
    final out = <String>[];
    for (final d in drugs) {
      final s = asStringSafe(d).trim();
      if (s.isNotEmpty) out.add(s);
    }
    return out;
  }
}
