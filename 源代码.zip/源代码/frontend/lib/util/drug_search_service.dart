import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:dio/dio.dart';
import 'http_utils.dart';

/// 药品检索服务 — 三级数据源，保证"首屏即时出结果 + 优雅降级"
///
/// 1. local：打包内置的常见药品基础库（毫秒级，弱网可用）
/// 2. free ：后端 /med/freeSearch 免费药品查询开放接口（带超时）
/// 3. ai   ：由调用方（ZhipuService）兜底，本服务不直接依赖
///
/// 任何一级失败都返回明确的降级原因，不向上抛异常。
class DrugSearchService {
  static final DrugSearchService _instance = DrugSearchService._internal();
  factory DrugSearchService() => _instance;
  DrugSearchService._internal();

  List<Map<String, dynamic>> _local = [];
  bool _loaded = false;

  /// 默认网络超时：首屏优先，超时即降级
  static const Duration remoteTimeout = Duration(seconds: 4);

  /// 加载本地药品库（重复调用幂等）
  Future<void> loadLocal() async {
    if (_loaded) return;
    try {
      final jsonStr = await rootBundle.loadString('assets/data/offline_drugs.json');
      final data = jsonDecode(jsonStr);
      _local = List<Map<String, dynamic>>.from(
        (data['drugs'] as List).map((e) => Map<String, dynamic>.from(e)),
      );
    } catch (_) {
      _local = [];
    }
    _loaded = true;
  }

  /// 本地库检索（同步，供首屏立即渲染）
  /// 匹配规则：药品名或别名包含关键词（忽略大小写）
  List<Map<String, dynamic>> searchLocal(String keyword) {
    if (keyword.trim().isEmpty) return [];
    final kw = keyword.trim().toLowerCase();
    final result = <Map<String, dynamic>>[];
    for (final d in _local) {
      final name = (d['name'] ?? '').toString();
      final alias = (d['alias'] as List?)?.map((e) => e.toString()).toList() ?? [];
      final hit = name.toLowerCase().contains(kw) ||
          alias.any((a) => a.toLowerCase().contains(kw));
      if (!hit) continue;
      result.add(_normalize({
        'drugName': name,
        'ggxh': d['spec'] ?? '',
        'manu': d['manu'] ?? '',
        'pzwh': '',
        'yxq': '${d['shelfLifeMonths'] ?? 24}个月',
        'type': d['category'] ?? '',
        'usage': d['usage'] ?? '',
        'jj': d['warning'] ?? '',
      }, 'local'));
    }
    return result;
  }

  /// 免费药品查询开放接口（关键词 / 条码 / 批准文号通用）
  /// 返回 null 表示不可用，reason 给出可直接展示的降级提示
  Future<DrugSearchOutcome> searchRemote(String keyword) async {
    try {
      final resp = await HttpUtils()
          .get('/med/freeSearch', params: {'keyword': keyword})
          .timeout(remoteTimeout);
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] != null) {
        final list = body['data'];
        if (list is List && list.isNotEmpty) {
          final items = list
              .map((e) => _normalize(Map<String, dynamic>.from(e), 'free'))
              .toList();
          return DrugSearchOutcome(items: items, source: 'free');
        }
        return DrugSearchOutcome(
            items: const [], source: 'free', reason: '未查询到「$keyword」相关的药品信息');
      }
      final msg = (body is Map ? body['msg'] : null)?.toString();
      return DrugSearchOutcome(
          items: const [],
          source: 'free',
          reason: msg?.isNotEmpty == true ? msg! : '药品查询服务暂时不可用');
    } on DioException catch (e) {
      return DrugSearchOutcome(
          items: const [],
          source: 'free',
          reason: '${HttpUtils.describeError(e)}，已切换智能识别');
    } catch (_) {
      return DrugSearchOutcome(
          items: const [], source: 'free', reason: '药品查询服务暂时不可用');
    }
  }

  /// 统一字段：无论哪一级来源，字段名保持一致，UI 无需分支
  Map<String, dynamic> _normalize(Map<String, dynamic> raw, String source) {
    return {
      'drugName': (raw['drugName'] ?? raw['名称'] ?? '').toString(),
      'ggxh': (raw['ggxh'] ?? raw['规格'] ?? '').toString(),
      'manu': (raw['manu'] ?? raw['manufacturer'] ?? '').toString(),
      'pzwh': (raw['pzwh'] ?? '').toString(),
      'yxq': (raw['yxq'] ?? '').toString(),
      'type': (raw['type'] ?? '').toString(),
      'usage': (raw['usage'] ?? '').toString(),
      'jj': (raw['jj'] ?? '').toString(),
      'source': source,
    };
  }
}

/// 检索结果封装：items 可能为空，reason 说明降级原因
class DrugSearchOutcome {
  final List<Map<String, dynamic>> items;
  final String source;
  final String? reason;

  const DrugSearchOutcome({required this.items, required this.source, this.reason});

  bool get isEmpty => items.isEmpty;
}
