import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/drug_item.dart';
import '../widgets/medicine_safety.dart';

/// 一次主动巡检产生的警报：安全快照 + 触发时间。
///
/// 快照是纯本地规则算好的可复用结论，UI 拿到后直接渲染横幅/角标即可；
/// 调度器不关心 UI 怎么展示，只负责「什么时候该提醒、提醒几次」。
class AgentAlert {
  final SafetySnapshot snapshot;
  final DateTime at;

  const AgentAlert({required this.snapshot, required this.at});
}

/// 家庭用药智能体 —— 主动巡检调度器。
///
/// 把「被动看药箱」升级为「主动巡检提醒」：App 启动后 + 回到前台时各触发一次巡检，
/// 发现过期/临期/重复成分时回调通知 UI（App 内横幅 / 角标）。
///
/// 设计要点：
/// - 单例，全局唯一，避免多处监听生命周期导致重复巡检；
/// - 同类警报 24h 内只报一次，防止用户频繁切后台时被横幅刷屏骚扰；
/// - 所有 IO / 解析异常一律静默吞掉，巡检绝不能让 App 崩。
class AgentScheduler {
  AgentScheduler._();

  static final AgentScheduler instance = AgentScheduler._();

  /// 药箱本地存储 key（与药匣页保持一致）
  static const _drugListKey = 'yaoqingbao_drug_list';

  /// 上次同类警报的时间戳 key（毫秒）
  static const _lastAlertTsKey = 'yaoqingbao_last_alert_ts';

  /// 同类警报最小间隔：24 小时（毫秒）
  static const _throttleMs = 24 * 60 * 60 * 1000;

  /// 当前挂载的上报回调；未挂载时为空，巡检结果只更新内部状态不上报 UI
  void Function(AgentAlert alert)? _onAlert;

  /// 生命周期观察者，负责在「回到前台」时触发巡检
  _LifecycleObserver? _observer;

  int _unread = 0;

  /// 未读警报数：有新的警报待用户查看时为 1，否则为 0
  int get unreadCount => _unread;

  /// 标记已读，清零角标
  void markRead() {
    _unread = 0;
  }

  /// 挂载调度器：立即巡检一次，并监听 App 生命周期，回到前台时再巡检。
  ///
  /// [onAlert] 是警报上报回调，UI 层用它弹横幅 / 刷新角标。
  void start({void Function(AgentAlert alert)? onAlert}) {
    _onAlert = onAlert;
    _observeLifecycle();
    checkNow();
  }

  /// 手动触发一次巡检。同样走 24h 节流，避免被高频调用刷屏。
  Future<void> checkNow() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_drugListKey);
      // 药箱从未写入过或为空：无警报，直接静默返回
      if (raw == null || raw.isEmpty) return;

      final decoded = jsonDecode(raw);
      if (decoded is! List) return;

      // 只评估未回收的条目；已投递回收的不再参与安全判断
      final items = <DrugItem>[];
      for (final e in decoded) {
        if (e is! Map) continue;
        final item = DrugItem.fromJson(Map<String, dynamic>.from(e));
        if (item.recycled == 0) items.add(item);
      }

      final snapshot = SafetySnapshot.of(items);
      // 无警报：静默返回，且不重置节流时间戳，让下一次出问题时能立刻报
      if (!snapshot.hasAlert) return;

      final now = DateTime.now().millisecondsSinceEpoch;
      final last = prefs.getInt(_lastAlertTsKey) ?? 0;
      // 距上次同类警报不足 24h，跳过本次上报，避免重复打扰
      if (now - last < _throttleMs) return;

      _unread = 1;
      await prefs.setInt(_lastAlertTsKey, now);
      _onAlert?.call(AgentAlert(snapshot: snapshot, at: DateTime.now()));
    } catch (_) {
      // 降级铁律：任何 IO / 解析异常都静默吞掉，巡检失败绝不影响正常使用
    }
  }

  /// 取消挂载：移除生命周期监听，清空上报回调
  void stop() {
    _removeObserver();
    _onAlert = null;
  }

  void _observeLifecycle() {
    try {
      _removeObserver();
      _observer = _LifecycleObserver(onResumed: () => checkNow());
      WidgetsBinding.instance.addObserver(_observer!);
    } catch (_) {
      // 生命周期监听不可用（如 binding 尚未初始化）时降级为仅手动巡检
      _observer = null;
    }
  }

  void _removeObserver() {
    if (_observer != null) {
      WidgetsBinding.instance.removeObserver(_observer!);
      _observer = null;
    }
  }
}

/// 轻量生命周期观察者：只关心「回到前台」这一件事。
///
/// 之所以不把 AgentScheduler 直接做成 WidgetsBindingObserver，
/// 是因为它是单例且非 Widget，由内部这个小对象承接回调更干净、也便于解绑。
class _LifecycleObserver with WidgetsBindingObserver {
  _LifecycleObserver({required this.onResumed});

  final VoidCallback onResumed;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      onResumed();
    }
  }
}
