/// 安全类型转换工具
///
/// 背景：后端 MyBatis-Plus 返回的字段类型可能随 SQL 变更而漂移（例如 countDown
/// 变成字符串 "365天"、id 变成数字），第三方药品接口更容易返回非标准结构。
/// 原先模型层直接 `json['field'] ?? default` 取值，遇类型不符会抛
/// `TypeError: type 'X' is not a subtype of type 'Y'`，
/// 一旦触发会让整个列表页构建失败（红屏）。
/// 这里的转换函数保证：任何输入都能得到一个类型正确的值，绝不抛异常。

/// 安全取字符串。null → fallback；非 String → toString()
String asStringSafe(dynamic value, [String fallback = '']) {
  if (value == null) return fallback;
  if (value is String) return value;
  return value.toString();
}

/// 安全取整数。null / 非法字符串 → fallback；double / 数字串 → 截断取整数
int asIntSafe(dynamic value, [int fallback = 0]) {
  if (value == null) return fallback;
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim()) ?? fallback;
  return fallback;
}

/// 安全取小数
double asDoubleSafe(dynamic value, [double fallback = 0.0]) {
  if (value == null) return fallback;
  if (value is num) return value.toDouble();
  if (value is String) return double.tryParse(value.trim()) ?? fallback;
  return fallback;
}
