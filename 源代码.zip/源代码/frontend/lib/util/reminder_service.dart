import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import '../data/drug_item.dart';

/// 到期提醒服务（本地推送通知）。
///
/// 与 [CalendarService] 分工：服药计划闹钟交给系统日历，到期提醒走本地通知。
/// 全程 try/catch 降级，通知失败绝不影响主流程。
class ReminderService {
  ReminderService._();

  static final ReminderService instance = ReminderService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _inited = false;

  static const String _channelId = 'yaoqingbao_expiry';
  static const String _channelName = '药品到期提醒';

  Future<void> init() async {
    if (_inited) return;
    try {
      tzdata.initializeTimeZones();
      try {
        final name = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(name));
      } catch (_) {
        tz.setLocalLocation(tz.getLocation('Asia/Shanghai'));
      }
      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher'),
        ),
      );
      _inited = true;
    } catch (_) {
      // 通知初始化失败：静默，后续 schedule 都走 try 兜底
    }
  }

  /// 请求通知权限（Android 13+ 运行时权限）
  Future<void> requestPermission() async {
    try {
      await init();
      await _plugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
    } catch (_) {}
  }

  /// 根据药箱重新排期到期提醒（T-10 天一次 + 窗口内每日一次）。
  ///
  /// 每次药箱变化后调用，先清空旧通知再按当前数据重排。
  Future<void> scheduleExpiryReminders(List<DrugItem> items) async {
    await init();
    try {
      await _plugin.cancelAll();
    } catch (_) {}

    final now = DateTime.now();
    final today9 = tz.TZDateTime(tz.local, now.year, now.month, now.day, 9, 0);
    var id = 1000;
    for (final item in items) {
      if (item.recycled == 1 || item.expDays <= 0 || item.produceTime.isEmpty) {
        continue;
      }
      try {
        final produce = DateTime.parse(item.produceTime);
        final expire = produce.add(Duration(days: item.expDays));
        final remainingDays = expire.difference(now).inDays;
        if (remainingDays <= 0) continue;

        if (remainingDays <= 10) {
          // 窗口内：每日 9 点提醒一次
          final next = today9.isAfter(now) ? today9 : today9.add(const Duration(days: 1));
          await _plugin.zonedSchedule(
            id++,
            '药品即将到期',
            '${item.medicineName} 还有 $remainingDays 天到期，请及时处理',
            next,
            _details(),
            uiLocalNotificationDateInterpretation:
                UILocalNotificationDateInterpretation.wallClockTime,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
            matchDateTimeComponents: DateTimeComponents.time,
          );
        } else {
          // 未进窗口：到期前 10 天提醒一次
          final remind = expire.subtract(const Duration(days: 10));
          final at = tz.TZDateTime(
              tz.local, remind.year, remind.month, remind.day, 9, 0);
          await _plugin.zonedSchedule(
            id++,
            '药品到期提醒',
            '${item.medicineName} 将在 10 天后到期，请留意',
            at,
            _details(),
            uiLocalNotificationDateInterpretation:
                UILocalNotificationDateInterpretation.wallClockTime,
            androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          );
        }
      } catch (_) {
        // 单条排期失败不影响其它
      }
    }
  }

  NotificationDetails _details() => const NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          _channelName,
          channelDescription: '药清宝药品到期提醒',
          importance: Importance.high,
          priority: Priority.high,
        ),
      );
}
