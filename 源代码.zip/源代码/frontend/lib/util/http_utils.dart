import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';

/// HTTP 工具类 — 单例模式
/// V2 改动：去除假 Token，不再注入 Authorization 头
/// V3 改动：新增错误分类 describeError，区分「无网络 / 超时 / 服务端故障 / 请求错误」，
///          调试模式下打印完整请求错误日志，便于真机 Logcat 排查
class HttpUtils {
  static final HttpUtils _instance = HttpUtils._internal();
  factory HttpUtils() => _instance;
  late Dio dio;

  HttpUtils._internal() {
    BaseOptions options = BaseOptions(
      baseUrl: 'http://121.41.65.114:8081',
      // 由 30s 收紧到 8s：移动端弱网下及时失败并走降级，避免界面长时间卡在加载态
      connectTimeout: const Duration(seconds: 8),
      receiveTimeout: const Duration(seconds: 8),
      sendTimeout: const Duration(seconds: 8),
      headers: {'Content-Type': 'application/json'},
    );
    dio = Dio(options);
    dio.interceptors.add(
      InterceptorsWrapper(
        onResponse: (response, handler) {
          // 业务层统一解析 {code,msg,data}，HTTP 200 也可能包含业务错误。
          return handler.next(response);
        },
        onError: (DioException error, handler) {
          return handler.next(error);
        },
      ),
    );
    // 可观测性：调试/Profile 下把每个失败请求的完整信息打到日志，
    // 真机上用 adb logcat -s flutter 即可看到失败的具体原因
    assert(() {
      dio.interceptors.add(
        InterceptorsWrapper(
          onError: (e, handler) {
            debugPrint(
              '[药清宝·网络] ${e.requestOptions.method} '
              '${e.requestOptions.uri} → type=${e.type.name} '
              'status=${e.response?.statusCode} err=${e.error}',
            );
            return handler.next(e);
          },
        ),
      );
      return true;
    }());
  }

  /// 将网络层异常分类为可直接展示给用户的中文提示。
  /// 核心原则：只有「手机真的没网 / 连不上服务器」才提示检查网络；
  /// 服务器返回 4xx/5xx 属于服务端问题，不应让用户去检查自己的网络。
  static String describeError(Object error) {
    if (error is DioException) {
      switch (error.type) {
        case DioExceptionType.connectionTimeout:
        case DioExceptionType.sendTimeout:
        case DioExceptionType.receiveTimeout:
        case DioExceptionType.transformTimeout:
          return '连接超时';
        case DioExceptionType.connectionError:
          // 底层通常是 SocketException：无网络、DNS 失败、端口不通
          return '网络连接不可用，请检查网络';
        case DioExceptionType.badCertificate:
          return '安全证书校验失败';
        case DioExceptionType.cancel:
          return '请求已取消';
        case DioExceptionType.badResponse:
          final code = error.response?.statusCode ?? 0;
          if (code >= 500) return '服务器开小差（$code），请稍后重试';
          if (code == 404) return '服务接口不存在（404）';
          return '请求失败（$code）';
        case DioExceptionType.unknown:
          // 部分无网场景异常不携带类型，统一按不可用处理
          return '网络连接不可用，请检查网络';
      }
    }
    return '网络异常，请稍后重试';
  }

  Future<Response> get(String path, {Map<String, dynamic>? params}) async {
    return _withRetry(() => dio.get(path, queryParameters: params));
  }

  Future<Response> post(String path, {dynamic data}) async {
    return _withRetry(() => dio.post(path, data: data));
  }

  Future<Response> _withRetry(Future<Response> Function() request) async {
    DioException? last;
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        return await request();
      } on DioException catch (e) {
        last = e;
        final retryable = e.type == DioExceptionType.connectionTimeout ||
            e.type == DioExceptionType.receiveTimeout ||
            e.type == DioExceptionType.sendTimeout ||
            e.type == DioExceptionType.connectionError;
        if (!retryable || attempt == 1) rethrow;
        await Future<void>.delayed(const Duration(milliseconds: 250));
      }
    }
    throw last ?? DioException(requestOptions: RequestOptions());
  }

  /// 删除资源：query 传简单参数，data 传请求体（批量删除的 id 数组走 body）
  Future<Response> delete(
    String path, {
    Map<String, dynamic>? params,
    dynamic data,
  }) async {
    return _withRetry(
      () => dio.delete(path, queryParameters: params, data: data),
    );
  }
}
