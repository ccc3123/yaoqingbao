import 'dart:io';

import 'package:record/record.dart';

import 'zhipu_service.dart';

/// 语音识别失败原因。
///
/// 枚举覆盖全部可能失败场景，但对外只在「无麦克风权限」时抛 [SpeechException]，
/// 其余失败（断网、无 Key、插件缺失、空录音）一律静默返回 null，
/// 由上层回退到手动键盘输入，保证任何情况下不崩。
enum SpeechFailure {
  /// 未授予麦克风权限（唯一会抛异常的失败）
  noPermission,

  /// 未配置智谱 API Key（ZhipuService 内部已兜底为 null，这里仅作枚举保留）
  noKey,

  /// 录音文件为空 / 转录结果为空
  empty,

  /// 用户主动取消录音
  cancelled,

  /// 其它未知错误
  error,
}

/// 语音识别异常。
///
/// 仅 [SpeechFailure.noPermission] 会抛出；其余失败不抛异常，避免上层崩溃。
class SpeechException implements Exception {
  final SpeechFailure reason;
  const SpeechException(this.reason);

  @override
  String toString() => 'SpeechException($reason)';
}

/// 语音输入服务：封装「录音 + 智谱 ASR 转文字」。
///
/// 用于「口述药品名 → 文字」场景。职责边界刻意收窄：
///  - 只负责把用户说的话转成字符串，**不生成任何医疗字段**；
///  - 适应症 / 用法用量 / 禁忌 / 贮藏 / 成分 只能来自官方说明书原文，
///    语音转写天然不涉此红线，本类也不做任何内容上的补全或推断。
///
/// 降级铁律：断网、无 Key、录音失败、转录失败，一律返回 null，
/// 绝不把异常抛到 UI 层。
class SpeechService {
  final AudioRecorder _recorder = AudioRecorder();

  /// 录音临时文件路径。固定单文件、每次覆盖，避免 systemTemp 里累积残留。
  String get _tempPath => '${Directory.systemTemp.path}/yqb_speech.wav';

  bool _isRecording = false;

  SpeechService();

  /// 是否正在录音。
  ///
  /// 用自维护的标志位而非 recorder 的查询接口：record 不同版本的
  /// `isRecording` 签名（getter / Future 方法）不一致，自己记录最稳。
  bool get isRecording => _isRecording;

  /// 检查麦克风权限。任何异常都视为无权限，返回 false。
  Future<bool> get hasPermission async {
    try {
      return await _recorder.hasPermission();
    } catch (_) {
      return false;
    }
  }

  /// 开始录音。
  ///
  /// 无麦克风权限时抛 [SpeechException(SpeechFailure.noPermission)]；
  /// 其它启动失败静默吞掉，`isRecording` 保持 false，由 UI 侧自然降级。
  Future<void> start() async {
    if (_isRecording) return; // 已在录音，幂等返回，避免重复 start 报错
    if (!await hasPermission) {
      throw const SpeechException(SpeechFailure.noPermission);
    }
    try {
      await _recorder.start(
        const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000),
        path: _tempPath,
      );
      _isRecording = true;
    } catch (_) {
      // 启动失败（如平台不支持 wav 编码）：不抛异常，保持 isRecording=false
    }
  }

  /// 停止录音并转文字。
  ///
  /// 流程：stop() 拿路径 → 读字节 → [ZhipuService.transcribe]。
  /// 空录音 / 转录失败 / 任何异常一律返回 null，临时文件在 finally 中兜底清理。
  Future<String?> stopAndRecognize() async {
    if (!_isRecording) return null;
    _isRecording = false;

    final String? path = await _stop();
    if (path == null || path.isEmpty) {
      await _deleteTempFile();
      return null;
    }

    try {
      final bytes = await File(path).readAsBytes();
      if (bytes.isEmpty) return null;
      return await ZhipuService().transcribe(bytes);
    } catch (_) {
      // 读文件 / 转录异常：静默返回 null，由调用方回退键盘输入
      return null;
    } finally {
      await _deleteTempFile();
    }
  }

  /// 取消录音：停止但**不做识别**，并清理临时文件。
  Future<void> cancel() async {
    if (!_isRecording) {
      await _deleteTempFile();
      return;
    }
    _isRecording = false;
    await _stop();
    await _deleteTempFile();
  }

  /// 释放录音资源。
  Future<void> dispose() async {
    _isRecording = false;
    try {
      await _recorder.dispose();
    } catch (_) {
      // dispose 失败不影响退出
    }
    await _deleteTempFile();
  }

  /// 停止录音并安全取回文件路径。
  ///
  /// record 插件不同版本的 `stop()` 返回类型有差异，这里用 `as String?`
  /// 做安全转换，任何异常一律返回 null。
  Future<String?> _stop() async {
    try {
      final dynamic path = await _recorder.stop();
      return path as String?;
    } catch (_) {
      return null;
    }
  }

  /// 清理临时文件。删除失败静默忽略，残留文件不影响主流程。
  Future<void> _deleteTempFile() async {
    try {
      final f = File(_tempPath);
      if (await f.exists()) {
        await f.delete();
      }
    } catch (_) {
      // 忽略清理失败
    }
  }
}
