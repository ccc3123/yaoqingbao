import '../data/drug_item.dart';
import 'expiry_rule.dart';

/// 单条回收明细。
///
/// 把「该不该回收」与「为什么回收」绑在一起返回给 UI，
/// 这样列表页无需再二次调用 ExpiryRule 去反推等级。
class RecycleItem {
  final DrugItem item;
  final ExpiryLevel level;
  final String reason;

  const RecycleItem({
    required this.item,
    required this.level,
    required this.reason,
  });
}

/// 一次一键回收生成的完整清单。
///
/// 纯内存对象、无 IO：既方便单测，也保证断网时依旧能离线规划。
class RecyclePlan {
  final List<RecycleItem> items;
  final int expiredCount;
  final int nearExpiryCount;
  final List<String> categorySummary;
  final String headline;

  const RecyclePlan({
    required this.items,
    required this.expiredCount,
    required this.nearExpiryCount,
    required this.categorySummary,
    required this.headline,
  });

  bool get isEmpty => items.isEmpty;
}

/// 回收调度规划器（纯本地逻辑）。
///
/// 一键回收时读整箱药品、筛出「已过期 + 临期」项并按品类聚合。
/// 之所以不放服务端：回收清单本质是本地确定计算，交给网络既慢又徒增断网风险。
class RecyclePlanner {
  RecyclePlanner._();

  /// 主入口：从整箱药品中规划出本次建议回收的清单。
  static RecyclePlan plan(List<DrugItem> items) {
    final recycleItems = <RecycleItem>[];
    var expired = 0;
    var danger = 0;
    var warn = 0;

    for (final item in items) {
      // 已投递回收的条目不再进入候选，避免重复规划。
      if (item.recycled != 0) continue;

      // 单条数据异常（如 countDown 脏值）只跳过该条，不拖垮整箱规划。
      try {
        final verdict = ExpiryRule.judge(
          remainDays: item.countDown,
          drugName: item.medicineName,
          openedDays: item.openedDays,
        );

        final reason = _reasonFor(verdict.level);
        if (reason == null) continue; // safe / notice 级别无需回收

        recycleItems.add(
          RecycleItem(item: item, level: verdict.level, reason: reason),
        );

        // 按等级分组计数，供后面的中文摘要使用。
        switch (verdict.level) {
          case ExpiryLevel.expired:
            expired++;
            break;
          case ExpiryLevel.danger:
            danger++;
            break;
          case ExpiryLevel.warn:
            warn++;
            break;
          default:
            break;
        }
      } catch (_) {
        // 兜底：绝不外抛，脏数据当作「无需回收」处理。
      }
    }

    final summary = <String>[];
    if (expired > 0) summary.add('已过期 $expired 种');
    if (danger > 0) summary.add('7天内到期 $danger 种');
    if (warn > 0) summary.add('30天内到期 $warn 种');

    final headline = recycleItems.isEmpty
        ? '药箱暂无需要回收的药品'
        : '共 ${recycleItems.length} 种药品建议回收';

    return RecyclePlan(
      items: recycleItems,
      expiredCount: expired,
      nearExpiryCount: danger + warn,
      categorySummary: summary,
      headline: headline,
    );
  }

  /// 等级 → 给用户看的回收原因文案。
  ///
  /// 返回 null 表示该等级不纳入回收（safe / notice），
  /// 由调用方据此跳过，避免把「可继续存放」的药品也推进回收口。
  static String? _reasonFor(ExpiryLevel level) {
    switch (level) {
      case ExpiryLevel.expired:
        return '已过期，请勿服用';
      case ExpiryLevel.danger:
        return '即将到期，建议优先回收';
      case ExpiryLevel.warn:
        return '临近有效期';
      default:
        return null;
    }
  }
}
