import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:sqflite/sqflite.dart';

import '../data/medicine.dart';
import 'safe_cast.dart';

/// 条码归一化：去掉空格与连字符。
/// 部分扫码器会在结果里附带空白或分组横线。
String normalizeBarcode(String input) {
  return input.replaceAll(RegExp(r'[\s\-]'), '');
}

/// 条码类别： 1=69开头13位商品码  2=其他13位  3=20位追溯码  4=其他长度
int classifyBarcode(String code) {
  if (code.length == 20) return 3;
  if (code.length == 13) return code.startsWith('69') ? 1 : 2;
  if (code.length == 14) return 2;
  return 4;
}

/// 查询候选条码。
///
/// 同一盒药在不同的扫码工具下可能给出不同位数：EAN-13 偶尔被截断成 UPC-A（去掉首位），
/// 也可能被补零成 14 位。这里只对最常见的一两种变形做兜底，避免无意义的全表扫描。
List<String> barcodeVariants(String raw) {
  final code = normalizeBarcode(raw);
  if (code.isEmpty) return const <String>[];
  final out = <String>[code];
  void add(String v) {
    if (v.isNotEmpty && !out.contains(v)) out.add(v);
  }

  if (code.length == 13) {
    add(code.substring(1)); // EAN-13 -> UPC-A 形态
  } else if (code.length == 12) {
    add('0$code'); // UPC-A -> EAN-13 形态
  } else if (code.length == 14 && code.startsWith('0')) {
    add(code.substring(1));
  }
  return out;
}

/// 离线药品条码库。
///
/// 数据来自开源库 EricLiuCN/barcode（截至 2023-09-07，药品条码 4 万余条），
/// 由 `tools/build_medicine_db.py` 在**构建前**转换为 SQLite 后随包下发。
/// 这样做的原因：App 运行时解析 84MB 的 MySQL dump 会让冷启动增加 15~40 秒，
/// 而且需要手写 SQL 方言翻译器，数据源一旦变更就会全线崩溃。
///
/// 全部查询只读、离线可用，不依赖网络与后端。
class DrugDb {
  DrugDb._();

  static final DrugDb instance = DrugDb._();

  static const String _assetPath = 'assets/data/medicine.db';
  static const String _fileName = 'medicine.db';
  static const int _chunkSize = 256 * 1024;

  Database? _db;
  Completer<Database?>? _opening;
  double _progress = 0.0;

  /// 是否已就绪。UI 可据此隐藏尚未可用的入口。
  bool get isReady => _db != null;

  /// 总开关。单元测试里置 false，避免 29MB 的包体拷贝拖垮 widget 测试。
  static bool enabled = true;

  /// 初始化进度 0.0 ~ 1.0，供启动页展示。
  double get progress => _progress;

  /// 记录数缓存，避免重复 COUNT(*)。
  int? _cachedCount;

  /// 等待就绪。查询前统一走这里，即使初始化尚未完成也不会抛异常。
  Future<Database?> get ready async {
    final db = _db;
    if (db != null) return db;
    return init();
  }

  /// 初始化：把 assets 中的库释放到私有目录并只读打开。
  ///
  /// - 已存在且非强制时直接复用，不重复拷贝
  /// - `onProgress` 只在真正拷贝时回调，用于启动页进度条
  /// - **任何异常都不向外抛**，返回 null 让调用方降级，保证赛点演示不闪退
  Future<Database?> init({
    void Function(double progress)? onProgress,
    bool force = false,
  }) async {
    final existing = _db;
    if (existing != null && !force) {
      onProgress?.call(1.0);
      return existing;
    }
    // 关闭时直接返回 null，让所有查询走「未命中」分支并降级到下一数据源。
    if (!enabled) return null;
    final opening = _opening;
    if (opening != null && !force) return opening.future;

    final completer = Completer<Database?>();
    _opening = completer;
    try {
      final dir = await getDatabasesPath();
      final target = File('$dir${Platform.pathSeparator}$_fileName');
      if (force || !await target.exists()) {
        await _copyFromAsset(target, onProgress);
      } else {
        _progress = 1.0;
        onProgress?.call(1.0);
      }
      _db = await openDatabase(
        target.path,
        readOnly: true,
        singleInstance: true,
      );
      completer.complete(_db);
    } catch (_) {
      _db = null;
      completer.complete(null);
    } finally {
      _opening = null;
    }
    return completer.future;
  }

  /// 从 assets 流式落盘。先写 .tmp 再 rename，
  /// 避免中途失败留下半个文件导致下次启动打开异常库。
  Future<void> _copyFromAsset(
      File target, void Function(double)? onProgress) async {
    final ByteData data = await rootBundle.load(_assetPath);
    final Uint8List bytes =
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
    final int total = bytes.length;
    if (total == 0) return;

    final tmp = File('${target.path}.tmp');
    if (await tmp.exists()) {
      await tmp.delete();
    }
    await tmp.parent.create(recursive: true);

    final sink = tmp.openWrite();
    try {
      for (var offset = 0; offset < total; offset += _chunkSize) {
        final end = offset + _chunkSize > total ? total : offset + _chunkSize;
        sink.add(Uint8List.sublistView(bytes, offset, end));
        await sink.flush();
        _progress = end / total;
        onProgress?.call(_progress);
      }
    } finally {
      await sink.close();
    }

    if (await target.exists()) {
      await target.delete();
    }
    await tmp.rename(target.path);
    _progress = 1.0;
    onProgress?.call(1.0);
  }

  /// 按条码精确查询。命中返回药品详情（含说明书官方原文），未命中返回 null。
  Future<Medicine?> lookupByBarcode(String rawCode) async {
    for (final code in barcodeVariants(rawCode)) {
      final row = await _lookupOne(code);
      if (row != null) return row;
    }
    return null;
  }

  Future<Medicine?> _lookupOne(String code) async {
    final db = await ready;
    if (db == null) return null;
    try {
      final rows = await db.query(
        'drug',
        where: 'barcode = ?',
        whereArgs: [code],
        limit: 1,
      );
      if (rows.isEmpty) return null;
      return Medicine.fromDbRow(rows.first);
    } catch (_) {
      return null;
    }
  }

  /// 按名称 / 别名 / 通用名 / 拼音模糊检索。
  ///
  /// 仅供降级使用：优先走条码精确命中。结果按名称长度升序，
  /// 让更贴合用户输入的短名称排在前面。
  Future<List<Medicine>> searchByName(
    String keyword, {
    int limit = 20,
  }) async {
    final kw = keyword.trim();
    if (kw.isEmpty) return const <Medicine>[];
    final db = await ready;
    if (db == null) return const <Medicine>[];
    try {
      final like = '%$kw%';
      final rows = await db.query(
        'drug',
        where: 'name LIKE ? OR name_norm LIKE ? OR alias LIKE ? OR pinyin LIKE ?',
        whereArgs: [like, like, like, like],
        orderBy: 'LENGTH(name) ASC',
        limit: limit,
      );
      return rows.map(Medicine.fromDbRow).toList(growable: false);
    } catch (_) {
      return const <Medicine>[];
    }
  }

  /// 全量药品名（仅 name / name_norm / alias / barcode 四列）。
  ///
  /// 供模糊匹配的编辑距离兜底：只取最小字段集，避免把 4.7 万行的
  /// 说明书全文一次性加载进内存。编辑距离命中后按 barcode 回查完整说明书。
  Future<List<Map<String, Object?>>> allNames() async {
    final db = await ready;
    if (db == null) return const <Map<String, Object?>>[];
    try {
      return await db.query('drug',
          columns: ['barcode', 'name', 'name_norm', 'alias']);
    } catch (_) {
      return const <Map<String, Object?>>[];
    }
  }

  /// 库存记录数。用于健康角的自检与答辩数据口径。
  Future<int> rowCount() async {
    final cached = _cachedCount;
    if (cached != null) return cached;
    final db = await ready;
    if (db == null) return 0;
    try {
      final rows = await db.rawQuery('SELECT COUNT(*) AS c FROM drug');
      final count = asIntSafe(rows.isNotEmpty ? rows.first['c'] : 0);
      _cachedCount = count;
      return count;
    } catch (_) {
      return 0;
    }
  }

  /// 数据版本信息（meta 表），用于答辩说明数据来源与时效。
  Future<Map<String, String>> meta() async {
    final db = await ready;
    if (db == null) return const <String, String>{};
    try {
      final rows = await db.query('meta');
      return <String, String>{
        for (final r in rows)
          asStringSafe(r['k']): asStringSafe(r['v']),
      };
    } catch (_) {
      return const <String, String>{};
    }
  }

  Future<void> close() async {
    final db = _db;
    if (db != null) {
      await db.close();
      _db = null;
      _cachedCount = null;
    }
  }
}
