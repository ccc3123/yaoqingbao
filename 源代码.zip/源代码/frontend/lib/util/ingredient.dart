import 'safe_cast.dart';

/// 冲突提醒的强度。
enum ConflictLevel {
  /// 词典精确命中，可信度高，红色强提醒
  strong,

  /// 推断得到，需用户核对，紫色弱提醒
  weak,
}

/// 一条成分冲突提醒。
class IngredientConflict {
  const IngredientConflict({
    required this.canonical,
    required this.display,
    required this.drugNames,
    required this.level,
    required this.reason,
  });

  /// 规范化成分标识
  final String canonical;

  /// 展示给用户的成分名
  final String display;

  /// 涉及该成分的药品名
  final List<String> drugNames;

  final ConflictLevel level;

  /// 为什么判定为重复（用于 UI 的次级说明）
  final String reason;
}

/// 词典条目：规范名 + 别名（含常见商品名）。
class IngredientTerm {
  const IngredientTerm(this.canonical, this.aliases);

  /// 规范化成分名（中文通用名）
  final String canonical;

  /// 别名列表，包含商品名与英文通用名。
  /// 别名必须足够长以避免误命中（例如不要用单字"芬"）。
  final List<String> aliases;
}

/// 家庭常备药成分词典。
///
/// 数据来源原则：**只登记确定性的名称对应关系**，不登记疗效描述。
/// 这样检测出的成分全部来自药盒上的真实文字，而不是模型猜测，
/// 从而规避「AI 幻觉 -> 医疗误导」这一红线风险。
///
/// 后续可通过 assets/data/ingredient_dict.json 扩展，这里保留常用量即可覆盖家庭场景。
const List<IngredientTerm> kIngredientDict = [
  // ---------------- 解热镇痛（最容易出现重复摄入的一类）
  IngredientTerm('布洛芬', ['布洛芬', '芬必得', '美林', 'Ibuprofen']),
  IngredientTerm('对乙酰氨基酚', [
    '对乙酰氨基酚', '扑热息痛', '泰诺林', '泰诺', '百服咛', 'Paracetamol'
  ]),
  IngredientTerm('阿司匹林', ['阿司匹林', '乙酰水杨酸', 'Aspirin', '拜阿司匹灵']),
  IngredientTerm('双氯芬酸', ['双氯芬酸', '扶他林', 'Diclofenac']),
  IngredientTerm('洛索洛芬', ['洛索洛芬', '乐松']),
  IngredientTerm('塞来昔布', ['塞来昔布', '西乐葆']),
  IngredientTerm('萘普生', ['萘普生', 'Naproxen']),
  IngredientTerm('吲哚美辛', ['吲哚美辛', '消炎痛']),
  IngredientTerm('氨基比林', ['氨基比林', '安乃近', '去痛片']),
  IngredientTerm('尼美舒利', ['尼美舒利']),

  // ---------------- 感冒复方成分
  IngredientTerm('伪麻黄碱', ['伪麻黄碱', '新康泰克', '白加黑', '日夜百服']),
  IngredientTerm('氯苯那敏', ['氯苯那敏', '扑尔敏']),
  IngredientTerm('氯雷他定', ['氯雷他定', '开瑞坦', '息斯敏', 'Loratadine']),
  IngredientTerm('西替利嗪', ['西替利嗪', '仙特明', '西替立嗪']),
  IngredientTerm('依巴斯汀', ['依巴斯汀', '开思亭']),
  IngredientTerm('非索非那定', ['非索非那定', '莱多菲']),
  IngredientTerm('右美沙芬', ['右美沙芬', '氢溴酸右美沙芬']),
  IngredientTerm('愈创甘油醚', ['愈创甘油醚', '愈创木酚']),
  IngredientTerm('金刚烷胺', ['金刚烷胺', '氨酚烷胺', '感康', '快克']),
  IngredientTerm('咖啡因', ['咖啡因', '咖酚伪麻']),

  // ---------------- 止咳化痰
  IngredientTerm('氨溴索', ['氨溴索', '沐舒坦', 'Ambroxol']),
  IngredientTerm('乙酰半胱氨酸', ['乙酰半胱氨酸', '富露施', '易维适']),
  IngredientTerm('可待因', ['可待因', '联邦止咳露', '复方磷酸可待因']),
  IngredientTerm('复方甘草', ['复方甘草', '甘草片']),

  // ---------------- 抗生素
  IngredientTerm('阿莫西林', ['阿莫西林', '阿莫仙', 'Amoxicillin', '阿莫西林克拉维']),
  IngredientTerm('头孢氨苄', ['头孢氨苄', '先锋四号', '先锋IV']),
  IngredientTerm('头孢克洛', ['头孢克洛', '希刻劳']),
  IngredientTerm('头孢呋辛', ['头孢呋辛', '西力欣']),
  IngredientTerm('头孢克肟', ['头孢克肟', '世福素']),
  IngredientTerm('阿奇霉素', ['阿奇霉素', '希舒美', 'Azithromycin']),
  IngredientTerm('克拉霉素', ['克拉霉素', '克拉仙']),
  IngredientTerm('罗红霉素', ['罗红霉素', '罗力得']),
  IngredientTerm('左氧氟沙星', ['左氧氟沙星', '可乐必妥', '利复星']),
  IngredientTerm('诺氟沙星', ['诺氟沙星', '氟哌酸']),
  IngredientTerm('莫西沙星', ['莫西沙星', '拜复乐']),
  IngredientTerm('甲硝唑', ['甲硝唑', '灭滴灵']),
  IngredientTerm('替硝唑', ['替硝唑']),
  IngredientTerm('红霉素', ['红霉素', '依托红霉素']),
  IngredientTerm('克林霉素', ['克林霉素', '氯洁霉素']),
  IngredientTerm('复方磺胺甲噁唑', ['磺胺甲噁唑', '复方新诺明', '百定']),

  // ---------------- 消化道
  IngredientTerm('奥美拉唑', ['奥美拉唑', '洛赛克', 'Omeprazole']),
  IngredientTerm('雷贝拉唑', ['雷贝拉唑', '波利特']),
  IngredientTerm('泮托拉唑', ['泮托拉唑', '泰美尼克']),
  IngredientTerm('铝碳酸镁', ['铝碳酸镁', '达喜']),
  IngredientTerm('蒙脱石', ['蒙脱石', '思密达']),
  IngredientTerm('多潘立酮', ['多潘立酮', '吗丁啉']),
  IngredientTerm('莫沙必利', ['莫沙必利', '加斯清']),
  IngredientTerm('法莫替丁', ['法莫替丁', '高舒达']),
  IngredientTerm('雷尼替丁', ['雷尼替丁']),
  IngredientTerm('双歧杆菌', ['双歧杆菌', '培菲康', '贝飞达']),
  IngredientTerm('地衣芽孢杆菌', ['地衣芽孢杆菌', '整肠生']),
  IngredientTerm('枯草杆菌', ['枯草杆菌', '美常安']),
  IngredientTerm('匹维溴铵', ['匹维溴铵', '得舒特']),

  // ---------------- 心血管（处方药，重复危害更大）
  IngredientTerm('硝苯地平', ['硝苯地平', '拜新同', '心痛定']),
  IngredientTerm('氨氯地平', ['氨氯地平', '络活喜', '压氏达']),
  IngredientTerm('美托洛尔', ['美托洛尔', '倍他乐克']),
  IngredientTerm('比索洛尔', ['比索洛尔', '康忻']),
  IngredientTerm('依那普利', ['依那普利', '依苏']),
  IngredientTerm('培哚普利', ['培哚普利', '雅施达']),
  IngredientTerm('缬沙坦', ['缬沙坦', '代文']),
  IngredientTerm('氯沙坦', ['氯沙坦', '科素亚']),
  IngredientTerm('厄贝沙坦', ['厄贝沙坦', '安博维']),
  IngredientTerm('阿托伐他汀', ['阿托伐他汀', '立普妥', '阿乐']),
  IngredientTerm('瑞舒伐他汀', ['瑞舒伐他汀', '可定']),
  IngredientTerm('辛伐他汀', ['辛伐他汀', '舒降之']),
  IngredientTerm('单硝酸异山梨酯', ['单硝酸异山梨酯', '依姆多', '鲁南欣康']),
  IngredientTerm('硝酸甘油', ['硝酸甘油']),
  IngredientTerm('螺内酯', ['螺内酯', '安体舒通']),
  IngredientTerm('氢氯噻嗪', ['氢氯噻嗪', '双氢克尿噻']),
  IngredientTerm('呋塞米', ['呋塞米', '速尿']),
  IngredientTerm('地高辛', ['地高辛']),
  IngredientTerm('华法林', ['华法林']),

  // ---------------- 内分泌
  IngredientTerm('二甲双胍', ['二甲双胍', '格华止', 'Metformin']),
  IngredientTerm('格列美脲', ['格列美脲', '亚莫利']),
  IngredientTerm('格列齐特', ['格列齐特', '达美康']),
  IngredientTerm('格列吡嗪', ['格列吡嗪', '美吡达']),
  IngredientTerm('阿卡波糖', ['阿卡波糖', '拜唐苹']),
  IngredientTerm('达格列净', ['达格列净', '安达唐']),
  IngredientTerm('恩格列净', ['恩格列净', '欧唐静']),
  IngredientTerm('西格列汀', ['西格列汀', '捷诺维']),
  IngredientTerm('利拉鲁肽', ['利拉鲁肽', '诺和力']),

  // ---------------- 外用
  IngredientTerm('莫匹罗星', ['莫匹罗星', '百多邦']),
  IngredientTerm('酮康唑', ['酮康唑', '金达克宁']),
  IngredientTerm('特比萘芬', ['特比萘芬', '兰美抒']),
  IngredientTerm('糠酸莫米松', ['糠酸莫米松', '艾洛松']),
  IngredientTerm('氢化可的松', ['氢化可的松']),
  IngredientTerm('双氯芬酸二乙胺', ['双氯芬酸二乙胺', '扶他林软膏']),

  // ---------------- 神经营养与其它
  IngredientTerm('甲钴胺', ['甲钴胺', '弥可保']),
  IngredientTerm('谷维素', ['谷维素']),
  IngredientTerm('氨基葡萄糖', ['氨基葡萄糖', '维固力']),
];

/// 剂型后缀，用于把药品名还原为可读的有效成分串。
const List<String> kFormSuffixes = [
  '缓释片', '控释片', '肠溶片', '分散片', '咀嚼片', '泡腾片', '薄膜衣片',
  '口腔崩解片', '含片', '片剂', '片',
  '缓释胶囊', '肠溶胶囊', '软胶囊', '胶囊剂', '胶囊',
  '颗粒剂', '颗粒', '干混悬剂', '混悬液', '口服溶液', '口服液', '溶液剂',
  '注射液', '注射剂', '粉针剂',
  '软膏剂', '软膏', '乳膏', '凝胶', '乳胶剂', '贴剂', '贴膏',
  '糖浆', '糖浆剂', '丸剂', '丸', '滴眼液', '眼药水', '滴耳液', '滴鼻液',
  '散剂', '散', '茶剂', '酊', '栓剂', '栓',
];

/// 去掉剂型后缀与剂量信息，得到更接近「通用名」的文本。
String extractCoreName(String raw) {
  var text = raw.trim();
  if (text.isEmpty) return '';

  // 去掉括号里的商品名——但商品名本身就是重要别名来源，
  // 因此在做成分匹配时会用完整原文，这里只是为了得到干净的核心名用于展示。
  text = text.replaceAll(RegExp(r'[（(][^（）()]*[）)]'), '');

  // 去掉剂量与包装：0.1g*12片 / 10mg*24粒 / 250ml 等
  text = text.replaceAll(RegExp(r'[0-9０-９]+(\.[0-9]+)?\s*(mg|g|ml|ug|μg|IU|%)', caseSensitive: false), '');
  text = text.replaceAll(RegExp(r'\*[0-9０-９]+[^ ]*'), '');
  text = text.replaceAll(RegExp(r'[0-9０-９]+'), '');

  // 反复剥离已知剂型后缀（如「缓释片」要先于「片」被匹配）
  for (final suffix in kFormSuffixes) {
    if (text.length > suffix.length && text.endsWith(suffix)) {
      text = text.substring(0, text.length - suffix.length);
      break;
    }
  }
  return text.trim();
}

/// 成分检测器。
class IngredientDetector {
  IngredientDetector._();

  /// 在给定文本中查找已知成分。
  ///
  /// 传入的文本应当尽量完整（药品名 + 商品名 + 说明书主要成份原文），
  /// 因为很多药只印商品名（如「芬必得」），通用名反而不显眼。
  static Set<String> detect(String text) {
    if (text.trim().isEmpty) return <String>{};
    final Set<String> hits = <String>{};
    for (final term in kIngredientDict) {
      for (final alias in term.aliases) {
        if (alias.isEmpty) continue;
        if (text.contains(alias)) {
          hits.add(term.canonical);
          break;
        }
      }
    }
    return hits;
  }

  /// 取可展示名：优先返回规范名。
  static String displayOf(String canonical) {
    for (final term in kIngredientDict) {
      if (term.canonical == canonical) return term.canonical;
    }
    return canonical;
  }
}

/// 药匣条目参与检测所需的最小信息。
class MedicineEntry {
  const MedicineEntry({
    required this.name,
    this.component,
    this.manu,
  });

  final String name;
  final String? component;

  /// 同一厂家同名不同规格不算重复世界观下的异常，这里仅作展示备用
  final String? manu;
}

/// 重复成分检测。
///
/// 结果分为两级：
///  - [ConflictLevel.strong]：在药品名或说明书原文中直接读到成分 -> 红色强提醒
///  - [ConflictLevel.weak]：名称完全一致（疑似同一盒药重复登记） -> 弱提醒
class DuplicateChecker {
  DuplicateChecker._();

  /// [entries] 为药匣中尚未回收的药品列表。
  static List<IngredientConflict> check(List<MedicineEntry> entries) {
    final Map<String, List<String>> byIngredient = <String, List<String>>{};
    final Map<String, Set<String>> seenNames = <String, Set<String>>{};

    for (final entry in entries) {
      final String name = asStringSafe(entry.name);
      if (name.isEmpty) continue;

      // 同时匹配「名称 + 商品名 + 厂家」与「说明书主要成份」
      final String haystack =
          '$name ${entry.component ?? ''} ${entry.manu ?? ''}';
      final Set<String> hits = IngredientDetector.detect(haystack);
      for (final canonical in hits) {
        byIngredient.putIfAbsent(canonical, () => <String>[]).add(name);
        seenNames.putIfAbsent(canonical, () => <String>{}).add(name);
      }
    }

    final List<IngredientConflict> out = <IngredientConflict>[];

    // 强提醒：同一成分出现在两种及以上不同药品中
    for (final entry in byIngredient.entries) {
      final names = entry.value.toSet().toList()..sort();
      if (names.length < 2) continue;
      out.add(IngredientConflict(
        canonical: entry.key,
        display: IngredientDetector.displayOf(entry.key),
        drugNames: names,
        level: ConflictLevel.strong,
        reason: '${names.length} 种药品含同一成分，同时服用可能摄入过量',
      ));
    }

    // 弱提醒：完全同名的重复登记
    final Map<String, int> nameCount = <String, int>{};
    for (final entry in entries) {
      final String name = asStringSafe(entry.name).trim();
      if (name.isEmpty) continue;
      nameCount[name] = (nameCount[name] ?? 0) + 1;
    }
    for (final n in nameCount.entries) {
      if (n.value >= 2) {
        out.add(IngredientConflict(
          canonical: 'duplicate:${n.key}',
          display: n.key,
          drugNames: <String>[n.key],
          level: ConflictLevel.weak,
          reason: '药匣中重复登记了 ${n.value} 次，可合并避免误判过期',
        ));
      }
    }
    return out;
  }
}
