import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

/// 设备标识工具 — 匿名隔离用
///
/// 药箱记录、家庭协同均按「设备标识」隔离，既满足后端 /medbox、/family
/// 的入参要求，又不需要用户注册登录（沿用项目既有的匿名设计）。
class DeviceUtils {
  static const _key = 'yaoqingbao_device_id';
  static const _familyKey = 'yaoqingbao_family_code';
  static const _memberKey = 'yaoqingbao_member_id';
  static const _memberNameKey = 'yaoqingbao_member_name';
  static const _uuid = Uuid();

  static String? _cached;

  /// 取本机唯一标识，首次调用时生成并落盘，后续复用
  static Future<String> deviceId() async {
    if (_cached != null && _cached!.isNotEmpty) return _cached!;
    final prefs = await SharedPreferences.getInstance();
    var id = prefs.getString(_key);
    if (id == null || id.isEmpty) {
      id = _uuid.v4();
      await prefs.setString(_key, id);
    }
    _cached = id;
    return id;
  }

  /// 家庭码（家庭协同用，未加入家庭时为空）
  static Future<String> familyCode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_familyKey) ?? '';
  }

  static Future<void> saveFamilyCode(String code) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_familyKey, code);
  }

  /// 家庭成员标识，默认与设备标识一致
  static Future<String> memberId() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString(_memberKey);
    if (id != null && id.isNotEmpty) return id;
    final dev = await deviceId();
    await prefs.setString(_memberKey, dev);
    return dev;
  }

  static Future<String> memberName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_memberNameKey) ?? '';
  }

  static Future<void> saveMember(String id, String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_memberKey, id);
    await prefs.setString(_memberNameKey, name);
  }
}
