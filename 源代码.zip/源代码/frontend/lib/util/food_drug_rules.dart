/// 食物-药物禁忌规则（本地确定性兜底）。
///
/// **定位**：只在断网 / 无 AI 时兜底，绝不取代联网 AI 的丰富建议。
/// 联网时由 AI 服药助理联网生成更全面的「酒 / 西柚 / 水果 / 茶 / 咖啡」等禁忌提醒。
/// 这里的数据只做「成分/类别关键词 → 提示语」的确定性映射，不涉诊疗推断。
class FoodDrugRule {
  final String keyword; // 命中药品名/成分/类别里包含该关键词即触发
  final String warning; // 提示语

  const FoodDrugRule(this.keyword, this.warning);
}

const List<FoodDrugRule> kFoodDrugRules = [
  // 抗生素类：忌酒、忌乳制品
  FoodDrugRule('阿莫西林', '服用期间应避免饮酒，酒精可能影响药效并加重不良反应'),
  FoodDrugRule('头孢', '服用头孢类药物期间严禁饮酒，可能引起双硫仑样反应（心慌、面部潮红、呼吸困难）'),
  FoodDrugRule('甲硝唑', '服用甲硝唑期间严禁饮酒，可能引起双硫仑样反应'),
  FoodDrugRule('替硝唑', '服用替硝唑期间严禁饮酒'),
  FoodDrugRule('左氧氟沙星', '喹诺酮类避免与含铝/镁/钙的胃药同服，服药前后 2 小时避免牛奶'),
  FoodDrugRule('诺氟沙星', '避免与含铝/镁/钙的胃药同服，服药前后 2 小时避免牛奶'),
  FoodDrugRule('红霉素', '避免与大量酸性饮料（如橙汁）同服，以免降低药效'),
  FoodDrugRule('克林霉素', '避免与红霉素等同类抗生素合用，注意肠道菌群'),
  // 心血管类：忌西柚、忌大量绿叶菜
  FoodDrugRule('硝苯地平', '避免与西柚（葡萄柚）同食，可能使血药浓度升高引发低血压'),
  FoodDrugRule('氨氯地平', '避免与西柚同食，可能增强降压作用'),
  FoodDrugRule('美托洛尔', '避免与西柚同食，避免突然停药'),
  FoodDrugRule('比索洛尔', '避免与西柚同食，避免突然停药'),
  FoodDrugRule('阿托伐他汀', '避免大量食用西柚（葡萄柚），可能增加肌肉损伤风险'),
  FoodDrugRule('瑞舒伐他汀', '避免大量食用西柚，可能增加不良反应风险'),
  FoodDrugRule('辛伐他汀', '严禁与西柚（葡萄柚）汁同服，可能引发横纹肌溶解'),
  FoodDrugRule('华法林', '保持维生素K摄入稳定，避免突然大量食用菠菜、西兰花等绿叶蔬菜'),
  FoodDrugRule('地高辛', '避免与高纤维食物同服，避免大量食用富含膳食纤维的食物'),
  // 解热镇痛类：忌酒、忌空腹
  FoodDrugRule('布洛芬', '避免空腹服用，避免与酒精同服以免损伤胃黏膜'),
  FoodDrugRule('对乙酰氨基酚', '严禁与酒精同服，可能造成严重肝损伤'),
  FoodDrugRule('阿司匹林', '避免空腹服用，避免与酒精同服，可能刺激胃黏膜'),
  FoodDrugRule('双氯芬酸', '避免空腹服用，避免与酒精同服'),
  FoodDrugRule('塞来昔布', '避免与酒精同服，可能增加胃肠道出血风险'),
  // 内分泌类：二甲双胍忌酒
  FoodDrugRule('二甲双胍', '服用期间避免大量饮酒，可能增加乳酸酸中毒风险'),
  FoodDrugRule('格列美脲', '服药后请按时进餐，避免饮酒以免诱发低血糖'),
  FoodDrugRule('格列齐特', '服药后请按时进餐，避免饮酒以免诱发低血糖'),
  FoodDrugRule('阿卡波糖', '与第一口饭同服效果最佳，避免与含糖饮料同服'),
  // 其它
  FoodDrugRule('铁剂', '避免与茶、咖啡同服，鞣酸会影响铁吸收；与维生素C同服可促进吸收'),
  FoodDrugRule('钙片', '避免与含大量草酸的食物（菠菜）同服，避免与铁剂同服影响吸收'),
  FoodDrugRule('甲状腺素', '清晨空腹服用，与早餐、钙片、铁剂至少间隔 30-60 分钟'),
  FoodDrugRule('降压药', '避免大量饮酒，酒精可能增强降压作用导致低血压'),
];

/// 根据药品文本（药名 + 成分）返回命中的食物禁忌提示。
///
/// 返回去重后的提示语列表；无命中返回空列表。
List<String> matchFoodDrugWarnings(String drugText) {
  if (drugText.trim().isEmpty) return const <String>[];
  final hits = <String>[];
  final seen = <String>{};
  for (final rule in kFoodDrugRules) {
    if (drugText.contains(rule.keyword) && seen.add(rule.keyword)) {
      hits.add('【${rule.keyword}】${rule.warning}');
    }
  }
  return hits;
}
