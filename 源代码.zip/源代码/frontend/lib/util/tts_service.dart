import 'package:flutter_tts/flutter_tts.dart';

/// 语音播报服务 — 朗读说明书原文与巡检警报，服务老年用户
///
/// 设计原则：
/// - 懒初始化 [FlutterTts]，避免在服务构造时触碰原生插件通道（部分设备
///   无 TTS 引擎，过早初始化会触发异常）；
/// - 只朗读调用方传入的官方原文，本服务不做任何内容生成；
/// - 所有异常静默吞掉，TTS 失败不影响主流程（断网、无引擎、插件缺失均不崩）。
class TtsService {
  /// 全局单例，说明书模块与巡检模块复用同一引擎实例，避免重复初始化。
  static final TtsService instance = TtsService._();

  TtsService._();

  /// TTS 引擎实例；首次 [speak] 时才创建，避免服务构造期触碰原生通道。
  FlutterTts? _tts;

  /// 语言是否已初始化标记；[setLanguage] 只在首次朗读前执行一次，
  /// 减少对原生通道的重复调用开销。
  bool _languageReady = false;

  /// 朗读文本。
  ///
  /// 空文本直接返回；首次朗读前初始化一次语言为 zh-CN（面向中文老年用户）。
  /// 任何异常（插件缺失、引擎不可用等）一律静默吞掉，不外抛。
  Future<void> speak(String text) async {
    if (text.isEmpty) {
      return;
    }
    try {
      _tts ??= FlutterTts();
      // 语言只初始化一次，避免反复设置带来的原生通道开销与潜在竞态。
      if (!_languageReady) {
        await _tts!.setLanguage('zh-CN');
        _languageReady = true;
      }
      await _tts!.speak(text);
    } catch (_) {
      // 降级铁律：TTS 属于辅助能力，失败绝不阻断主流程。
    }
  }

  /// 停止当前朗读。
  ///
  /// 即使引擎尚未初始化或已释放，也不外抛异常，静默返回。
  Future<void> stop() async {
    try {
      await _tts?.stop();
    } catch (_) {
      // 静默吞掉，保证调用方无需感知引擎状态。
    }
  }
}
