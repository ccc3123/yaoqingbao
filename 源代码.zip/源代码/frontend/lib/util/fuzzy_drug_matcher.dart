import 'dart:math' as math;

import '../data/medicine.dart';
import 'drug_db.dart';
import 'ingredient.dart';
import 'safe_cast.dart';

/// 一次模糊匹配的结果。
///
/// [score] 为 0~1 的相似度，越高越可信。医疗字段（适应症/用法用量/禁忌/贮藏/成分）
/// 全部来自 [medicine] 里随库下发的说明书官方原文，这里绝不生成任何医疗内容。
class FuzzyMatch {
  final Medicine medicine;
  final double score;

  const FuzzyMatch({required this.medicine, required this.score});
}

/// 编辑距离兜底阶段的候选：记录回查条码、命中的名称（用于算分数分母）与最小距离。
class _NameHit {
  const _NameHit({
    required this.barcode,
    required this.name,
    required this.distance,
  });

  final String barcode;
  final String name;
  final int distance;
}

/// 药品名模糊匹配器（本地纯算法，离线可用）。
///
/// 服务于「语音/口述药品名 -> 容错匹配本地 4.7 万条药品库」的场景：
/// 语音识别经常把剂型、剂量、同音字说错，直接子串查询会漏掉，
/// 因此按「精确 -> 核心名 -> 编辑距离」三级兜底，代价逐级增大、命中即返回。
///
/// 全部查询只读离线，任何异常一律返回空列表，保证断网/无库时不崩。
class FuzzyDrugMatcher {
  FuzzyDrugMatcher._();

  static final FuzzyDrugMatcher instance = FuzzyDrugMatcher._();

  /// 对输入名称做多策略模糊匹配，返回按相似度排序的前 [limit] 条。
  Future<List<FuzzyMatch>> match(String keyword, {int limit = 10}) async {
    try {
      final kw = keyword.trim();
      if (kw.isEmpty) return const <FuzzyMatch>[];
      final cap = limit > 0 ? limit : 10;

      // 策略一：原文子串命中。库里 name/name_norm/alias/pinyin 四字段 LIKE 命中，
      // 属于最高置信，直接给满分。
      final exact = await DrugDb.instance.searchByName(kw, limit: cap);
      if (exact.isNotEmpty) {
        return [
          for (final m in exact) FuzzyMatch(medicine: m, score: 1.0),
        ];
      }

      // 策略二：剥掉剂型/剂量后按核心名再查。语音常带「缓释片」「10mg」这类尾巴，
      // 核心名命中可信度略降一档。
      final core = extractCoreName(kw);
      if (core.isNotEmpty && core != kw) {
        final coreHits =
            await DrugDb.instance.searchByName(core, limit: cap);
        if (coreHits.isNotEmpty) {
          return [
            for (final m in coreHits) FuzzyMatch(medicine: m, score: 0.9),
          ];
        }
      }

      // 策略三：编辑距离兜底。前两级都空手而归时才走这里——这是最贵的一步，
      // 要扫 4.7 万条 name/name_norm，所以靠长度差早停压住开销。
      return _fuzzyByDistance(kw, cap);
    } catch (_) {
      // 降级铁律：任何异常不外抛，返回空列表让调用方当作「未命中」处理。
      return const <FuzzyMatch>[];
    }
  }

  /// 编辑距离兜底：全量 name/name_norm 与输入做 Levenshtein，取距离最小者回查。
  Future<List<FuzzyMatch>> _fuzzyByDistance(String kw, int cap) async {
    final rows = await DrugDb.instance.allNames();
    if (rows.isEmpty) return const <FuzzyMatch>[];

    // 阈值随输入长度放宽：短词打错一字就是一半，长词允许错更多。
    final maxDistance = math.max(2, kw.length ~/ 3);

    final candidates = <_NameHit>[];
    for (final row in rows) {
      final barcode = asStringSafe(row['barcode']);
      final name = asStringSafe(row['name']);
      final nameNorm = asStringSafe(row['name_norm']);

      var best = maxDistance + 1;
      var bestName = '';

      // name 与 name_norm 各算一次距离，取较小者。长度差本身是距离的下界，
      // 差得太多就直接跳过，避免对不可能命中的名字跑完整 DP。
      for (final candidate in <String>[name, nameNorm]) {
        if (candidate.isEmpty) continue;
        if ((kw.length - candidate.length).abs() > maxDistance) continue;
        final d = _levenshtein(kw, candidate);
        if (d < best) {
          best = d;
          bestName = candidate;
        }
      }
      if (best > maxDistance) continue;

      candidates.add(_NameHit(barcode: barcode, name: bestName, distance: best));
    }

    // 距离升序；同距离时短名称更贴近输入，排前。
    candidates.sort((a, b) {
      final byDist = a.distance.compareTo(b.distance);
      if (byDist != 0) return byDist;
      return a.name.length.compareTo(b.name.length);
    });

    final out = <FuzzyMatch>[];
    for (final c in candidates) {
      if (out.length >= cap) break;
      // 只有 barcode 回查成功才算命中；查不到说明该行数据不完整，跳过。
      final medicine = await DrugDb.instance.lookupByBarcode(c.barcode);
      if (medicine == null) continue;
      final denom = math.max(kw.length, c.name.length);
      final score = denom == 0 ? 0.0 : (1 - c.distance / denom).clamp(0.0, 1.0);
      out.add(FuzzyMatch(medicine: medicine, score: score.toDouble()));
    }
    return out;
  }

  /// 计算两个字符串的编辑距离（Levenshtein）。
  ///
  /// 用两行滚动数组把空间压到 O(min(len(a), len(b)))。药品名基本是 CJK 基本平面字符，
  /// 每个字符占单个 UTF-16 码元，因此按 codeUnit 逐位比较即可，无需引入 characters 包。
  static int _levenshtein(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;

    // 让 b 恒为较短的一方，列数更少、滚动数组更小。
    if (a.length < b.length) {
      final t = a;
      a = b;
      b = t;
    }

    final n = b.length;
    var prev = List<int>.generate(n + 1, (i) => i);
    var curr = List<int>.filled(n + 1, 0);

    for (var i = 1; i <= a.length; i++) {
      curr[0] = i;
      for (var j = 1; j <= n; j++) {
        final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
        curr[j] = math.min(
          math.min(curr[j - 1] + 1, prev[j] + 1),
          prev[j - 1] + cost,
        );
      }
      final tmp = prev;
      prev = curr;
      curr = tmp;
    }
    return prev[n];
  }
}
