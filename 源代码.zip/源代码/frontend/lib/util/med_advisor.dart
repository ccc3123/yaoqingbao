import '../data/drug_item.dart';
import '../data/med_record.dart';
import '../data/user_profile.dart';
import 'ai_client.dart';
import 'drug_db.dart';
import 'food_drug_rules.dart';

/// AI 服药助理 —— 联网用药建议引擎。
///
/// 设计原则（本次迭代核心）：
/// 1. **联网 AI 为主引擎**：由可配置大模型生成连续服用/用量/间隔/食物禁忌/身体评估建议，
///    鼓励 AI 自我发挥、主动创新，话术轻松不教条；
/// 2. **RAG 接地**：把官方说明书原文 + 健康档案 + 药箱清单 + 服药记录作为上下文，
///    让建议落到真实药品上、减少幻觉（不是限制它，而是给它准确素材）；
/// 3. **强制免责**：每条 AI 建议尾部固定附「仅供参考，请遵医嘱/药师」；
/// 4. **本地兜底**：断网 / 无 Key 时用食物禁忌词典 + 重复成分 + 到期规则给基础提示。
class MedAdvisor {
  MedAdvisor._();

  static final MedAdvisor instance = MedAdvisor._();

  final AiClient _ai = AiClient.instance;

  static const String _disclaimer = '\n\n（本建议由 AI 生成，仅供参考，请遵医嘱或咨询药师）';

  /// 药匣页小形象的主动气泡提示。
  ///
  /// 联网时由 AI 结合药箱内容发挥创意生成；断网时回落本地规则结论。
  Future<String> proactiveTip({
    required UserProfile profile,
    required List<DrugItem> items,
  }) async {
    final active = items.where((e) => e.recycled == 0).toList();
    if (active.isEmpty) return '药箱还空着呢，添加药品后我就能帮你把关啦～';

    final local = _localTips(active);
    try {
      final aiTip = await _ai.chat([
        const ChatMessage(
          role: 'system',
          content: '你是一个住在家庭药箱里的小助手「药宝」。看到用户药箱里的药品后，'
              '用一句轻松、友好、口语化的话主动提醒一个最要紧的用药注意点，'
              '尤其是食物禁忌（酒、西柚、水果、茶、咖啡等）。可以发挥创意，'
              '语气俏皮一点，不要教条、不要长篇大论。只输出这一句话（30 字内）。',
        ),
        ChatMessage(
          role: 'user',
          content: '我的药箱：${_cabinetBrief(active)}\n'
              '${profile.isCompleted ? '我的情况：${profile.toDescription()}' : ''}\n'
              '本地已知线索：${local.isEmpty ? '无' : local.join('；')}\n'
              '请给一句主动提醒（可参考本地线索，也可发挥你自己的知识）。',
        ),
      ], temperature: 0.9, maxTokens: 120);
      if (aiTip != null && aiTip.trim().isNotEmpty) {
        return aiTip.trim();
      }
    } catch (_) {
      // 联网失败，走本地兜底
    }
    return local.isNotEmpty ? local.first : '要记得按时检查药箱有效期哦～';
  }

  /// 回答用户用药问题（多轮对话用）。
  ///
  /// [history] 为之前的对话（不含本轮），用于保持上下文。
  Future<String> answer({
    required String question,
    required UserProfile profile,
    required List<DrugItem> items,
    required List<MedRecord> records,
    List<ChatMessage> history = const [],
  }) async {
    final q = question.trim();
    if (q.isEmpty) return '请告诉我你想了解什么用药问题～';

    final active = items.where((e) => e.recycled == 0).toList();

    try {
      // 1. RAG 检索：把药箱里命中的药品官方说明书原文作上下文
      final instructions = await _retrieveInstructions(active);

      // 2. 组装上下文
      final system = _buildSystemPrompt(profile);
      final userContent = _buildUserContent(
        question: q,
        items: active,
        records: records,
        instructions: instructions,
      );

      // 3. 联网生成
      final messages = <ChatMessage>[ChatMessage(role: 'system', content: system)];
      messages.addAll(history);
      messages.add(ChatMessage(role: 'user', content: userContent));

      final reply = await _ai.chat(messages, temperature: 0.6, maxTokens: 900);
      if (reply != null && reply.trim().isNotEmpty) {
        return AiClient.stripMarkdown(reply) + _disclaimer;
      }
    } catch (_) {
      // 联网失败，走本地兜底
    }

    // 4. 本地兜底
    return localAnswer(q, active) + '\n\n（当前离线，以上为本地基础提示，联网后可获得更详细建议）';
  }

  /// 本地确定性兜底（断网时）。
  ///
  /// 只做「命中词典/规则 → 提示」的确定性映射，不做任何自由推断。
  String localAnswer(String question, List<DrugItem> items) {
    final lower = question.toLowerCase();
    final isFood = _containsAny(lower, ['吃', '喝', '酒', '水果', '西柚', '茶', '咖啡', '食物', '忌']);
    final isDose = _containsAny(lower, ['剂量', '用量', '吃多少', '多少']);
    final isInterval = _containsAny(lower, ['间隔', '多久', '多久一次', '几个小时']);
    final isContinuous = _containsAny(lower, ['连续', '一直吃', '长期', '能不能一直']);

    final warnings = <String>[];
    for (final item in items) {
      final hits = matchFoodDrugWarnings('${item.medicineName} ${item.component}');
      if (isFood) {
        warnings.addAll(hits);
      }
    }

    final buffer = StringBuffer();
    if (warnings.isNotEmpty) {
      buffer.writeln('根据药箱里的药品，本地提示如下：');
      for (final w in _dedupe(warnings).take(5)) {
        buffer.writeln('• $w');
      }
    } else if (items.isEmpty) {
      buffer.writeln('药箱暂无药品，请先添加药品再咨询。');
    } else {
      buffer.writeln('本地暂时无法准确回答这个问题，联网后可获得 AI 用药建议。');
    }

    // 剂量/间隔/连续服用这类问题，本地只给通用安全提示，不自由推断
    if (isDose || isInterval || isContinuous) {
      buffer.writeln('\n• 剂量与间隔请以药品说明书「用法用量」为准，请勿自行加大剂量或延长/缩短疗程。');
    }
    return buffer.toString().trim();
  }

  // ------------------------------------------------------------------ 私有

  String _buildSystemPrompt(UserProfile profile) {
    return '你是「药清宝」App 里的 AI 服药助理「药宝」，一位贴心、专业的家庭用药安全助手。'
        '你可以基于官方药品说明书、用户健康档案、药箱清单与服药记录，给出：'
        '①哪些药品不宜连续服用 ②哪些用量不宜过大 ③两次服药应间隔多久 ④哪些食物/酒/水果不宜与药同服 ⑤结合身体状况的评估。'
        '要求：'
        '1. 优先引用【官方说明书】里的信息，说明书没有的再结合你的医学常识，但要谨慎、不编造；'
        '2. 语气友好、口语化、有温度，可以适当发挥创意，但绝不给出「停药/换药」等必须由医生决定的结论；'
        '3. 涉及具体剂量时提醒以说明书为准；'
        '4. 回答简洁，分点列出，每条不超过 60 字。\n'
        '${profile.isCompleted ? '【用户健康档案】${profile.toDescription()}\n' : ''}'
        '【重要】你的建议仅供参考，不构成医疗诊断。';
  }

  String _buildUserContent({
    required String question,
    required List<DrugItem> items,
    required List<MedRecord> records,
    required String instructions,
  }) {
    final buf = StringBuffer();
    buf.writeln('【用户问题】$question');
    buf.writeln();
    buf.writeln('【我的药箱】');
    buf.writeln(_cabinetBrief(items));
    buf.writeln();
    if (records.isNotEmpty) {
      buf.writeln('【近期服药记录】');
      for (final r in records.take(10)) {
        buf.writeln('- ${r.takenAt} 服用 ${r.medicineName} ${r.dose}${r.unit}');
      }
      buf.writeln();
    }
    if (instructions.isNotEmpty) {
      buf.writeln('【官方药品说明书摘录】');
      buf.writeln(instructions);
    }
    return buf.toString().trim();
  }

  /// 药箱清单摘要（药名 + 主要成分 + 到期状态 + 余量）
  String _cabinetBrief(List<DrugItem> items) {
    final buf = StringBuffer();
    for (final item in items) {
      final parts = <String>[
        item.medicineName,
        if (item.component.isNotEmpty) '（成分：${item.component}）',
        if (item.countDown <= 0) '（已过期）',
        if (item.countDown > 0 && item.countDown <= 30) '（${item.countDown} 天后到期）',
        if (item.remaining > 0 && item.unit.isNotEmpty) '剩余 ${item.remaining}${item.unit}',
      ];
      buf.writeln('- ${parts.join(' ')}');
    }
    return buf.toString().trim();
  }

  /// 检索药箱药品的官方说明书，拼接成上下文
  Future<String> _retrieveInstructions(List<DrugItem> items) async {
    final seen = <String>{};
    final buffer = StringBuffer();
    for (final item in items) {
      final name = item.medicineName.trim();
      if (name.isEmpty || !seen.add(name)) continue;
      try {
        final hits = await DrugDb.instance.searchByName(name, limit: 1);
        if (hits.isNotEmpty) {
          final m = hits.first;
          final lines = <String>[
            '【药名】${m.drugName}',
            if (m.usage.isNotEmpty) '【用法用量】${m.usage}',
            if (m.jj.isNotEmpty) '【禁忌】${m.jj}',
            if (m.zysx.isNotEmpty) '【注意事项】${m.zysx}',
            if (m.component.isNotEmpty) '【成分】${m.component}',
          ];
          buffer.writeln(lines.join('\n'));
          buffer.writeln();
        }
      } catch (_) {
        // 检索失败静默跳过，不阻塞主流程
      }
    }
    return buffer.toString().trim();
  }

  List<String> _localTips(List<DrugItem> items) {
    final tips = <String>[];
    // 1. 食物禁忌
    final foodWarnings = <String>[];
    for (final item in items) {
      foodWarnings.addAll(
          matchFoodDrugWarnings('${item.medicineName} ${item.component}'));
    }
    if (foodWarnings.isNotEmpty) {
      tips.add('⚠️ 注意饮食：${_dedupe(foodWarnings).first}');
    }
    // 2. 临期提醒
    final near = items.where((e) => e.countDown > 0 && e.countDown <= 10).toList();
    if (near.isNotEmpty) {
      tips.add('⏰ ${near.map((e) => e.medicineName).join('、')} 快到期了，记得优先用完～');
    }
    final expired = items.where((e) => e.countDown <= 0).toList();
    if (expired.isNotEmpty) {
      tips.add('🚫 ${expired.map((e) => e.medicineName).join('、')} 已过期，请勿服用并及时回收');
    }
    // 3. 余量告急
    final lowStock = items.where((e) => e.remaining > 0 && e.remaining <= 2 && e.unit.isNotEmpty).toList();
    if (lowStock.isNotEmpty) {
      tips.add('💊 ${lowStock.map((e) => e.medicineName).join('、')} 余量不多，记得补药');
    }
    return tips;
  }

  List<String> _dedupe(List<String> list) {
    final seen = <String>{};
    final out = <String>[];
    for (final s in list) {
      if (s.isNotEmpty && seen.add(s)) out.add(s);
    }
    return out;
  }

  bool _containsAny(String text, List<String> keywords) =>
      keywords.any(text.contains);
}
