import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../data/med_plan.dart';
import 'device_utils.dart';
import 'http_utils.dart';

/// 服药计划服务（本地 + 家庭共享同步）
class MedPlanService {
  MedPlanService._();

  static final MedPlanService instance = MedPlanService._();

  static const String _key = 'yaoqingbao_med_plans';

  /// 拉取计划：本地优先，服务端可用时合并家庭共享计划。
  Future<List<MedPlan>> list() async {
    final local = await _loadLocal();
    try {
      final familyCode = await DeviceUtils.familyCode();
      final devId = await DeviceUtils.deviceId();
      final resp = await HttpUtils().get('/medplan/list', params: {
        if (familyCode.isNotEmpty) 'familyCode': familyCode else 'deviceId': devId,
      });
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is List) {
        final remote = (body['data'] as List)
            .whereType<Map>()
            .map((e) => MedPlan.fromJson(Map<String, dynamic>.from(e)))
            .toList();
        if (remote.isNotEmpty) {
          await _saveLocal(remote);
          return remote;
        }
      }
    } catch (_) {
      // 服务端不可用，沿用本地
    }
    return local;
  }

  /// 保存（新建或更新），本地 + 服务端尽力同步
  Future<MedPlan> save(MedPlan plan) async {
    final local = await _loadLocal();
    final idx = local.indexWhere((e) => e.id == plan.id && plan.id > 0);
    if (idx >= 0) {
      local[idx] = plan;
    } else {
      local.add(plan);
    }
    await _saveLocal(local);

    try {
      final familyCode = await DeviceUtils.familyCode();
      final devId = await DeviceUtils.deviceId();
      await HttpUtils().post('/medplan/save', data: {
        if (plan.id > 0) 'id': plan.id,
        'familyCode': familyCode,
        'deviceId': devId,
        'medicineName': plan.medicineName,
        'dosage': plan.dosage,
        'times': plan.times.join(','),
        'startDate': plan.startDate,
        'endDate': plan.endDate,
        'enabled': plan.enabled ? 1 : 0,
      });
    } catch (_) {
      // 静默：下次进入时重新拉取补传
    }
    return plan;
  }

  /// 删除计划
  Future<void> delete(MedPlan plan) async {
    final local = await _loadLocal();
    local.removeWhere((e) => e.id == plan.id);
    await _saveLocal(local);
    try {
      if (plan.id > 0) {
        await HttpUtils().delete('/medplan/delete', params: {'id': plan.id});
      }
    } catch (_) {}
  }

  Future<List<MedPlan>> _loadLocal() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_key);
    if (s == null || s.isEmpty) return <MedPlan>[];
    try {
      final list = jsonDecode(s);
      if (list is List) {
        return list
            .whereType<Map>()
            .map((e) => MedPlan.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
      return <MedPlan>[];
    } catch (_) {
      return <MedPlan>[];
    }
  }

  Future<void> _saveLocal(List<MedPlan> plans) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
        _key, jsonEncode(plans.map((e) => e.toJson()).toList()));
  }
}
