import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// 启动期与运行期的全局异常兜底
///
/// 目标：任何未被捕获的异常 / Flutter 框架错误都不再导致"静默闪退"，
/// 而是落到日志（Logcat: flutter）与用户可见的友好错误页。
class CrashGuard {
  CrashGuard._();

  static bool _installed = false;

  static const String _tag = '[药清宝·异常]';

  /// 安装全局错误处理，幂等
  static void install() {
    if (_installed) return;
    _installed = true;

    // 1. Flutter 框架层异常（构建/布局/绘制期抛错）
    FlutterError.onError = (FlutterErrorDetails details) {
      FlutterError.presentError(details);
      _log(details.exceptionAsString(), details.stack);
    };

    // 2. Dart 异步与 PlatformDispatcher 层未捕获异常
    PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
      _log(error.toString(), stack);
      return true; // 已处理，不再向上抛
    };

    // 3. 替换 release 模式下灰屏 / debug 模式下红字报错为友好提示
    ErrorWidget.builder = (FlutterErrorDetails details) => _ErrorCard(details: details);
  }

  /// runZonedGuarded 的回调
  static void reportZoneError(Object error, StackTrace stack) => _log(error.toString(), stack);

  static void _log(String message, StackTrace? stack) {
    if (kReleaseMode) {
      // release 下 debugPrint 仍会输出到 Logcat（tag: flutter），
      // 后续接入 Crashlytics / Sentry 时在此处扩展即可。
      debugPrint('$_tag $message');
    } else {
      debugPrint('$_tag $message');
    }
    if (stack != null) debugPrint('$_tag stack:\n$stack');
  }
}

/// 单个 widget 构建失败时的占位卡片，避免整块红屏或灰线程panic式空板
class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.details});

  final FlutterErrorDetails details;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        margin: const EdgeInsets.all(8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppColors.dangerTint,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.dangerTint),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('这块内容暂时没能显示出来',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.danger)),
            const SizedBox(height: 6),
            Text(
              details.exceptionAsString().split('\n').first,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, color: AppColors.muted),
            ),
          ],
        ),
      ),
    );
  }
}
