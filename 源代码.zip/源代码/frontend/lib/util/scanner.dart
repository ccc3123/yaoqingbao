import 'package:barcode_scan2/barcode_scan2.dart';

class Scanner {
  static Future<String> scanBarcode() async {
    try {
      final result = await BarcodeScanner.scan(
        options: ScanOptions(strings: {
          'cancel': '取消',
          'flash_on': '打开闪光灯',
          'flash_off': '关闭闪光灯',
        }),
      );
      return result.rawContent;
    } catch (e) {
      return '';
    }
  }
}
