import 'dart:typed_data';

import 'package:image_picker/image_picker.dart';

import '../data/medicine.dart';
import 'drug_db.dart';
import 'zhipu_service.dart';

/// 拍照识药的结果。
class VisionResult {
  const VisionResult({
    required this.medicine,
    required this.fromOfficialDb,
    this.confidence = 0,
    this.rawText = '',
  });

  final Medicine medicine;

  /// 是否用 AI 读到的药名**回查到了离线条码库**。
  /// true 表示说明书类字段（适应症/禁忌/用法用量/贮藏）来自官方原文；
  /// false 表示这些字段为空 —— UI 必须明确提示"说明书内容未获取"。
  final bool fromOfficialDb;

  final double confidence;
  final String rawText;
}

/// 拍照识药失败的原因，便于 UI 给出准确提示而不是笼统的"识别失败"。
enum VisionFailure {
  /// 用户主动取消
  cancelled,

  /// 没有可用的相机/相册权限
  permissionDenied,

  /// 视觉模型不可用（无 Key / 超时 / 返回非法）
  aiUnavailable,

  /// 模型判断图片里不是药品
  notMedicine,

  /// 图片里没读出药名
  emptyName,
}

class VisionException implements Exception {
  const VisionException(this.reason, {this.detail});

  final VisionFailure reason;
  final String? detail;

  String get message {
    switch (reason) {
      case VisionFailure.cancelled:
        return '已取消';
      case VisionFailure.permissionDenied:
        return '需要相册或相机权限才能识别药盒';
      case VisionFailure.aiUnavailable:
        return 'AI 识别服务暂时不可用，可改用扫码或手动搜索';
      case VisionFailure.notMedicine:
        return '这张图里没有识别到药品包装，请对准药盒正面重拍';
      case VisionFailure.emptyName:
        return '没能看清药品名称，请在光线充足处对准包装上的药名重拍';
    }
  }
}

/// 拍照识药。
///
/// 链路：**选图 → 视觉模型 OCR → 用药名回查离线条码库补全官方说明书**。
///
/// 关键设计：AI 只负责"看清包装上写了什么"，**不负责**告诉用户这药怎么用。
/// 拿到药名后立刻回查本地库（`DrugDb`），把适应症/禁忌/用法用量等医疗字段
/// 换成官方说明书原文；查不到就留空并如实告知，绝不让模型临场编一段。
class VisionService {
  VisionService({ImagePicker? picker, ZhipuService? ai, DrugDb? db})
      : _picker = picker ?? ImagePicker(),
        _ai = ai ?? ZhipuService(),
        _db = db ?? DrugDb.instance;

  final ImagePicker _picker;
  final ZhipuService _ai;
  final DrugDb _db;

  /// 选一张图并识别。
  ///
  /// [useCamera] true 走相机直拍，false 走相册（演示与无相机设备兜底）。
  /// 压缩参数按识别需要取舍：视觉模型对分辨率不敏感，但 base64 后体积会放大
  /// 约 1/3，超过 1MB 时请求明显变慢，因此统一压到 1280px / 质量 85。
  Future<VisionResult> recognize({bool useCamera = true}) async {
    final XFile? file = await _picker.pickImage(
      source: useCamera ? ImageSource.camera : ImageSource.gallery,
      maxWidth: 1280,
      maxHeight: 1280,
      imageQuality: 85,
    );
    // 用户取消时 pickImage 返回 null，这是正常路径，不算错误
    if (file == null) {
      throw const VisionException(VisionFailure.cancelled);
    }

    Uint8List bytes;
    try {
      bytes = await file.readAsBytes();
    } catch (_) {
      throw const VisionException(VisionFailure.permissionDenied);
    }
    if (bytes.isEmpty) {
      throw const VisionException(VisionFailure.permissionDenied);
    }

    return recognizeBytes(bytes);
  }

  /// 直接识别一段图片字节（便于测试与后续接入剪贴板/相册多选）。
  Future<VisionResult> recognizeBytes(Uint8List bytes) async {
    final Map<String, dynamic>? data = await _ai.recognizeByImage(bytes);

    if (data == null || data.isEmpty) {
      throw const VisionException(VisionFailure.aiUnavailable);
    }
    if (data['isMedicine'] == false) {
      throw const VisionException(VisionFailure.notMedicine);
    }

    final String name = (data['drugName'] ?? '').toString().trim();
    if (name.isEmpty) {
      throw const VisionException(VisionFailure.emptyName);
    }

    final double confidence = _asDouble(data['confidence']);
    final String rawText = (data['rawText'] ?? '').toString().trim();

    // 用药名回查离线条码库，把医疗字段换成官方说明书原文
    Medicine? official;
    try {
      final hits = await _db.searchByName(name, limit: 1);
      if (hits.isNotEmpty) official = hits.first;
    } catch (_) {
      // 离线库不可用不影响主流程，按"未补全"处理
    }

    final Medicine medicine = Medicine(
      id: official?.id ?? '',
      // 名称取 AI 读到的（用户看到的包装名），其余优先官方库
      drugName: name,
      brand: (data['brand'] ?? '').toString().trim().isNotEmpty
          ? (data['brand'] ?? '').toString().trim()
          : (official?.brand ?? ''),
      ggxh: _pick(data['ggxh'], official?.ggxh),
      manu: _pick(data['manu'], official?.manu),
      pzwh: _pick(data['pzwh'], official?.pzwh),
      type: _pick(data['type'], official?.type),
      // ---- 以下全部只取官方说明书；查不到就留空，绝不由 AI 生成 ----
      syz: official?.syz ?? '',
      usage: official?.usage ?? '',
      jj: official?.jj ?? '',
      zc: official?.zc ?? '',
      component: official?.component ?? '',
      barcode: official?.barcode ?? '',
      source: official != null ? 'vision+codedb' : 'vision',
    );

    return VisionResult(
      medicine: medicine,
      fromOfficialDb: official != null,
      confidence: confidence,
      rawText: rawText,
    );
  }

  /// 优先取 AI 读到的值，为空时才回落到官方库
  static String _pick(dynamic preferred, String? fallback) {
    final String v = (preferred ?? '').toString().trim();
    return v.isNotEmpty ? v : (fallback ?? '');
  }

  static double _asDouble(dynamic v) {
    if (v is num) return v.toDouble().clamp(0.0, 1.0);
    final double? parsed = double.tryParse((v ?? '').toString());
    return (parsed ?? 0).clamp(0.0, 1.0);
  }
}
