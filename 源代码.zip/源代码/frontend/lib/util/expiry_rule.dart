/// 有效期分级。
///
/// 药匣里每条记录已有 `countDown`（剩余天数），这里只负责把它翻译成
/// 渲染层的等级与文案，**不改动 `DrugItem` 的数据模型**。
enum ExpiryLevel {
  /// 安全（>90 天）
  safe,

  /// 关注（≤90 天）
  notice,

  /// 临近（≤30 天）
  warn,

  /// 紧急（≤7 天）
  danger,

  /// 已过期（≤0 天）
  expired,
}

/// 分级结果，含给用户的可读说明。
class ExpiryVerdict {
  const ExpiryVerdict({
    required this.level,
    required this.label,
    required this.advice,
  });

  final ExpiryLevel level;
  final String label;
  final String advice;

  bool get isExpired => level == ExpiryLevel.expired;

  /// 是否需要用户立刻处理（红色警报级别）
  bool get isUrgent =>
      level == ExpiryLevel.expired || level == ExpiryLevel.danger;
}

/// 过期判定规则。
///
/// 全部为**纯本地规则**，不依赖网络与 AI —— 答辩断网也必须能正常提醒。
/// 之所以不给 AI 做：有效期算错会直接误导是否继续服药，属于医疗风险，
/// 而它本质是确定性计算，完全没有交给模型推理的必要。
class ExpiryRule {
  ExpiryRule._();

  /// 急救与生物制品：这类药品失效风险高，阈值整体前移。
  static const List<String> _rescueKeywords = [
    '硝酸甘油',
    '胰岛素',
    '肾上腺素',
    '速效救心',
    '沙丁胺醇',
    '氨茶碱',
    '地高辛',
    '华法林',
    '肝素',
  ];

  /// 开封后有效期大幅缩短的剂型（一般按 28 天折算）
  static const List<String> _openSensitiveKeywords = [
    '糖浆',
    '滴眼液',
    '眼药水',
    '软膏',
    '乳膏',
    '口服液',
    '混悬液',
    '滴耳液',
    '滴鼻液',
  ];

  /// 开封后的默认可用天数
  static const int daysAfterOpen = 28;

  /// 主判定入口。
  ///
  /// [remainDays] 距过期还剩多少天（可为负，表示已过期）
  /// [drugName] / [form] 用于类别差异化
  /// [openedDays] 若记录了开封日期，传入已开的天数；未记录传 null
  static ExpiryVerdict judge({
    required int remainDays,
    String? drugName,
    String? form,
    int? openedDays,
  }) {
    // 1. 已开封的敏感剂型：剩余有效期不得超过开封后可用窗口
    if (openedDays != null && _isOpenSensitive(drugName, form)) {
      final left = daysAfterOpen - openedDays;
      if (left <= 0) {
        return const ExpiryVerdict(
          level: ExpiryLevel.danger,
          label: '已开封超期',
          advice: '开封已超过 $daysAfterOpen 天，建议停止使用并回收',
        );
      }
      if (left <= 7) {
        return ExpiryVerdict(
          level: ExpiryLevel.danger,
          label: '开封仅剩 $left 天',
          advice: '开封后建议在 $daysAfterOpen 天内用完，请勿继续存放',
        );
      }
    }

    // 2. 已过期
    if (remainDays <= 0) {
      return ExpiryVerdict(
        level: ExpiryLevel.expired,
        label: '已过期 ${-remainDays} 天',
        advice: '请尽快投入回收点，切勿服用',
      );
    }

    // 3. 急救与生物制品：阈值前移，30 天就要换
    if (_isRescue(drugName, form)) {
      if (remainDays <= 30) {
        return ExpiryVerdict(
          level: ExpiryLevel.warn,
          label: '急救药仅剩 $remainDays 天',
          advice: '急救与生物制品建议提前更换，避免失效风险',
        );
      }
      if (remainDays <= 60) {
        return ExpiryVerdict(
          level: ExpiryLevel.notice,
          label: '剩 $remainDays 天',
          advice: '建议提前备好替换药品',
        );
      }
      return ExpiryVerdict(
        level: ExpiryLevel.safe,
        label: '剩 $remainDays 天',
        advice: '按规定条件存放',
      );
    }

    // 4. 常规药品四级
    if (remainDays <= 7) {
      return ExpiryVerdict(
        level: ExpiryLevel.danger,
        label: '仅剩 $remainDays 天',
        advice: '即将过期，如已不再需要请优先回收',
      );
    }
    if (remainDays <= 30) {
      return ExpiryVerdict(
        level: ExpiryLevel.warn,
        label: '剩 $remainDays 天',
        advice: '临近有效期，请注意优先使用',
      );
    }
    if (remainDays <= 90) {
      return ExpiryVerdict(
        level: ExpiryLevel.notice,
        label: '剩 $remainDays 天',
        advice: '留意有效期，避免囤积过期',
      );
    }
    return ExpiryVerdict(
      level: ExpiryLevel.safe,
      label: '剩 $remainDays 天',
      advice: '按规定条件存放',
    );
  }

  /// 综合药品名与剂型判断是否为开封敏感剂型
  static bool _isOpenSensitive(String? drugName, String? form) {
    final text = '${drugName ?? ''} ${form ?? ''}';
    if (text.trim().isEmpty) return false;
    return _openSensitiveKeywords.any(text.contains);
  }

  /// 是否为急救 / 生物制品
  static bool _isRescue(String? drugName, String? form) {
    final text = '${drugName ?? ''} ${form ?? ''}';
    if (text.trim().isEmpty) return false;
    return _rescueKeywords.any(text.contains);
  }
}
