import 'package:shared_preferences/shared_preferences.dart';

import 'device_utils.dart';
import 'http_utils.dart';

/// 账号服务（手机号验证码登录 + 家庭码绑定）
///
/// 混合双入口：子女走手机号账号，父母老人走家庭码免注册。
/// 令牌仅存本机，健康档案仍不上传。
class AuthService {
  AuthService._();

  static final AuthService instance = AuthService._();

  static const String _tokenKey = 'yaoqingbao_token';
  static const String _userIdKey = 'yaoqingbao_user_id';
  static const String _phoneKey = 'yaoqingbao_phone';
  static const String _nicknameKey = 'yaoqingbao_nickname';

  /// 发送验证码；返回 demoCode（演示模式），null 表示失败
  Future<String?> sendCode(String phone) async {
    _lastError = null;
    try {
      final resp = await HttpUtils().post(
        '/auth/sendCode',
        data: {'phone': phone},
      );
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is Map) {
        return (body['data']['demoCode'] ?? '').toString();
      }
      if (body is Map && body['msg'] != null)
        _lastError = body['msg'].toString();
    } catch (e) {
      _lastError = HttpUtils.describeError(e);
    }
    return null;
  }

  /// 验证码登录；成功返回 true 并保存令牌
  Future<bool> login(String phone, String code) async {
    _lastError = null;
    try {
      final resp = await HttpUtils().post(
        '/auth/login',
        data: {'phone': phone, 'code': code},
      );
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is Map) {
        final data = body['data'] as Map;
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString(_tokenKey, (data['token'] ?? '').toString());
        await prefs.setInt(
          _userIdKey,
          int.tryParse((data['userId'] ?? '0').toString()) ?? 0,
        );
        await prefs.setString(_phoneKey, (data['phone'] ?? '').toString());
        await prefs.setString(
          _nicknameKey,
          (data['nickname'] ?? '').toString(),
        );
        // 账号登录后同步昵称到成员名，供服药记录展示
        await DeviceUtils.saveMember(
          await DeviceUtils.memberId(),
          (data['nickname'] ?? '').toString(),
        );
        return true;
      }
      if (body is Map && body['msg'] != null) {
        _lastError = body['msg'].toString();
      }
    } catch (e) {
      _lastError = HttpUtils.describeError(e);
    }
    return false;
  }

  String? _lastError;
  String get lastError => _lastError ?? '登录失败，请稍后重试';

  Future<String?> token() async {
    final prefs = await SharedPreferences.getInstance();
    final t = prefs.getString(_tokenKey);
    return (t == null || t.isEmpty) ? null : t;
  }

  Future<int> userId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getInt(_userIdKey) ?? 0;
  }

  Future<String> phone() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_phoneKey) ?? '';
  }

  Future<bool> isLoggedIn() async {
    return (await token()) != null;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userIdKey);
    await prefs.remove(_phoneKey);
    await prefs.remove(_nicknameKey);
  }

  // ============ 家庭（混合双入口） ============

  /// 创建家庭，返回家庭码；null 表示失败
  Future<String?> createFamily({required String familyName}) async {
    try {
      final memberId = await DeviceUtils.memberId();
      final name = await DeviceUtils.memberName();
      final uid = await userId();
      final resp = await HttpUtils().post(
        '/family/create',
        data: {
          'memberId': memberId,
          'memberName': name.isEmpty ? '我' : name,
          'familyName': familyName,
          if (uid > 0) 'userId': uid,
        },
      );
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is Map) {
        final code = (body['data']['familyCode'] ?? '').toString();
        await DeviceUtils.saveFamilyCode(code);
        return code;
      }
    } catch (_) {}
    return null;
  }

  /// 凭家庭码加入家庭；成功返回家庭码
  Future<String?> joinFamily({required String familyCode}) async {
    try {
      final memberId = await DeviceUtils.memberId();
      final name = await DeviceUtils.memberName();
      final uid = await userId();
      final resp = await HttpUtils().post(
        '/family/join',
        data: {
          'familyCode': familyCode,
          'memberId': memberId,
          'memberName': name.isEmpty ? '家人' : name,
          if (uid > 0) 'userId': uid,
        },
      );
      final body = resp.data;
      if (body is Map && body['code'] == 200) {
        await DeviceUtils.saveFamilyCode(familyCode);
        return familyCode;
      }
    } catch (_) {}
    return null;
  }

  /// 查询当前成员/账号所属家庭（返回家庭码，空串=未加入）
  Future<String> myFamily() async {
    final cached = await DeviceUtils.familyCode();
    if (cached.isNotEmpty) return cached;
    try {
      final memberId = await DeviceUtils.memberId();
      final uid = await userId();
      final resp = await HttpUtils().get(
        '/family/my',
        params: {if (uid > 0) 'userId': uid else 'memberId': memberId},
      );
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is Map) {
        final code = (body['data']['familyCode'] ?? '').toString();
        if (code.isNotEmpty) await DeviceUtils.saveFamilyCode(code);
        return code;
      }
    } catch (_) {}
    return cached;
  }
}
