import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// AI 配置（OpenAI 兼容协议三要素）。
///
/// 只要填 baseUrl + apiKey + model，即可自动连接任意 OpenAI 兼容模型：
/// 智谱 GLM / DeepSeek / OpenAI / 本地 Ollama 等（参考猎诈智脑的
/// `OpenAI(api_key=..., base_url=...)` 模式）。
class AiConfig {
  final String baseUrl;
  final String apiKey;
  final String model;
  final bool enabled;

  const AiConfig({
    this.baseUrl = '',
    this.apiKey = '',
    this.model = '',
    this.enabled = true,
  });

  bool get isValid => baseUrl.isNotEmpty && apiKey.isNotEmpty && model.isNotEmpty;

  AiConfig copyWith({
    String? baseUrl,
    String? apiKey,
    String? model,
    bool? enabled,
  }) =>
      AiConfig(
        baseUrl: baseUrl ?? this.baseUrl,
        apiKey: apiKey ?? this.apiKey,
        model: model ?? this.model,
        enabled: enabled ?? this.enabled,
      );
}

/// 一条对话消息（OpenAI chat 消息格式）
class ChatMessage {
  final String role; // system / user / assistant
  final String content;

  const ChatMessage({required this.role, required this.content});

  Map<String, dynamic> toJson() => {'role': role, 'content': content};
}

/// 可配置 AI 客户端（OpenAI 兼容）。
///
/// 职责单一：把消息列表发给配置的模型，返回模型回复文本。
/// 与 [ZhipuService] 的区别：ZhipuService 用于「药品识别/报告/问药」且硬编码
/// 「禁止诊疗」红线；本客户端用于「AI 服药助理」——system prompt 由调用方注入，
/// 允许生成用药建议（调用方负责加免责声明），两者互不干扰。
class AiClient {
  AiClient._();

  static final AiClient instance = AiClient._();

  static const String _keyBase = 'yaoqingbao_ai_base_url';
  static const String _keyApi = 'yaoqingbao_ai_api_key';
  static const String _keyModel = 'yaoqingbao_ai_model';
  static const String _keyEnabled = 'yaoqingbao_ai_enabled';

  /// 默认 = 智谱 GLM（与现有识别链路同源，开箱即用）。
  /// ⚠️ 生产提交前应把默认 Key 置空，改用 --dart-define 注入并轮换。
  static const String _defaultBase = 'https://open.bigmodel.cn/api/paas/v4';
  static const String _defaultKey =
      String.fromEnvironment('ZHIPU_KEY', defaultValue: 'cb6a756da78c4e31bf8331a044bc2586.ybW466UPdpMq6A3q');
  static const String _defaultModel = 'glm-4-flash';

  Dio? _dio;

  Dio _client() {
    return _dio ??= Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 40),
      headers: {'Content-Type': 'application/json'},
    ));
  }

  /// 读取本地配置（未配置时回退到默认 GLM）
  Future<AiConfig> loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    return AiConfig(
      baseUrl: prefs.getString(_keyBase) ?? _defaultBase,
      apiKey: prefs.getString(_keyApi) ?? _defaultKey,
      model: prefs.getString(_keyModel) ?? _defaultModel,
      enabled: prefs.getBool(_keyEnabled) ?? true,
    );
  }

  /// 保存配置
  Future<void> saveConfig(AiConfig config) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyBase, config.baseUrl);
    await prefs.setString(_keyApi, config.apiKey);
    await prefs.setString(_keyModel, config.model);
    await prefs.setBool(_keyEnabled, config.enabled);
    _dio = null; // 配置变了，重建连接
  }

  /// 发送多轮对话，返回模型回复文本；失败（无配置/超时/非法）返回 null。
  Future<String?> chat(
    List<ChatMessage> messages, {
    double temperature = 0.5,
    int maxTokens = 1200,
  }) async {
    final config = await loadConfig();
    if (!config.enabled || !config.isValid) return null;
    try {
      final resp = await _client().post(
        '${config.baseUrl}/chat/completions',
        data: {
          'model': config.model,
          'messages': messages.map((e) => e.toJson()).toList(),
          'temperature': temperature,
          'max_tokens': maxTokens,
        },
        options: Options(headers: {'Authorization': 'Bearer ${config.apiKey}'}),
      );
      if (resp.statusCode != 200) return null;
      final choices = resp.data['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) return null;
      final raw = (choices[0]['message']['content'] ?? '').toString().trim();
      return raw.isEmpty ? null : raw;
    } on DioException {
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 连通性测试：发一条极短消息，有回显即视为可用。
  Future<bool> test() async {
    final reply = await chat(
      const [ChatMessage(role: 'user', content: '回复“OK”两个字即可')],
      temperature: 0,
      maxTokens: 10,
    );
    return reply != null && reply.isNotEmpty;
  }

  /// 从模型回复里尽量提取纯文本（去掉可能的 markdown 代码块包裹）
  static String stripMarkdown(String raw) {
    var s = raw.trim();
    final fence = RegExp(r'```(?:json|markdown)?\s*([\s\S]*?)\s*```')
        .firstMatch(s);
    if (fence != null) s = fence.group(1)!.trim();
    return s;
  }

  /// 尝试解析模型回复为 JSON（三级兜底），失败返回 null
  static Map<String, dynamic>? tryParseJson(String raw) {
    String content = stripMarkdown(raw);
    try {
      final decoded = jsonDecode(content);
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {}
    final brace = RegExp(r'\{[\s\S]*\}').firstMatch(content);
    if (brace != null) {
      try {
        final decoded = jsonDecode(brace.group(0)!);
        if (decoded is Map<String, dynamic>) return decoded;
      } catch (_) {}
    }
    return null;
  }
}
