import 'dart:convert';
import 'dart:typed_data';

import 'package:dio/dio.dart';

/// 智谱 AI 药品识别服务。
///
/// 定位是「**兜底**」：只有在离线条码库（`DrugDb`）与后端都拿不到结果时才走到这里。
/// 命中顺序见 `DrugDb` / `xunyuan_page._lookup`。
///
/// 两条能力：
///  - 文本：`glm-4-flash`，用于药名搜索与条码兜底
///  - 视觉：`glm-4v-flash`（官方定价免费），用于拍照识药
class ZhipuService {
  /// API Key 走编译期注入，便于 CI 与不同账号切换：
  ///   flutter build apk --dart-define=ZHIPU_KEY=xxx
  ///
  /// ⚠️ defaultValue 目前仍是历史明文密钥，仅为保证现有包不停服。
  /// 正式提交/开源前必须把 defaultValue 置空，并轮换该 Key、清理 git 历史 ——
  /// 源码里的字符串可被反编译直接提取。
  static const String _apiKey = String.fromEnvironment(
    'ZHIPU_KEY',
    defaultValue: 'cb6a756da78c4e31bf8331a044bc2586.ybW466UPdpMq6A3q',
  );

  static const String _apiUrl =
      'https://open.bigmodel.cn/api/paas/v4/chat/completions';
  static const String _textModel = 'glm-4-flash';

  /// 免费的多模态模型。若后续遇到上下文超限，可换 `glm-4.6v-flash`（同为免费）。
  static const String _visionModel = 'glm-4v-flash';

  /// AI **允许**输出的字段。
  ///
  /// 分级管控的核心闸门：即使模型自作主张返回了医疗字段，
  /// 也会被 [_sanitize] 拦掉，绝不进入 UI。
  static const Set<String> _allowedKeys = {
    'drugName', // 药品名称
    'brand', // 商品名
    'manu', // 生产企业
    'ggxh', // 规格
    'pzwh', // 批准文号
    'type', // 剂型 / 分类
    'shelfLifeMonths', // 有效期（月）
    'confidence', // 置信度 0~1
    'isMedicine', // 图片是否为药品
    'rawText', // 模型从包装上读到的原文
    'queryType', // 查询类型
    'relatedDrugs', // 相关药品名称（仅为名称列表，非诊疗建议）
    'source', // 来源标记
  };

  /// AI 药箱安全报告**允许**输出的字段。
  ///
  /// 与药品识别分开管理：报告只输出整理与收纳建议，
  /// 因此白名单里没有任何医疗字段，连 `relatedDrugs` 都不给。
  static const Set<String> _reportKeys = {
    'summary', // 一句话总评（不涉诊疗）
    'suggestions', // 整理建议列表
    'storageTips', // 收纳存放建议
    'source',
  };

  /// RAG 问药**允许**输出的字段。
  ///
  /// 与药品识别/报告分开管理：问药只允许输出「组织好的回答 + 涉及的药品名」，
  /// 不给任何独立医疗字段（适应症/禁忌/用法等只能来自官方说明书原文，
  /// 且只能以引用方式出现在 answer 里，不允许作为独立字段返回）。
  static const Set<String> _qaKeys = {
    'answer', // 组织好的回答（只引用官方说明书原文）
    'drugs', // 涉及到的药品名列表（仅为名称，非诊疗结论）
    'source',
  };

  final Dio _dio;

  ZhipuService({Dio? dio})
      : _dio = dio ??
            Dio(BaseOptions(
              // 视觉模型比文本慢得多，接收超时给到 40s，避免把正常请求误杀
              connectTimeout: const Duration(seconds: 15),
              receiveTimeout: const Duration(seconds: 40),
              headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer $_apiKey',
              },
            ));

  /// Key 是否可用。为空时所有调用直接返回 null，走 UI 降级。
  bool get hasKey => _apiKey.isNotEmpty;

  // ---------------------------------------------------------------- 文本能力

  /// 智能药品搜索（支持药名/症状/药效/病症/服用规则等多种查询方式）
  Future<Map<String, dynamic>?> searchDrugByName(String keyword) async {
    final prompt = '''
你是一个专业的药品信息智能搜索引擎。用户可能输入以下任意类型的关键词：
- 药品名称（如：阿莫西林、布洛芬）
- 症状描述（如：发烧、头痛、咳嗽、胃痛）
- 药效需求（如：退烧、止痛、消炎、止咳）
- 服用规则（如：饭前服用、一日三次）
- 疾病/病症（如：感冒、高血压、糖尿病）
- 药品分类（如：抗生素、降压药、感冒药）

用户查询：$keyword

请推荐最相关的药品。若用户描述的是症状/病症，推荐 2-3 种常用非处方药。
以 JSON 返回（未知项填空字符串）：
{
  "drugName": "药品通用名（多种用顿号分隔）",
  "manu": "代表生产企业",
  "type": "药品分类",
  "pzwh": "批准文号",
  "ggxh": "常见规格",
  "relatedDrugs": "同类药品推荐 2-3 种",
  "queryType": "drug_name/symptom/effect/disease/usage_rule/category"
}

严格要求：
1. 只输出 JSON，不要用 markdown 包裹
2. **禁止**输出适应症、用法用量、禁忌、贮藏条件、成份 —— 这些只能取自官方说明书
3. 不确定就填空字符串，禁止编造
''';
    return _chat(model: _textModel, prompt: prompt);
  }

  /// 根据条码兜底推断药品
  Future<Map<String, dynamic>?> lookupByCode(String code) async {
    final prompt = '''
你是药品条码识别助手。根据商品条码判断其可能的药品信息。

条码号：$code
条码前缀对应的国家/地区：${_barcodeCountry(code)}

以 JSON 返回（未知项填空字符串）：
{
  "drugName": "该条码可能对应的药品名称",
  "manu": "可能的制药企业",
  "ggxh": "常见规格",
  "type": "药品类型",
  "confidence": 0.0,
  "rawText": "条码${code.length >= 3 ? code.substring(0, 3) : code}前缀属于${_barcodeCountry(code)}"
}

严格要求：
1. 只输出 JSON，不要用 markdown 包裹
2. **禁止**输出适应症、用法用量、禁忌、贮藏条件、成份
3. 条码本身通常不含药名，无法确定就留空，confidence 给低值
''';
    return _chat(model: _textModel, prompt: prompt);
  }

  // ---------------------------------------------------------------- 视觉能力

  /// 拍照识药：把图片交给免费视觉模型做 OCR + 外观推断。
  ///
  /// [bytes] 应为压缩后的 JPEG（建议 <300KB）。返回结构与文本链路一致，
  /// 便于上层统一走 [_sanitize] 与 `Medicine.fromJson`。
  Future<Map<String, dynamic>?> recognizeByImage(Uint8List bytes) async {
    if (!hasKey || bytes.isEmpty) return null;
    final String b64 = base64Encode(bytes);
    final List<Map<String, dynamic>> content = [
      {
        'type': 'image_url',
        'image_url': {'url': 'data:image/jpeg;base64,$b64'},
      },
      {'type': 'text', 'text': _visionPrompt},
    ];
    final result = await _chat(
      model: _visionModel,
      content: content,
      temperature: 0.2,
      maxTokens: 800,
      receiveTimeout: const Duration(seconds: 40),
    );
    if (result == null) return null;
    return result..putIfAbsent('source', () => 'vision');
  }

  static const String _visionPrompt = '''
你是药品包装 OCR 助手。请仔细阅读图片中的药品包装（药盒、药瓶或说明书），
只提取你**确实看清的文字**，不要推测、不要补充常识。

以 JSON 返回（看不清的字段一律填空字符串）：
{
  "isMedicine": true,
  "drugName": "药品通用名，若包装上有商品名请写成「通用名 (商品名)」",
  "brand": "商品名 / 商标",
  "ggxh": "规格，如 0.1g*12片",
  "manu": "生产企业全称",
  "pzwh": "批准文号，如 国药准字H20023456",
  "type": "剂型，如 片剂 / 胶囊 / 颗粒",
  "shelfLifeMonths": 0,
  "confidence": 0.0,
  "rawText": "你在包装上读到的关键原文"
}

严格要求：
1. 只输出 JSON，不要用 ```json ``` 包裹
2. **禁止**输出适应症、功能主治、用法用量、禁忌、不良反应、贮藏条件、成份，
   无论你"知道"与否 —— 这些只能来自官方说明书，AI 提供会造成医疗风险
3. 图片里没有药品时 isMedicine 填 false，其余留空
4. 看不清就留空并把 confidence 调低，绝对不要编造
''';

  // ------------------------------------------------------- AI 药箱安全报告

  /// AI 药箱安全报告。
  ///
  /// **输入全部是本地确定性规则算好的结论**（过期分级来自 [ExpiryRule]、
  /// 成分冲突来自词典精确匹配），模型只做两件事：
  ///   1. 把这些结论翻译成一段通顺的总评；
  ///   2. 给出整理顺序与收纳建议。
  ///
  /// 刻意**不**让它判断"能不能一起吃""要不要停药"——那是医疗判断，
  /// 幻觉代价是真实的人身伤害。这也正是本 App 把"AI 要素"落在
  /// 整理与提醒、而不是诊疗上的原因：既拿到了 AI 加分项，又不越合规红线。
  ///
  /// 无 Key / 超时 / 返回非法时一律返回 null，调用方展示本地规则结论即可。
  Future<Map<String, dynamic>?> medicineBoxReport({
    required int total,
    required List<String> expired,
    required List<String> nearExpiry,
    required List<String> conflicts,
  }) async {
    if (!hasKey) return null;
    if (total <= 0) return null;

    String bullet(List<String> list) =>
        list.isEmpty ? '（无）' : list.map((e) => '- $e').join('\n');

    final prompt = '''
下面是某家庭药箱的**已经由本地规则计算完成的**盘点结论，请你据此生成一份整理建议。

【在册药品总数】$total
【已过期】
${bullet(expired)}
【30 天内到期】
${bullet(nearExpiry)}
【检测到重复成分或重复登记】
${bullet(conflicts)}

要求：
1. 只能输出 JSON：{"summary": "...", "suggestions": ["..."], "storageTips": "..."}
2. summary 一句话概括当前药箱状态，不超过 60 字
3. suggestions 给 3~5 条**整理与收纳**建议，每条不超过 40 字，按紧急程度排序
4. storageTips 一句存放建议，不超过 40 字
5. 严禁出现：能否同服、剂量、疗程、停药、诊断、替代用药等任何医疗与用药指导
6. 严禁编造上面列表里没有的药品名
''';

    return _chat(
      model: _textModel,
      prompt: prompt,
      temperature: 0.4,
      maxTokens: 700,
      receiveTimeout: const Duration(seconds: 25),
      allowedKeys: _reportKeys,
    );
  }

  // ---------------------------------------------------------------- 语音能力

  /// 语音转文字（ASR）。
  ///
  /// 复用同一个 API Key 与 open.bigmodel.cn 域名，端点 /audio/transcriptions。
  /// [audioBytes] 为录音文件（wav/mp3）的原始字节，内部转 base64 上传。
  /// 失败（无 Key / 超时 / 返回非法）一律返回 null，由调用方降级到键盘输入。
  Future<String?> transcribe(Uint8List audioBytes) async {
    if (!hasKey || audioBytes.isEmpty) return null;
    try {
      final String b64 = base64Encode(audioBytes);
      final resp = await _dio.post(
        'https://open.bigmodel.cn/api/paas/v4/audio/transcriptions',
        data: {
          'model': 'glm-asr-2512',
          'file_base64': b64,
        },
        options: Options(receiveTimeout: const Duration(seconds: 40)),
      );
      if (resp.statusCode != 200) return null;
      final data = resp.data;
      if (data is! Map) return null;
      // 多级兜底解析转录文本，兼容不同返回结构
      final dynamic raw = data['text'] ??
          data['transcript'] ??
          (data['data'] is Map ? (data['data'] as Map)['text'] : null);
      final String text = (raw ?? '').toString().trim();
      return text.isEmpty ? null : text;
    } on DioException {
      return null;
    } catch (_) {
      return null;
    }
  }

  // ------------------------------------------------------- RAG 问药

  /// RAG 问药：仅依据官方说明书原文组织回答。
  ///
  /// [question] 用户自然语言问题；[context] 检索命中的药品官方说明书字段
  /// 拼接文本（由 DrugQaService 从本地 SQLite 检索得到）。
  /// 模型只负责「理解问题 + 引用原文组织措辞」，绝不生成说明书之外的医疗内容。
  ///
  /// 无 Key / 空问题 / 空上下文时返回 null，调用方展示本地检索结果即可。
  Future<Map<String, dynamic>?> askQuestion({
    required String question,
    required String context,
  }) async {
    if (!hasKey) return null;
    if (question.trim().isEmpty) return null;

    final prompt = '''
你是药品信息助手。请**仅依据**下方【官方药品说明书】回答用户问题。

【用户问题】$question

【官方药品说明书】
${context.isEmpty ? '（未检索到相关药品说明书）' : context}

要求：
1. 只输出 JSON：{"answer": "...", "drugs": ["涉及的药品名"]}
2. answer 只能引用上方说明书原文，不得编造、不得用常识补充
3. 若说明书未包含该信息，answer 写"说明书未载明该信息，建议咨询药师或医师"
4. 严禁回答：能否同服、剂量、疗程、停药、诊断、替代用药等诊疗问题——遇到直接回答"涉及用药安全，请咨询药师或医师"
5. 严禁输出任何说明书原文之外的医疗字段
''';

    return _chat(
      model: _textModel,
      prompt: prompt,
      temperature: 0.3,
      maxTokens: 800,
      receiveTimeout: const Duration(seconds: 25),
      allowedKeys: _qaKeys,
    );
  }

  // ---------------------------------------------------------------- 通用调用

  Future<Map<String, dynamic>?> _chat({
    required String model,
    String? prompt,
    List<Map<String, dynamic>>? content,
    double temperature = 0.3,
    int maxTokens = 1024,
    Duration? receiveTimeout,
    Set<String>? allowedKeys,
  }) async {
    if (!hasKey) return null;
    try {
      final Map<String, dynamic> body = {
        'model': model,
        'messages': [
          {
            'role': 'system',
            'content':
                '你是专业的药品识别系统。严格按要求输出 JSON，不要添加解释。'
                    '禁止提供任何诊疗建议或用药指导。',
          },
          {'role': 'user', 'content': content ?? prompt},
        ],
        'temperature': temperature,
        'max_tokens': maxTokens,
      };

      // 文本链路用 25s，视觉链路 40s（推理更慢），避免共用 BaseOptions 把视觉请求误杀
    final resp = await _dio.post(
      _apiUrl,
      data: body,
      options: Options(receiveTimeout: receiveTimeout),
    );
      if (resp.statusCode != 200) return null;
      final choices = resp.data['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) return null;
      final String raw = (choices[0]['message']['content'] ?? '').toString();
      if (raw.isEmpty) return null;

      final parsed = _parseJson(raw);
      if (parsed == null) return null;
      return _sanitize(parsed, allowedKeys: allowedKeys);
    } on DioException {
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 分级管控闸门：只保留允许由 AI 生成的字段。
  ///
  /// 模型常常"好心"多返回几个字段（尤其 `syz` 适应症、`jj` 禁忌），
  /// 这些属于医疗信息，一旦是幻觉就会误导用户。这里统一丢弃。
  Map<String, dynamic> _sanitize(
    Map<String, dynamic> data, {
    Set<String>? allowedKeys,
  }) {
    final Set<String> allowed = allowedKeys ?? _allowedKeys;
    final Map<String, dynamic> out = <String, dynamic>{};
    for (final entry in data.entries) {
      if (allowed.contains(entry.key)) {
        out[entry.key] = entry.value;
      }
    }
    if (out.isEmpty) return <String, dynamic>{};
    out['source'] = 'ai';
    return out;
  }

  /// 从模型回复中提取 JSON（三级兜底）
  Map<String, dynamic>? _parseJson(String content) {
    try {
      final decoded = jsonDecode(content);
      if (decoded is Map<String, dynamic>) return decoded;
      return null;
    } catch (_) {
      // 模型常把 JSON 包在 markdown 代码块里
      final fence = RegExp(r'```(?:json)?\s*(\{[\s\S]*?\})\s*```').firstMatch(content);
      if (fence != null) {
        try {
          final decoded = jsonDecode(fence.group(1)!);
          if (decoded is Map<String, dynamic>) return decoded;
        } catch (_) {}
      }
      // 退一步：抓最外层花括号
      final brace = RegExp(r'\{[\s\S]*\}').firstMatch(content);
      if (brace != null) {
        try {
          final decoded = jsonDecode(brace.group(0)!);
          if (decoded is Map<String, dynamic>) return decoded;
        } catch (_) {}
      }
      return null;
    }
  }

  static String _barcodeCountry(String code) {
    if (code.length < 3) return '未知';
    final prefix = code.substring(0, 3);
    if (prefix.compareTo('690') >= 0 && prefix.compareTo('699') <= 0) {
      return '中国大陆';
    }
    const map = {
      '000': '美国/加拿大', '300': '法国', '400': '德国', '450': '日本',
      '460': '俄罗斯', '471': '中国台湾', '480': '菲律宾', '500': '英国',
      '560': '葡萄牙', '600': '南非', '730': '瑞典', '750': '墨西哥',
      '760': '瑞士', '770': '哥伦比亚', '780': '智利', '800': '意大利',
      '840': '西班牙', '870': '荷兰', '880': '韩国', '885': '泰国',
      '890': '印度', '930': '澳大利亚', '940': '新西兰', '955': '马来西亚',
    };
    return map[prefix] ?? '未知';
  }
}
