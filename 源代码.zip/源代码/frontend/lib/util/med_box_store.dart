import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/drug_item.dart';

/// 药箱本地存储 —— 单一数据源。
///
/// 药匣页与服药记录服务都通过它读写同一份药箱。
/// 服药记录递减余量后 bump [revision]，药匣页监听 [revision] 自动重新加载，
/// 解决「药匣页内存态 _items vs SharedPreferences 持久化」不同步的问题（冲突③）。
class MedBoxStore {
  MedBoxStore._();

  static const String key = 'yaoqingbao_drug_list';

  /// 数据版本号：任何写操作 +1，UI 监听它即可感知变化
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  static Future<List<DrugItem>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(key);
    if (s == null || s.isEmpty) return <DrugItem>[];
    try {
      final list = jsonDecode(s);
      if (list is List) {
        return list
            .whereType<Map>()
            .map((e) => DrugItem.fromJson(Map<String, dynamic>.from(e)))
            .toList();
      }
      return <DrugItem>[];
    } catch (_) {
      return <DrugItem>[];
    }
  }

  static Future<void> save(List<DrugItem> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      key,
      jsonEncode(items.map((e) => e.toJson()).toList()),
    );
    revision.value++;
  }

  static Future<void> upsert(DrugItem item) async {
    final items = await load();
    final index = items.indexWhere((e) => e.medicineId == item.medicineId);
    if (index >= 0) {
      items[index] = item;
    } else {
      items.add(item);
    }
    await save(items);
  }

  static Future<void> remove(String medicineId) async {
    final items = await load();
    items.removeWhere((e) => e.medicineId == medicineId);
    await save(items);
  }
}
