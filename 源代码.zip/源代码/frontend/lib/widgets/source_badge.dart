import 'package:flutter/material.dart';

import '../data/medicine.dart';
import 'design_icons.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 数据来源的可信级别。
///
/// 分级管控的可视化出口：用户必须能一眼分辨「这段说明书是官方原文」
/// 还是「这段是 AI 猜的」。医疗信息混着展示而不标注来源，是本类 App 最大的风险。
enum SourceTier {
  /// 官方说明书原文（离线条码库 / 药品数据库）
  official,

  /// AI 生成（仅名称、规格、厂家、剂型这类识别性字段）
  ai,

  /// 混合：名称由 AI 识别，说明书由官方库补全
  mixed,
}

/// 药品来源徽标。
///
/// 展示规则：
///  - `source` 以 codedb 开头 → 绿标「官方说明书」
///  - `source` 为 ai → 紫标「AI 参考」
///  - `source` 为 vision+codedb → 蓝标「AI 识别 + 官方说明书」
class SourceBadge extends StatelessWidget {
  const SourceBadge({super.key, required this.source, this.compact = false});

  final String source;

  /// 紧凑模式只显示一个小圆点 + 短文案，用于列表项
  final bool compact;

  static SourceTier tierOf(String source) {
    if (source.contains('codedb') && source.contains('vision')) {
      return SourceTier.mixed;
    }
    if (source.contains('codedb')) return SourceTier.official;
    if (source.contains('vision')) return SourceTier.ai;
    if (source == 'ai') return SourceTier.ai;
    return SourceTier.official;
  }

  static String labelOf(String source) {
    switch (tierOf(source)) {
      case SourceTier.official:
        return '官方说明书';
      case SourceTier.ai:
        return 'AI 参考';
      case SourceTier.mixed:
        return 'AI 识别 · 官方说明书';
    }
  }

  static Color colorOf(String source) {
    switch (tierOf(source)) {
      case SourceTier.official:
        return AppSemantic.sourceOfficial;
      case SourceTier.ai:
        return AppSemantic.sourceAi;
      case SourceTier.mixed:
        return AppSemantic.sourceMixed;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = colorOf(source);
    final label = labelOf(source);
    final bg = color.withValues(alpha: 0.10);

    if (compact) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(label,
              style: TextStyle(
                  fontSize: AppText.sizeCaption, color: color, fontWeight: FontWeight.w600)),
        ]),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        tierOf(source) == SourceTier.official
            ? DesignIcons.menuBook(size: 14, color: color)
            : DesignIcons.autoAwesome(size: 14, color: color),
        const SizedBox(width: 6),
        Text(label,
            style: TextStyle(
                fontSize: 12, color: color, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

/// 分级管控提示条。
///
/// 当这条药品**没有**官方说明书时明确告知，并说明为什么不给 AI 补全 ——
/// 宁可留白，也不能让模型编一段用法用量给用户。
class SourceDisclaimer extends StatelessWidget {
  const SourceDisclaimer({super.key, required this.medicine});

  final Medicine medicine;

  @override
  Widget build(BuildContext context) {
    if (medicine.hasOfficialInstruction) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warningTint,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.warningTint),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline, size: 16, color: AppColors.warning),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              '该药品暂未收录官方说明书。适应症、用法用量、禁忌等信息'
              '只采用官方来源，不会由 AI 生成，请以药品包装与说明书为准。',
              style: TextStyle(
                  fontSize: 12, height: 1.6, color: AppSemantic.sourceLocal),
            ),
          ),
        ],
      ),
    );
  }
}
