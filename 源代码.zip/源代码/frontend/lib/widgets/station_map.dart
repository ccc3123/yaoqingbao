import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../util/geo_utils.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 底图来源与审图号
///
/// 底图使用高德地图瓦片服务（GCJ-02 坐标系）。
/// 依据《地图管理条例》，互联网地图必须在可视范围内标注审图号，
/// 此处取自高德地图官网公示信息，上线前需与最新公示值核对。
const String kMapSourceName = '高德地图';
const String kMapApprovalNumber = 'GS(2024)1158号';
const String kMapSurveyLicense = '甲测资字11112528';

/// 回收点 / 药店地图组件
///
/// 基于用户定位标注附近点位，支持与列表联动：
/// 列表选中项 → 地图居中到该点；点击地图标注 → 回调给列表滚动定位。
class StationMap extends StatelessWidget {
  /// 站点列表，元素为在线或离线格式的 Map
  final List<Map<String, dynamic>> stations;
  /// 用户当前定位（WGS84），为空时不画"我的位置"
  final double? userLat;
  final double? userLng;
  /// 当前选中项在 stations 中的下标，-1 表示未选中
  final int selectedIndex;
  final void Function(int index) onMarkerTap;
  final double height;

  const StationMap({
    super.key,
    required this.stations,
    this.userLat,
    this.userLng,
    this.selectedIndex = -1,
    required this.onMarkerTap,
    this.height = 240,
  });

  /// 兼容在线（location:{lat,lng}）与离线（latitude/longitude）两种字段格式
  /// 字段可能是 num 也可能是字符串，统一安全转换，避免脏数据导致解析崩溃
  static double _num(dynamic v) {
    if (v == null) return 0.0;
    if (v is num) return v.toDouble();
    return double.tryParse(v.toString()) ?? 0.0;
  }

  static double latOf(Map s) {
    final loc = s['location'];
    if (loc is Map) return _num(loc['lat']);
    return _num(s['latitude'] ?? s['lat']);
  }

  static double lngOf(Map s) {
    final loc = s['location'];
    if (loc is Map) return _num(loc['lng']);
    return _num(s['longitude'] ?? s['lng']);
  }

  @override
  Widget build(BuildContext context) {
    // 1. 取有效点位并统一做 WGS84 → GCJ02 纠偏
    final points = <_StationPoint>[];
    for (int i = 0; i < stations.length; i++) {
      final lat = latOf(stations[i]);
      final lng = lngOf(stations[i]);
      if (lat == 0 && lng == 0) continue;
      final g = GeoUtils.wgs84ToGcj02(lat, lng);
      points.add(_StationPoint(
        index: i,
        name: (stations[i]['title'] ?? stations[i]['name'] ?? '回收点').toString(),
        lat: g[0],
        lng: g[1],
      ));
    }

    // 2. 决定地图中心：选中项 > 用户位置 > 首个点位 > 北京
    LatLng center;
    if (selectedIndex >= 0 && selectedIndex < points.length &&
        points.any((p) => p.index == selectedIndex)) {
      final p = points.firstWhere((p) => p.index == selectedIndex);
      center = LatLng(p.lat, p.lng);
    } else if (userLat != null && userLng != null) {
      final g = GeoUtils.wgs84ToGcj02(userLat!, userLng!);
      center = LatLng(g[0], g[1]);
    } else if (points.isNotEmpty) {
      center = LatLng(points.first.lat, points.first.lng);
    } else {
      center = const LatLng(39.90923, 116.397428);
    }

    final markers = <Marker>[];

    // 用户位置标注
    if (userLat != null && userLng != null) {
      final g = GeoUtils.wgs84ToGcj02(userLat!, userLng!);
      markers.add(Marker(
        point: LatLng(g[0], g[1]),
        width: 28,
        height: 28,
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.info,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.2), blurRadius: 4)],
          ),
          child: const Icon(Icons.my_location, size: 14, color: Colors.white),
        ),
      ));
    }

    // 站点标注
    for (final p in points) {
      final selected = p.index == selectedIndex;
      markers.add(Marker(
        point: LatLng(p.lat, p.lng),
        width: selected ? 40 : 32,
        height: selected ? 40 : 32,
        child: GestureDetector(
          onTap: () => onMarkerTap(p.index),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: selected ? AppColors.danger : AppColors.primary,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.18), blurRadius: 3)],
              ),
              child: Text(
                selected ? p.name : '${p.index + 1}',
                style: const TextStyle(color: Colors.white, fontSize: AppText.sizeCaption, fontWeight: FontWeight.w700),
                overflow: TextOverflow.ellipsis,
              ),
            ),
            Icon(
              Icons.location_pin,
              size: selected ? 24 : 20,
              color: selected ? AppColors.danger : AppColors.primary,
            ),
          ]),
        ),
      ));
    }

    return SizedBox(
      height: height,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(children: [
          // 用 ValueKey 触发重建来切换中心点，避免强依赖 MapController 的版本差异
          FlutterMap(
            key: ValueKey('${center.latitude.toStringAsFixed(5)}_${center.longitude.toStringAsFixed(5)}'),
            options: MapOptions(
              initialCenter: center,
              initialZoom: selectedIndex >= 0 ? 15.5 : 13,
              // 限制缩放范围，避免用户放大到没有瓦片的层级
              minZoom: 4,
              maxZoom: 18,
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',
                subdomains: const ['1', '2', '3', '4'],
                userAgentPackageName: 'cn.edu.ppsuc.yaoqingbao',
                maxZoom: 18,
              ),
              MarkerLayer(markers: markers),
            ],
          ),

          // 图例
          Positioned(
            left: 10,
            top: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.92),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle)),
                const SizedBox(width: 5),
                const Text('回收点', style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.ink3)),
                const SizedBox(width: 10),
                Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.info, shape: BoxShape.circle)),
                const SizedBox(width: 5),
                const Text('我的位置', style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.ink3)),
              ]),
            ),
          ),

          // 审图号：地图服务合规要求，必须常驻可见
          Positioned(
            right: 6,
            bottom: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '$kMapSourceName · 审图号：$kMapApprovalNumber · $kMapSurveyLicense',
                style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.ink3),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

class _StationPoint {
  final int index;
  final String name;
  final double lat;
  final double lng;
  const _StationPoint({required this.index, required this.name, required this.lat, required this.lng});
}
