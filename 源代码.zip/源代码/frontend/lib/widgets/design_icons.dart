import 'package:flutter/material.dart';
import '../theme/app_text.dart';

/// 自定义设计图标
/// - 底部三节点：使用设计师裁剪好的 3 张独立 PNG 图片
/// - 其余图标：使用 Material Icon 保留明确辨识度
/// - 绿色背景创意字体：双层阴影确保白色文字在任何深浅绿色上都清晰
class DesignIcons {
  DesignIcons._();

  // ═══════════════════════════════════════════════
  //  底部导航三节点图标（设计师裁剪的独立PNG）
  // ═══════════════════════════════════════════════

  static Widget nodeXunYuan({double? size, Color? color}) =>
      _navIcon('assets/images/icons-nodes1.png', size: size, color: color);

  static Widget nodeYaoXia({double? size, Color? color}) =>
      _navIcon('assets/images/icons-nodes2.png', size: size, color: color);

  static Widget nodeGuiChu({double? size, Color? color}) =>
      _navIcon('assets/images/icons-nodes3.png', size: size, color: color);

  static Widget _navIcon(String path, {double? size, Color? color}) {
    final s = size ?? 24;
    return SizedBox(
      width: s,
      height: s,
      child: Image.asset(path, fit: BoxFit.contain, color: color),
    );
  }

  // ═══════════════════════════════════════════════
  //  创意绿色背景字体效果（双层阴影保证可读性）
  // ═══════════════════════════════════════════════

  /// 大标题（dark green 头部）— 纯白加粗，字距拉开
  static TextStyle greenBgTitle({double fontSize = 20}) => TextStyle(
        color: Colors.white,
        fontSize: fontSize,
        fontWeight: FontWeight.w800,
        letterSpacing: 3,
      );

  /// 副标题 — 半透白，轻盈感
  static TextStyle greenBgSubtitle() => TextStyle(
        color: Colors.white70,
        fontSize: AppText.sizeCaption,
        letterSpacing: 2,
      );

  /// 统计数值（"0" / "3" 等大数字）— 纯白加粗
  static TextStyle greenBgValue({double fontSize = 26}) => TextStyle(
        color: Colors.white,
        fontSize: fontSize,
        fontWeight: FontWeight.w900,
        letterSpacing: 2,
      );

  /// 统计标签（"在册" / "已过期" 等小字）— 半透白
  static TextStyle greenBgLabel() => TextStyle(
        color: Colors.white60,
        fontSize: AppText.sizeCaption,
        fontWeight: FontWeight.w500,
        letterSpacing: 1,
      );

  // ═══════════════════════════════════════════════
  //  动作图标 → Material Icon（辨识度高）
  // ═══════════════════════════════════════════════

  static Widget eco({double? size, Color? color}) =>
      Icon(Icons.eco_rounded, size: size ?? 24, color: color);
  static Widget recycling({double? size, Color? color}) =>
      Icon(Icons.recycling, size: size ?? 24, color: color);
  static Widget medication({double? size, Color? color}) =>
      Icon(Icons.medication_rounded, size: size ?? 24, color: color);
  static Widget medicationOutlined({double? size, Color? color}) =>
      Icon(Icons.medication_outlined, size: size ?? 24, color: color);
  static Widget search({double? size, Color? color}) =>
      Icon(Icons.search, size: size ?? 24, color: color);
  static Widget searchOff({double? size, Color? color}) =>
      Icon(Icons.search_off, size: size ?? 24, color: color);
  static Widget location({double? size, Color? color}) =>
      Icon(Icons.location_on, size: size ?? 24, color: color);
  static Widget locationOutlined({double? size, Color? color}) =>
      Icon(Icons.location_on_outlined, size: size ?? 24, color: color);
  static Widget navigation({double? size, Color? color}) =>
      Icon(Icons.navigation_rounded, size: size ?? 24, color: color);
  static Widget mapIcon({double? size, Color? color}) =>
      Icon(Icons.map_outlined, size: size ?? 24, color: color);
  static Widget history({double? size, Color? color}) =>
      Icon(Icons.history, size: size ?? 24, color: color);
  static Widget calendar({double? size, Color? color}) =>
      Icon(Icons.calendar_today, size: size ?? 24, color: color);
  static Widget timer({double? size, Color? color}) =>
      Icon(Icons.timer, size: size ?? 24, color: color);
  static Widget add({double? size, Color? color}) =>
      Icon(Icons.add, size: size ?? 24, color: color);
  static Widget delete({double? size, Color? color}) =>
      Icon(Icons.delete, size: size ?? 24, color: color);
  static Widget warning({double? size, Color? color}) =>
      Icon(Icons.warning_amber_rounded, size: size ?? 24, color: color);
  static Widget dangerous({double? size, Color? color}) =>
      Icon(Icons.dangerous, size: size ?? 24, color: color);
  static Widget info({double? size, Color? color}) =>
      Icon(Icons.info_outline, size: size ?? 24, color: color);
  static Widget lightbulb({double? size, Color? color}) =>
      Icon(Icons.lightbulb_outline, size: size ?? 24, color: color);
  static Widget chevronRight({double? size, Color? color}) =>
      Icon(Icons.chevron_right, size: size ?? 24, color: color);
  static Widget arrowForward({double? size, Color? color}) =>
      Icon(Icons.arrow_forward_ios, size: size ?? 24, color: color);
  static Widget arrowDropDown({double? size, Color? color}) =>
      Icon(Icons.arrow_drop_down, size: size ?? 24, color: color);
  static Widget flash({double? size, Color? color}) =>
      Icon(Icons.flash_on_rounded, size: size ?? 24, color: color);
  static Widget menuBook({double? size, Color? color}) =>
      Icon(Icons.menu_book_outlined, size: size ?? 24, color: color);
  static Widget formatQuote({double? size, Color? color}) =>
      Icon(Icons.format_quote, size: size ?? 24, color: color);
  static Widget camera({double? size, Color? color}) =>
      Icon(Icons.camera_alt_rounded, size: size ?? 24, color: color);
  static Widget autoAwesome({double? size, Color? color}) =>
      Icon(Icons.auto_awesome, size: size ?? 24, color: color);
}
