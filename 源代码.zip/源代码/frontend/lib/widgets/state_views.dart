/// 加载 / 空 / 错误三态的统一呈现。
///
/// 原先 12 个页面各写一遍 `CircularProgressIndicator`，尺寸、文案、
/// 留白各不相同，且屏幕阅读器读不出"正在加载"这件事。收敛到这里后：
///   · 视觉一致；
///   · 加载态带 [Semantics] 的 liveRegion，读屏能播报；
///   · 空态与错误态强制要求一句人话说明，避免只甩一个图标。
library;

import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_dimens.dart';
import '../theme/app_text.dart';

/// 加载中。[message] 为空时只显示指示器（用于卡片内的小范围加载）。
class LoadingView extends StatelessWidget {
  const LoadingView({super.key, this.message = '正在加载…', this.compact = false});

  final String? message;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final indicator = SizedBox(
      width: compact ? 20 : 32,
      height: compact ? 20 : 32,
      child: CircularProgressIndicator(
        strokeWidth: compact ? 2 : 3,
        color: AppColors.primary,
      ),
    );

    return Semantics(
      liveRegion: true,
      label: message ?? '正在加载',
      excludeSemantics: true,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              indicator,
              if (message != null && !compact) ...[
                const SizedBox(height: AppSpacing.md),
                Text(message!, style: AppText.bodyMuted),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// 空数据。[action] 传入时在说明下方显示一个主按钮。
class EmptyView extends StatelessWidget {
  const EmptyView({
    super.key,
    required this.title,
    this.description,
    this.icon = Icons.inbox_outlined,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? description;
  final IconData icon;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 56, color: AppColors.primaryPale),
            const SizedBox(height: AppSpacing.lg),
            Text(title, style: AppText.title, textAlign: TextAlign.center),
            if (description != null) ...[
              const SizedBox(height: AppSpacing.sm),
              Text(
                description!,
                style: AppText.bodyMuted,
                textAlign: TextAlign.center,
              ),
            ],
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: AppSpacing.xl),
              FilledButton(onPressed: onAction, child: Text(actionLabel!)),
            ],
          ],
        ),
      ),
    );
  }
}

/// 出错。默认提供「重试」按钮，[onRetry] 为空时隐藏。
class ErrorView extends StatelessWidget {
  const ErrorView({
    super.key,
    this.title = '加载失败',
    this.description = '请检查网络后重试。',
    this.onRetry,
  });

  final String title;
  final String? description;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      liveRegion: true,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.xl),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.cloud_off_outlined,
                size: 56,
                color: AppColors.muted,
              ),
              const SizedBox(height: AppSpacing.lg),
              Text(title, style: AppText.title, textAlign: TextAlign.center),
              if (description != null) ...[
                const SizedBox(height: AppSpacing.sm),
                Text(
                  description!,
                  style: AppText.bodyMuted,
                  textAlign: TextAlign.center,
                ),
              ],
              if (onRetry != null) ...[
                const SizedBox(height: AppSpacing.xl),
                OutlinedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh, size: 18),
                  label: const Text('重试'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
