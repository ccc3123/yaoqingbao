import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/drug_item.dart';
import '../data/med_record.dart';
import '../data/user_profile.dart';
import '../routes/app_routes.dart';
import '../util/med_advisor.dart';
import 'design_icons.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// AI 服药助理小形象 —— 药匣页常驻的「药宝」。
///
/// 看到药箱里的药品就会冒气泡主动提示（联网 AI 发挥创意生成，断网走本地规则），
/// 点击进入问答页交互。
class MedAssistant extends StatefulWidget {
  final UserProfile profile;
  final List<DrugItem> items;
  final List<MedRecord> records;

  const MedAssistant({
    super.key,
    required this.profile,
    required this.items,
    required this.records,
  });

  @override
  State<MedAssistant> createState() => _MedAssistantState();
}

class _MedAssistantState extends State<MedAssistant> {
  String _tip = '';
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refreshTip();
  }

  Future<void> _refreshTip() async {
    setState(() => _loading = true);
    final tip = await MedAdvisor.instance.proactiveTip(
      profile: widget.profile,
      items: widget.items,
    );
    if (!mounted) return;
    setState(() {
      _tip = tip;
      _loading = false;
    });
  }

  void _openChat() {
    HapticFeedback.selectionClick();
    AppRoutes.toMedChat(
      context,
      profile: widget.profile,
      items: widget.items,
      records: widget.records,
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _openChat,
      child: Container(
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primaryTintWeak, AppSemantic.aiTint],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.primaryTint),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 小形象头像
            Column(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: const LinearGradient(
                      colors: [AppColors.primaryLight, AppColors.primaryStrong],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withValues(alpha: 0.35),
                        blurRadius: 10,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: DesignIcons.autoAwesome(size: 26, color: Colors.white),
                ),
                const SizedBox(height: 4),
                const Text('药宝',
                    style: TextStyle(
                        fontSize: AppText.sizeCaption,
                        fontWeight: FontWeight.w700,
                        color: AppColors.primaryStrong)),
              ],
            ),
            const SizedBox(width: 12),
            // 气泡
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      DesignIcons.autoAwesome(
                          size: 14, color: AppSemantic.ai),
                      const SizedBox(width: 6),
                      const Expanded(
                        child: Text('AI 服药助理',
                            style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w700,
                                color: AppSemantic.aiStrong)),
                      ),
                      GestureDetector(
                        onTap: _refreshTip,
                        child: const Padding(
                          padding: EdgeInsets.all(4),
                          child: Icon(Icons.refresh,
                              size: 16, color: AppSemantic.ai),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // 气泡内容
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(12),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(14),
                        bottomLeft: Radius.circular(14),
                        bottomRight: Radius.circular(14),
                      ),
                    ),
                    child: _loading
                        ? const SizedBox(
                            height: 18,
                            child: Center(
                              child: SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2)),
                            ),
                          )
                        : Text(
                            _tip,
                            style: const TextStyle(
                                fontSize: 13, height: 1.5, color: AppColors.ink),
                          ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Text('点击和我聊聊用药问题',
                          style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
                      const Spacer(),
                      DesignIcons.chevronRight(
                          size: 16, color: AppSemantic.ai),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
