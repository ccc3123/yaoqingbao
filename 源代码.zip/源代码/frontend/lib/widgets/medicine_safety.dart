import 'package:flutter/material.dart';

import '../data/drug_item.dart';
import '../util/expiry_rule.dart';
import '../util/ingredient.dart';
import '../util/zhipu_service.dart';
import 'design_icons.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 五级颜色。整个 App 的药品状态配色都从这里取，避免各处硬编码不一致。
class SafetyColors {
  SafetyColors._();

  static Color of(ExpiryLevel level) {
    switch (level) {
      case ExpiryLevel.expired:
        return AppColors.danger;
      case ExpiryLevel.danger:
        return AppColors.danger;
      case ExpiryLevel.warn:
        return AppColors.warning;
      case ExpiryLevel.notice:
        return AppColors.warning;
      case ExpiryLevel.safe:
        return AppColors.primaryLight;
    }
  }

  /// 浅色底（卡片背景 / 图标底）
  static Color bgOf(ExpiryLevel level) => of(level).withValues(alpha: 0.10);
}

/// 药箱安全快照：一次遍历算好，UI 只负责渲染。
///
/// 全部是**纯本地计算**，断网、无 AI Key 时结论完全一致 ——
/// 这是"AI 药箱安全管家"里 AI 只做锦上添花的前提。
class SafetySnapshot {
  SafetySnapshot._({
    required this.total,
    required this.counts,
    required this.conflicts,
    required this.expiredNames,
    required this.nearExpiryNames,
  });

  final int total;

  /// 每个等级的数量
  final Map<ExpiryLevel, int> counts;

  /// 重复成分 / 重复登记提醒
  final List<IngredientConflict> conflicts;

  final List<String> expiredNames;
  final List<String> nearExpiryNames;

  /// 从药匣条目计算快照。
  ///
  /// [items] 应传入**未回收**的条目；已回收的不参与安全评估。
  static SafetySnapshot of(List<DrugItem> items) {
    final counts = <ExpiryLevel, int>{
      for (final l in ExpiryLevel.values) l: 0,
    };

    final expiredNames = <String>[];
    final nearExpiryNames = <String>[];

    for (final item in items) {
      final verdict = ExpiryRule.judge(
        remainDays: item.countDown,
        drugName: item.medicineName,
        openedDays: item.openedDays,
      );
      counts[verdict.level] = (counts[verdict.level] ?? 0) + 1;

      if (verdict.level == ExpiryLevel.expired) {
        expiredNames.add(item.medicineName);
      } else if (verdict.level == ExpiryLevel.danger ||
          verdict.level == ExpiryLevel.warn) {
        nearExpiryNames.add(item.medicineName);
      }
    }

    final conflicts = DuplicateChecker.check(
      items
          .map((e) => MedicineEntry(
                name: e.medicineName,
                component: e.component,
                manu: e.manu,
              ))
          .toList(),
    );

    return SafetySnapshot._(
      total: items.length,
      counts: counts,
      conflicts: conflicts,
      expiredNames: expiredNames,
      nearExpiryNames: nearExpiryNames,
    );
  }

  int count(ExpiryLevel l) => counts[l] ?? 0;

  /// 需要立刻处理的数量（已过期 + 7 天内）
  int get urgent => count(ExpiryLevel.expired) + count(ExpiryLevel.danger);

  /// 强冲突（同成分跨药品）数量
  int get strongConflicts =>
      conflicts.where((c) => c.level == ConflictLevel.strong).length;

  /// 是否需要拉响警报
  bool get hasAlert => urgent > 0 || strongConflicts > 0;

  /// 完全没有需要处理的项
  bool get isClean => !hasAlert && count(ExpiryLevel.warn) == 0;

  /// 一句话状态（本地规则产出，不经过 AI）
  String get headline {
    if (total == 0) return '药箱为空';
    if (count(ExpiryLevel.expired) > 0) {
      return '${count(ExpiryLevel.expired)} 种已过期，需立即处理';
    }
    if (strongConflicts > 0) return '检测到 $strongConflicts 组重复成分';
    if (urgent > 0) return '$urgent 种即将到期';
    if (count(ExpiryLevel.warn) > 0) return '${count(ExpiryLevel.warn)} 种临近有效期';
    return '药箱状态良好';
  }
}

/// 药匣页顶部的安全区：分级汇总 + 重复成分提醒 + AI 报告入口。
class SafetyZone extends StatelessWidget {
  const SafetyZone({
    super.key,
    required this.snapshot,
    required this.onGoMap,
  });

  final SafetySnapshot snapshot;
  final VoidCallback onGoMap;

  @override
  Widget build(BuildContext context) {
    // 药箱为空时只展示小贴士，不占视觉重心
    if (snapshot.total == 0) {
      return _buildTips();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildLevelBar(),
        if (snapshot.count(ExpiryLevel.expired) > 0) ...[
          const SizedBox(height: 10),
          _buildExpiredCard(),
        ],
        if (snapshot.conflicts.isNotEmpty) ...[
          const SizedBox(height: 10),
          ...snapshot.conflicts
              .take(2)
              .map((c) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _buildConflictCard(c),
                  )),
        ],
        if (snapshot.conflicts.length > 2) ...[
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(
              '另有 ${snapshot.conflicts.length - 2} 条提醒，见下方 AI 安全报告',
              style: const TextStyle(fontSize: 12, color: AppColors.muted),
            ),
          ),
        ],
      ],
    );
  }

  /// 五级分布条：一眼看清整体结构
  Widget _buildLevelBar() {
    const order = [
      ExpiryLevel.expired,
      ExpiryLevel.danger,
      ExpiryLevel.warn,
      ExpiryLevel.notice,
      ExpiryLevel.safe,
    ];
    final visible = order.where((l) => snapshot.count(l) > 0).toList();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            DesignIcons.autoAwesome(size: 16, color: AppColors.primary),
            const SizedBox(width: 6),
            const Text('药箱安全概览',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
            const Spacer(),
            Text(
              snapshot.headline,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: snapshot.hasAlert
                    ? AppColors.danger
                    : AppColors.primary,
              ),
            ),
          ]),
          const SizedBox(height: 12),
          if (visible.isEmpty)
            const Text('暂无分级数据', style: TextStyle(fontSize: 12, color: AppColors.muted))
          else
            Row(
              children: visible
                  .map((l) => Expanded(
                        flex: snapshot.count(l),
                        child: _levelSegment(l),
                      ))
                  .toList(),
            ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 12,
            runSpacing: 6,
            children: visible.map(_levelLegend).toList(),
          ),
        ],
      ),
    );
  }

  Widget _levelSegment(ExpiryLevel level) {
    return Container(
      height: 8,
      margin: const EdgeInsets.symmetric(horizontal: 1),
      decoration: BoxDecoration(
        color: SafetyColors.of(level),
        borderRadius: BorderRadius.circular(4),
      ),
    );
  }

  Widget _levelLegend(ExpiryLevel level) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            color: SafetyColors.of(level),
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        const SizedBox(width: 4),
        Text('${_levelLabel(level)} ${snapshot.count(level)}',
            style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.ink3)),
      ],
    );
  }

  Widget _buildExpiredCard() {
    return Builder(builder: (context) {
      return GestureDetector(
        onTap: onGoMap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.dangerTint,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(children: [
            DesignIcons.warning(size: 18, color: AppColors.danger),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '${snapshot.count(ExpiryLevel.expired)} 种药品已过期，请尽快处理',
                style: const TextStyle(color: AppColors.danger, fontSize: 14),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.danger,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text('立即处理 →',
                  style: TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ]),
        ),
      );
    });
  }

  Widget _buildConflictCard(IngredientConflict c) {
    final strong = c.level == ConflictLevel.strong;
    final color = strong ? AppColors.danger : AppSemantic.conflict;
    final bg = strong ? AppColors.dangerTint : AppSemantic.categoryScienceTint;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(strong ? Icons.medication_liquid : Icons.copy_all,
                size: 18, color: color),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                strong ? '重复成分：${c.display}' : '重复登记：${c.display}',
                style: TextStyle(
                    fontSize: 14, fontWeight: FontWeight.w600, color: color),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(strong ? '强提醒' : '待核对',
                  style: TextStyle(fontSize: AppText.sizeCaption, color: color)),
            ),
          ]),
          const SizedBox(height: 8),
          Text(
            c.drugNames.join('、'),
            style: const TextStyle(fontSize: 12, color: AppColors.ink3),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 4),
          Text(c.reason,
              style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
        ],
      ),
    );
  }

  Widget _buildTips() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.primaryTintWeak,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.primaryTint),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          DesignIcons.lightbulb(size: 20, color: AppColors.primary),
          const SizedBox(width: 8),
          const Text('家庭药品管理小贴士',
              style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primaryStrong)),
        ]),
        const SizedBox(height: 10),
        const Text(
          '• 每3个月检查一次家庭药箱\n• 过期药品属于危险废物，请勿随意丢弃\n'
          '• 将药品存放在阴凉干燥处，避免儿童接触\n• 不同药品分开存放，避免交叉污染',
          style: TextStyle(fontSize: 12, color: AppColors.ink3, height: 1.8),
        ),
      ]),
    );
  }

  static String _levelLabel(ExpiryLevel level) {
    switch (level) {
      case ExpiryLevel.expired:
        return '已过期';
      case ExpiryLevel.danger:
        return '紧急';
      case ExpiryLevel.warn:
        return '临近';
      case ExpiryLevel.notice:
        return '关注';
      case ExpiryLevel.safe:
        return '安全';
    }
  }
}

/// AI 药箱安全报告弹层。
///
/// 结构刻意做成「**本地结论在上，AI 建议在下**」：
/// 即使 AI 不可用，用户拿到的信息依然是完整可信的。
class SafetyReportSheet extends StatefulWidget {
  const SafetyReportSheet({
    super.key,
    required this.snapshot,
    required this.service,
    this.onGoMap,
  });

  final SafetySnapshot snapshot;
  final ZhipuService service;
  final VoidCallback? onGoMap;

  @override
  State<SafetyReportSheet> createState() => _SafetyReportSheetState();
}

class _SafetyReportSheetState extends State<SafetyReportSheet> {
  bool _loading = false;
  Map<String, dynamic>? _report;
  String? _error;

  @override
  void initState() {
    super.initState();
    _generate();
  }

  Future<void> _generate() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });

    final conflictTexts = widget.snapshot.conflicts
        .map((c) => c.level == ConflictLevel.strong
            ? '${c.display}：${c.drugNames.join("、")}'
            : '重复登记 ${c.display}')
        .toList();

    final res = await widget.service.medicineBoxReport(
      total: widget.snapshot.total,
      expired: widget.snapshot.expiredNames,
      nearExpiry: widget.snapshot.nearExpiryNames,
      conflicts: conflictTexts,
    );

    if (!mounted) return;
    setState(() {
      _loading = false;
      if (res == null || res.isEmpty) {
        _error = 'AI 建议暂不可用（离线或无可用模型）\n下方为本地规则结论，可正常参考';
      } else {
        _report = res;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.snapshot;
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(children: [
              DesignIcons.autoAwesome(size: 20, color: AppColors.primary),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('AI 药箱安全报告',
                    style:
                        TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 20),
                onPressed: () => Navigator.pop(context),
              ),
            ]),
            const SizedBox(height: 6),
            const Text(
              '风险分级与成分比对由本地规则计算，断网可用；下方建议由 AI 生成，仅供参考。',
              style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted),
            ),
            const SizedBox(height: 16),

            // ---- 本地确定性结论 ----
            _sectionTitle('本地盘点', AppColors.primary),
            const SizedBox(height: 8),
            _statRow(),
            if (s.conflicts.isNotEmpty) ...[
              const SizedBox(height: 12),
              ...s.conflicts.map(_conflictLine),
            ],

            const SizedBox(height: 18),

            // ---- AI 建议 ----
            _sectionTitle('AI 整理建议', AppSemantic.ai),
            const SizedBox(height: 8),
            if (_loading)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 18),
                child: Center(
                    child: SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2))),
              )
            else if (_error != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.warningTint,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(children: [
                  DesignIcons.info(size: 16, color: AppColors.warning),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(_error!,
                          style: const TextStyle(
                              fontSize: 12, color: AppSemantic.sourceLocal))),
                ]),
              )
            else if (_report != null)
              _reportBody(_report!),

            if (s.count(ExpiryLevel.expired) > 0 && widget.onGoMap != null) ...[
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: widget.onGoMap,
                icon: DesignIcons.navigation(size: 18, color: Colors.white),
                label: const Text('查看附近回收点'),
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text, Color color) {
    return Row(children: [
      Container(width: 3, height: 14, color: color),
      const SizedBox(width: 8),
      Text(text,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
    ]);
  }

  Widget _statRow() {
    final s = widget.snapshot;
    return Row(children: [
      _statCell('在册', '${s.total}', AppColors.primaryLight),
      _statCell('已过期', '${s.count(ExpiryLevel.expired)}',
          SafetyColors.of(ExpiryLevel.expired)),
      _statCell('紧急', '${s.count(ExpiryLevel.danger)}',
          SafetyColors.of(ExpiryLevel.danger)),
      _statCell('临近', '${s.count(ExpiryLevel.warn)}',
          SafetyColors.of(ExpiryLevel.warn)),
      _statCell('重复', '${s.conflicts.length}', AppSemantic.conflict),
    ]);
  }

  Widget _statCell(String label, String value, Color color) {
    return Expanded(
      child: Column(children: [
        Text(value,
            style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w700, color: color)),
        const SizedBox(height: 2),
        Text(label, style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
      ]),
    );
  }

  Widget _conflictLine(IngredientConflict c) {
    final strong = c.level == ConflictLevel.strong;
    final color = strong ? AppColors.danger : AppSemantic.conflict;
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(strong ? Icons.medication_liquid : Icons.copy_all,
              size: 15, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              strong
                  ? '${c.display}：${c.drugNames.join("、")}'
                  : '${c.display}（${c.reason}）',
              style: TextStyle(fontSize: 12, color: color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _reportBody(Map<String, dynamic> data) {
    final summary = (data['summary'] ?? '').toString().trim();
    final tips = (data['storageTips'] ?? '').toString().trim();
    final rawSuggestions = data['suggestions'];
    final suggestions = <String>[];
    if (rawSuggestions is List) {
      for (final e in rawSuggestions) {
        final t = e.toString().trim();
        if (t.isNotEmpty) suggestions.add(t);
      }
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.subtleBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppSemantic.aiTint),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (summary.isNotEmpty)
            Text(summary,
                style: const TextStyle(
                    fontSize: 13,
                    height: 1.6,
                    color: AppColors.ink,
                    fontWeight: FontWeight.w600)),
          if (suggestions.isNotEmpty) ...[
            const SizedBox(height: 10),
            ...suggestions.map((s) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('• ',
                          style:
                              TextStyle(fontSize: 12, color: AppSemantic.ai)),
                      Expanded(
                        child: Text(s,
                            style: const TextStyle(
                                fontSize: 12,
                                height: 1.6,
                                color: AppColors.ink2)),
                      ),
                    ],
                  ),
                )),
          ],
          if (tips.isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(children: [
              DesignIcons.lightbulb(size: 14, color: AppSemantic.ai),
              const SizedBox(width: 6),
              Expanded(
                child: Text(tips,
                    style: const TextStyle(
                        fontSize: 12, color: AppSemantic.ai, height: 1.5)),
              ),
            ]),
          ],
        ],
      ),
    );
  }
}
