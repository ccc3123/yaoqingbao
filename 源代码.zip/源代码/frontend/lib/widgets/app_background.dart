import 'package:flutter/material.dart';

/// Wraps content with the river-landscape background image.
///
/// Uses a [Stack] with the header-bg.png image at the bottom,
/// an optional semi-transparent tint overlay, and the child content on top.
/// This approach keeps the background fixed while content scrolls over it.
class AppBackground extends StatelessWidget {
  final Widget child;
  final Color? overlayColor;
  final double overlayOpacity;
  final Alignment imageAlignment;
  final BoxFit imageFit;

  const AppBackground({
    super.key,
    required this.child,
    this.overlayColor,
    this.overlayOpacity = 0.0,
    this.imageAlignment = Alignment.topCenter,
    this.imageFit = BoxFit.cover,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Layer 0: Background image
        Positioned.fill(
          child: Image.asset(
            'assets/images/header-bg.png',
            fit: imageFit,
            alignment: imageAlignment,
          ),
        ),
        // Layer 1: Optional tint overlay for readability
        if (overlayColor != null && overlayOpacity > 0)
          Positioned.fill(
            child: Container(color: overlayColor!.withValues(alpha: overlayOpacity)),
          ),
        // Layer 2: Content
        Positioned.fill(child: child),
      ],
    );
  }
}
