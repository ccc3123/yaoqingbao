import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/user_profile.dart';
import '../routes/app_routes.dart';
import '../util/profile_service.dart';
import '../theme/app_colors.dart';

/// 个人健康问卷（首次启动 / 个人中心编辑共用）
///
/// 收集姓名、性别、年龄、疾病史、身体状况，AI 服药助理据此做个性化评估。
/// **数据仅存本机**，不上传后端。
class ProfileSetupPage extends StatefulWidget {
  final bool isFirstLaunch;

  const ProfileSetupPage({super.key, this.isFirstLaunch = false});

  @override
  State<ProfileSetupPage> createState() => _ProfileSetupPageState();
}

class _ProfileSetupPageState extends State<ProfileSetupPage> {
  static const _ink = AppColors.ink;
  static const _mutedInk = AppColors.ink3;
  static const _accent = AppColors.primary;

  final _nameCtrl = TextEditingController();
  final _yearCtrl = TextEditingController();
  final _conditionCtrl = TextEditingController();
  final _allergyCtrl = TextEditingController();
  final _customDiseaseCtrl = TextEditingController();

  String _gender = '';
  final Set<String> _diseases = {};

  static const List<String> _commonDiseases = [
    '高血压',
    '糖尿病',
    '冠心病',
    '哮喘',
    '肝肾疾病',
    '消化系统疾病',
    '过敏体质',
    '无慢性病',
  ];

  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await ProfileService.load();
    if (!mounted) return;
    setState(() {
      _nameCtrl.text = p.name;
      _yearCtrl.text = p.birthYear > 0 ? '${p.birthYear}' : '';
      _gender = p.gender;
      _diseases
        ..clear()
        ..addAll(p.diseaseHistory.where((e) => _commonDiseases.contains(e)));
      _customDiseaseCtrl.text =
          p.diseaseHistory.where((e) => !_commonDiseases.contains(e)).join('、');
      _conditionCtrl.text = p.condition;
      _allergyCtrl.text = p.allergies;
    });
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _yearCtrl.dispose();
    _conditionCtrl.dispose();
    _allergyCtrl.dispose();
    _customDiseaseCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    HapticFeedback.mediumImpact();
    final name = _nameCtrl.text.trim();
    final year = int.tryParse(_yearCtrl.text.trim()) ?? 0;
    if (name.isEmpty) {
      _toast('请填写称呼');
      return;
    }
    if (_gender.isEmpty) {
      _toast('请选择性别');
      return;
    }
    if (year <= 1900 || year > DateTime.now().year) {
      _toast('请填写正确的出生年份');
      return;
    }

    final diseases = <String>[..._diseases];
    final custom = _customDiseaseCtrl.text
        .split(RegExp(r'[、,，\s]+'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty);
    diseases.addAll(custom);

    setState(() => _saving = true);
    await ProfileService.save(UserProfile(
      name: name,
      gender: _gender,
      birthYear: year,
      diseaseHistory: diseases,
      condition: _conditionCtrl.text.trim(),
      allergies: _allergyCtrl.text.trim(),
    ));
    if (!mounted) return;
    setState(() => _saving = false);
    if (widget.isFirstLaunch) {
      AppRoutes.toHome(context);
    } else {
      Navigator.pop(context, true);
    }
  }

  void _toast(String msg) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    messenger?.showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('个人健康档案'),
        automaticallyImplyLeading: !widget.isFirstLaunch,
        backgroundColor: AppColors.surface,
        foregroundColor: _ink,
        titleTextStyle: const TextStyle(
          color: _ink,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      body: Theme(
        data: Theme.of(context).copyWith(
          textTheme: Theme.of(context).textTheme.copyWith(
                bodyLarge: const TextStyle(color: _ink, fontSize: 16),
                bodyMedium: const TextStyle(color: _ink, fontSize: 14),
                bodySmall: const TextStyle(color: _mutedInk, fontSize: 12),
              ),
          inputDecorationTheme: Theme.of(context).inputDecorationTheme.copyWith(
                labelStyle: const TextStyle(color: _mutedInk),
                floatingLabelStyle: const TextStyle(color: _accent),
                hintStyle: const TextStyle(color: _mutedInk),
                prefixIconColor: _mutedInk,
                suffixIconColor: _mutedInk,
              ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.primaryTintWeak,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.lock_outline, size: 16, color: _accent),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '健康档案仅存本机、不上传，AI 据此为你做个性化用药评估',
                        style: TextStyle(
                          fontSize: 12,
                          color: _mutedInk,
                          height: 1.45,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _fieldLabel('称呼'),
              TextField(
                controller: _nameCtrl,
                decoration: const InputDecoration(hintText: '如：张先生 / 王阿姨'),
              ),
              const SizedBox(height: 16),
              _fieldLabel('性别'),
              Wrap(
                spacing: 10,
                children: ['男', '女', '其他'].map((g) {
                  final active = _gender == g;
                  return ChoiceChip(
                    label: Text(g),
                    selected: active,
                    onSelected: (_) => setState(() => _gender = g),
                    selectedColor: AppColors.primaryTintWeak,
                    labelStyle: TextStyle(
                        color: active
                            ? AppColors.primaryStrong
                            : Colors.grey[600]),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              _fieldLabel('出生年份'),
              TextField(
                controller: _yearCtrl,
                keyboardType: TextInputType.number,
                maxLength: 4,
                decoration: const InputDecoration(
                  hintText: '如 1968',
                  counterText: '',
                ),
              ),
              const SizedBox(height: 16),
              _fieldLabel('疾病史（可多选）'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _commonDiseases.map((d) {
                  final active = _diseases.contains(d);
                  return FilterChip(
                    label: Text(d),
                    selected: active,
                    onSelected: (_) {
                      setState(() {
                        if (active) {
                          _diseases.remove(d);
                        } else {
                          _diseases.add(d);
                        }
                      });
                    },
                    selectedColor: AppColors.primaryTintWeak,
                    checkmarkColor: AppColors.primary,
                  );
                }).toList(),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _customDiseaseCtrl,
                decoration: const InputDecoration(hintText: '其它疾病（用顿号分隔，可留空）'),
              ),
              const SizedBox(height: 16),
              _fieldLabel('当前身体状况'),
              TextField(
                controller: _conditionCtrl,
                maxLines: 2,
                decoration: const InputDecoration(hintText: '如：近期感冒、术后恢复、备孕等'),
              ),
              const SizedBox(height: 16),
              _fieldLabel('过敏史 / 过敏药物'),
              TextField(
                controller: _allergyCtrl,
                decoration: const InputDecoration(hintText: '如：青霉素过敏（可留空）'),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saving ? null : _submit,
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                  child: Text(_saving ? '保存中…' : '保存档案'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _fieldLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
      );
}
