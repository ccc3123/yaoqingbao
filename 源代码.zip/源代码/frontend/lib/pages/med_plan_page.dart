import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/drug_item.dart';
import '../data/med_plan.dart';
import '../data/med_record.dart';
import '../util/calendar_service.dart';
import '../util/med_plan_service.dart';
import '../util/med_record_service.dart';
import '../widgets/design_icons.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 服药计划 + 服药记录页
///
/// 计划闹钟写入系统日历；服药记录联动药箱余量递减、更新最近服用时间。
class MedPlanPage extends StatefulWidget {
  final List<DrugItem> cabinetItems;

  const MedPlanPage({super.key, required this.cabinetItems});

  @override
  State<MedPlanPage> createState() => _MedPlanPageState();
}

class _MedPlanPageState extends State<MedPlanPage> {
  List<MedPlan> _plans = [];
  List<MedRecord> _records = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final plans = await MedPlanService.instance.list();
    final records = await MedRecordService.instance.list();
    if (!mounted) return;
    setState(() {
      _plans = plans;
      _records = records;
      _loading = false;
    });
  }

  /// 同步闹钟到系统日历（保存/删除/切换后调用）
  Future<void> _resyncCalendar() async {
    final updated = await CalendarService.instance.syncPlans(_plans);
    for (final p in updated) {
      await MedPlanService.instance.save(p);
    }
    setState(() => _plans = updated);
  }

  Future<void> _addPlan() async {
    final plan = await _showPlanEditor(null);
    if (plan == null) return;
    await MedPlanService.instance.save(plan);
    await _load();
    await _resyncCalendar();
  }

  Future<void> _editPlan(MedPlan plan) async {
    final edited = await _showPlanEditor(plan);
    if (edited == null) return;
    await MedPlanService.instance.save(edited);
    await _load();
    await _resyncCalendar();
  }

  Future<void> _deletePlan(MedPlan plan) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('删除计划'),
        content: Text('确认删除「${plan.medicineName}」的服药计划吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await MedPlanService.instance.delete(plan);
      await _load();
      await _resyncCalendar();
    }
  }

  Future<void> _togglePlan(MedPlan plan, bool enabled) async {
    final updated = plan.copyWith(enabled: enabled);
    await MedPlanService.instance.save(updated);
    await _load();
    await _resyncCalendar();
  }

  /// 记录一次服药
  Future<void> _recordDose() async {
    if (widget.cabinetItems.isEmpty) {
      _toast('药箱暂无药品，请先在药匣添加');
      return;
    }
    final result = await _showRecordDialog();
    if (result == null) return;
    final (medicineId, medicineName, dose, unit) = result;
    await MedRecordService.instance.record(
      medicineId: medicineId,
      medicineName: medicineName,
      dose: dose,
      unit: unit,
    );
    await _load();
    _toast('已记录，药箱余量已更新');
  }

  Future<MedPlan?> _showPlanEditor(MedPlan? existing) async {
    final nameCtrl = TextEditingController(text: existing?.medicineName ?? '');
    final doseCtrl = TextEditingController(text: existing?.dosage ?? '');
    final times = <String>[...(existing?.times ?? [])];
    const presets = ['07:00', '08:00', '12:00', '18:00', '20:00', '21:00'];

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.fromLTRB(
              20, 16, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2))),
              ),
              const SizedBox(height: 14),
              Text(existing == null ? '新建服药计划' : '编辑服药计划',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: '药品名称'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: doseCtrl,
                decoration: const InputDecoration(labelText: '剂量（如 1片 / 10ml）'),
              ),
              const SizedBox(height: 16),
              const Text('每日服药时间（可多选）',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: presets.map((t) {
                  final active = times.contains(t);
                  return FilterChip(
                    label: Text(t),
                    selected: active,
                    onSelected: (_) {
                      setSheetState(() {
                        if (active) {
                          times.remove(t);
                        } else {
                          times.add(t);
                        }
                      });
                    },
                    selectedColor: AppColors.primaryTintWeak,
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('取消'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: FilledButton.styleFrom(
                          backgroundColor: AppColors.primary),
                      child: const Text('保存'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (saved == true && nameCtrl.text.trim().isNotEmpty && times.isNotEmpty) {
      return MedPlan(
        id: existing?.id ?? 0,
        medicineName: nameCtrl.text.trim(),
        dosage: doseCtrl.text.trim(),
        times: times,
        startDate: existing?.startDate ?? '',
        endDate: existing?.endDate ?? '',
        enabled: existing?.enabled ?? true,
        calendarEventIds: existing?.calendarEventIds ?? const [],
      );
    }
    if (saved == true && (nameCtrl.text.trim().isEmpty || times.isEmpty)) {
      _toast('请填写药品名称并选择时间');
    }
    return null;
  }

  /// 返回 (medicineId, medicineName, dose, unit)
  Future<(String, String, double, String)?> _showRecordDialog() async {
    DrugItem? selected = widget.cabinetItems.first;
    final doseCtrl = TextEditingController(text: '1');
    final unitCtrl = TextEditingController(text: selected.unit.isNotEmpty ? selected.unit : '片');

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: EdgeInsets.fromLTRB(
              20, 16, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2))),
              ),
              const SizedBox(height: 14),
              const Text('记录服药',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              DropdownButtonFormField<DrugItem>(
                initialValue: selected,
                items: widget.cabinetItems
                    .map((e) => DropdownMenuItem(
                          value: e,
                          child: Text(e.medicineName,
                              overflow: TextOverflow.ellipsis),
                        ))
                    .toList(),
                onChanged: (v) {
                  setSheetState(() {
                    selected = v;
                    if (v != null && v.unit.isNotEmpty) {
                      unitCtrl.text = v.unit;
                    }
                  });
                },
                decoration: const InputDecoration(labelText: '选择药品'),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: doseCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: '本次剂量'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  SizedBox(
                    width: 90,
                    child: TextField(
                      controller: unitCtrl,
                      decoration: const InputDecoration(labelText: '单位'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('取消'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      style: FilledButton.styleFrom(
                          backgroundColor: AppColors.primary),
                      child: const Text('确认服药'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );

    if (saved == true && selected != null) {
      final dose = double.tryParse(doseCtrl.text.trim()) ?? 0;
      if (dose <= 0) {
        _toast('请输入有效剂量');
        return null;
      }
      return (selected!.medicineId, selected!.medicineName, dose, unitCtrl.text.trim());
    }
    return null;
  }

  void _toast(String msg) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    messenger?.showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('服药计划'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 40),
                children: [
                  _sectionHeader('服药计划', '闹钟已同步到系统日历'),
                  if (_plans.isEmpty)
                    _emptyHint('还没有服药计划，点下方按钮新建')
                  else
                    ..._plans.map((p) => _planCard(p)),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _addPlan,
                    icon: DesignIcons.add(size: 18, color: AppColors.primary),
                    label: const Text('新建计划'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.primary,
                      side: const BorderSide(color: AppColors.primary),
                    ),
                  ),
                  const SizedBox(height: 24),
                  _sectionHeader('服药记录', '每次服药自动更新药箱余量'),
                  FilledButton.icon(
                    onPressed: _recordDose,
                    icon: DesignIcons.medication(size: 18, color: Colors.white),
                    label: const Text('记录一次服药'),
                    style: FilledButton.styleFrom(
                        backgroundColor: AppColors.primary),
                  ),
                  const SizedBox(height: 8),
                  if (_records.isEmpty)
                    _emptyHint('暂无服药记录')
                  else
                    ..._records.take(30).map(_recordTile),
                ],
              ),
            ),
    );
  }

  Widget _sectionHeader(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Container(width: 3, height: 16, color: AppColors.primary),
          const SizedBox(width: 8),
          Text(title,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(subtitle,
                style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted),
                overflow: TextOverflow.ellipsis),
          ),
        ],
      ),
    );
  }

  Widget _planCard(MedPlan p) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 6)],
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.primaryTintWeak,
              borderRadius: BorderRadius.circular(12),
            ),
            child: DesignIcons.medication(size: 20, color: AppColors.primary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.medicineName,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w600)),
                if (p.dosage.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(p.dosage,
                      style: const TextStyle(fontSize: 12, color: AppColors.muted)),
                ],
                const SizedBox(height: 4),
                Text('每日 ${p.timesLabel}',
                    style: const TextStyle(fontSize: 12, color: AppColors.primary)),
              ],
            ),
          ),
          Switch(
            value: p.enabled,
            activeThumbColor: AppColors.primary,
            onChanged: (v) => _togglePlan(p, v),
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'edit') _editPlan(p);
              if (v == 'delete') _deletePlan(p);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: Text('编辑')),
              PopupMenuItem(value: 'delete', child: Text('删除')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _recordTile(MedRecord r) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.divider),
      ),
      child: Row(
        children: [
          const Icon(Icons.check_circle_outline, size: 18, color: AppColors.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${r.medicineName}  ${r.dose}${r.unit}',
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(r.takenAt,
                    style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
              ],
            ),
          ),
          if (r.memberName.isNotEmpty)
            Text(r.memberName,
                style: const TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
        ],
      ),
    );
  }

  Widget _emptyHint(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: Text(text,
            style: const TextStyle(fontSize: 13, color: AppColors.muted)),
      ),
    );
  }
}
