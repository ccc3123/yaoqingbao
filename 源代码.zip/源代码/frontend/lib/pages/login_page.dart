import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../util/auth_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 账号登录页 —— 手机号验证码登录（混合双入口的「账号」一侧）
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  static const _ink = AppColors.ink;
  static const _mutedInk = AppColors.ink3;
  static const _accent = AppColors.primary;

  final _formKey = GlobalKey<FormState>();
  final _phoneCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  bool _sending = false;
  bool _logging = false;
  int _cooldown = 0;
  String? _demoCode;

  @override
  void dispose() {
    _phoneCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendCode() async {
    final phone = _phoneCtrl.text.trim();
    if (!RegExp(r'^1\d{10}$').hasMatch(phone)) {
      _toast('请输入正确的手机号');
      return;
    }
    if (_cooldown > 0) return;
    HapticFeedback.lightImpact();
    setState(() => _sending = true);
    final code = await AuthService.instance.sendCode(phone);
    if (!mounted) return;
    setState(() {
      _sending = false;
      _demoCode = code;
      if (code != null) _codeCtrl.text = code; // 演示模式自动填充
      _cooldown = code == null ? 0 : 60;
    });
    if (code != null) {
      _startCooldown();
    }
    _toast(code != null ? '验证码已发送' : '发送失败，请检查网络');
  }

  Future<void> _startCooldown() async {
    while (mounted && _cooldown > 0) {
      await Future<void>.delayed(const Duration(seconds: 1));
      if (!mounted) return;
      setState(() => _cooldown--);
    }
  }

  Future<void> _login() async {
    final phone = _phoneCtrl.text.trim();
    final code = _codeCtrl.text.trim();
    if (phone.isEmpty || code.isEmpty) {
      _toast('请输入手机号和验证码');
      return;
    }
    HapticFeedback.mediumImpact();
    setState(() => _logging = true);
    final ok = await AuthService.instance.login(phone, code);
    if (!mounted) return;
    setState(() => _logging = false);
    if (ok) {
      _toast('登录成功');
      Navigator.pop(context, true);
    } else {
      _toast(AuthService.instance.lastError);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.maybeOf(
      context,
    )?.showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('账号登录'),
        backgroundColor: AppColors.surface,
        foregroundColor: _ink,
        titleTextStyle: const TextStyle(
          color: _ink,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 8),
              const Text(
                '登录后可创建/加入家庭，与家人共享药箱',
                style: TextStyle(
                  fontSize: 13,
                  color: _mutedInk,
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _phoneCtrl,
                keyboardType: TextInputType.phone,
                maxLength: 11,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: const TextStyle(color: _ink, fontSize: 16),
                cursorColor: _accent,
                decoration: const InputDecoration(
                  labelText: '手机号',
                  labelStyle: TextStyle(color: _mutedInk),
                  floatingLabelStyle: TextStyle(color: _accent),
                  hintStyle: TextStyle(color: _mutedInk),
                  prefixIcon: Icon(Icons.phone_iphone, color: _mutedInk),
                  counterText: '',
                ),
                validator: (v) =>
                    RegExp(r'^1\d{10}$').hasMatch((v ?? '').trim())
                        ? null
                        : '请输入 11 位手机号',
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _codeCtrl,
                      keyboardType: TextInputType.number,
                      maxLength: 6,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      style: const TextStyle(color: _ink, fontSize: 16),
                      cursorColor: _accent,
                      decoration: const InputDecoration(
                        labelText: '验证码',
                        labelStyle: TextStyle(color: _mutedInk),
                        floatingLabelStyle: TextStyle(color: _accent),
                        hintStyle: TextStyle(color: _mutedInk),
                        counterText: '',
                      ),
                      validator: (v) =>
                          RegExp(r'^\d{6}$').hasMatch((v ?? '').trim())
                              ? null
                              : '请输入 6 位验证码',
                    ),
                  ),
                  const SizedBox(width: 12),
                  SizedBox(
                    height: 52,
                    child: OutlinedButton(
                      onPressed: _sending || _cooldown > 0 ? null : _sendCode,
                      child: Text(
                        _sending
                            ? '发送中…'
                            : (_cooldown > 0 ? '${_cooldown}s 后重试' : '获取验证码'),
                      ),
                    ),
                  ),
                ],
              ),
              if (_demoCode != null) ...[
                const SizedBox(height: 4),
                const Text(
                  '演示模式：验证码已自动填充',
                  style: TextStyle(
                    fontSize: AppText.sizeCaption,
                    color: _mutedInk,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _logging
                    ? null
                    : () {
                        if (_formKey.currentState?.validate() ?? false)
                          _login();
                      },
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: Text(_logging ? '登录中…' : '登录'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
