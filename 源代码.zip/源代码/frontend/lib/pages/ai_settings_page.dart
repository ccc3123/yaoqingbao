import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../util/ai_client.dart';
import '../theme/app_colors.dart';

/// AI 接口设置页 —— 可配置 OpenAI 兼容模型。
///
/// 填 baseUrl + apiKey + model 即可自动连接智谱 GLM / DeepSeek / OpenAI / Ollama 等。
class AiSettingsPage extends StatefulWidget {
  const AiSettingsPage({super.key});

  @override
  State<AiSettingsPage> createState() => _AiSettingsPageState();
}

class _AiSettingsPageState extends State<AiSettingsPage> {
  final _baseCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  bool _enabled = true;
  bool _testing = false;
  String? _testResult;
  bool _testOk = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await AiClient.instance.loadConfig();
    if (!mounted) return;
    setState(() {
      _baseCtrl.text = c.baseUrl;
      _keyCtrl.text = c.apiKey;
      _modelCtrl.text = c.model;
      _enabled = c.enabled;
    });
  }

  @override
  void dispose() {
    _baseCtrl.dispose();
    _keyCtrl.dispose();
    _modelCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    HapticFeedback.mediumImpact();
    await AiClient.instance.saveConfig(AiConfig(
      baseUrl: _baseCtrl.text.trim(),
      apiKey: _keyCtrl.text.trim(),
      model: _modelCtrl.text.trim(),
      enabled: _enabled,
    ));
    _toast('已保存');
  }

  Future<void> _test() async {
    HapticFeedback.lightImpact();
    setState(() {
      _testing = true;
      _testResult = null;
    });
    final ok = await AiClient.instance.test();
    if (!mounted) return;
    setState(() {
      _testing = false;
      _testOk = ok;
      _testResult = ok ? '连接成功，模型可用' : '连接失败，请检查 baseUrl / Key / 模型名';
    });
  }

  void _toast(String msg) {
    ScaffoldMessenger.maybeOf(context)
        ?.showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI 接口设置')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '接入任意 OpenAI 兼容大模型',
              style: TextStyle(fontSize: 13, color: AppColors.muted),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _baseCtrl,
              decoration: const InputDecoration(
                labelText: 'Base URL',
                hintText: 'https://open.bigmodel.cn/api/paas/v4',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _keyCtrl,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'API Key',
                hintText: '你的密钥',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _modelCtrl,
              decoration: const InputDecoration(
                labelText: '模型名',
                hintText: 'glm-4-flash / deepseek-chat / gpt-4o-mini',
              ),
            ),
            const SizedBox(height: 12),
            SwitchListTile(
              value: _enabled,
              onChanged: (v) => setState(() => _enabled = v),
              title: const Text('启用 AI'),
              contentPadding: EdgeInsets.zero,
            ),
            const SizedBox(height: 16),
            if (_testResult != null)
              Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _testOk ? AppColors.primaryTintWeak : AppColors.dangerTint,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Icon(
                      _testOk ? Icons.check_circle : Icons.error_outline,
                      size: 18,
                      color: _testOk ? AppColors.primary : AppColors.danger,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(_testResult!,
                          style: const TextStyle(fontSize: 13)),
                    ),
                  ],
                ),
              ),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _testing ? null : _test,
                    icon: _testing
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : const Icon(Icons.wifi_tethering, size: 18),
                    label: Text(_testing ? '测试中…' : '测试连通'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: _save,
                    style: FilledButton.styleFrom(
                        backgroundColor: AppColors.primary),
                    child: const Text('保存'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text(
              '提示：默认已接入智谱 GLM，开箱即用；切换其它模型时请确认对方兼容 OpenAI 协议。',
              style: TextStyle(fontSize: 12, color: AppColors.muted, height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}
