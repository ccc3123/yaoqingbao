import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../util/http_utils.dart';
import '../util/scanner.dart';
import '../util/zhipu_service.dart';
import '../util/drug_db.dart';
import '../util/vision_service.dart';
import '../data/medicine.dart';
import '../routes/app_routes.dart';
import '../routes/home_page.dart';
import '../widgets/design_icons.dart';
import '../widgets/app_background.dart';
import '../widgets/source_badge.dart';
import '../util/speech_service.dart';
import '../util/fuzzy_drug_matcher.dart';
import '../util/tts_service.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 寻源 — 扫码识药 + 关键词搜索 + AI 降级识别
class XunYuanPage extends StatefulWidget {
  const XunYuanPage({super.key});
  @override
  State<XunYuanPage> createState() => _XunYuanPageState();
}

class _XunYuanPageState extends State<XunYuanPage>
    with SingleTickerProviderStateMixin {
  final _searchCtrl = TextEditingController();
  Medicine? _medicine;
  bool _loading = false;
  bool _aiLoading = false;
  String? _error;
  /// 降级提示：接口超时 / 不可用 / 无结果时展示，不抛异常也不打断用户
  String? _notice;
  late final AnimationController _pulseCtrl;
  List<String> _history = [];
  static const _histKey = 'yaoqingbao_search_history';
  static const _maxHist = 10;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000));
    _pulseCtrl.repeat(reverse: true);
    _loadHistory();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final s = prefs.getString(_histKey);
    if (s != null) setState(() => _history = List<String>.from(jsonDecode(s)));
  }

  Future<void> _saveHistory(String kw) async {
    _history.remove(kw);
    _history.insert(0, kw);
    if (_history.length > _maxHist) _history = _history.sublist(0, _maxHist);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_histKey, jsonEncode(_history));
    setState(() {});
  }

  Future<void> _clearHistory() async {
    HapticFeedback.selectionClick();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_histKey);
    setState(() => _history = []);
  }

  Future<void> _scan() async {
    HapticFeedback.mediumImpact();
    setState(() {
      _loading = true;
      _error = null;
      _notice = null;
      _medicine = null;
      _aiLoading = false;
    });
    final code = await Scanner.scanBarcode();
    if (code.isEmpty) {
      setState(() {
        _loading = false;
        _error = '扫描已取消';
      });
      return;
    }
    await _lookup(code);
  }

  /// 识别降级链（由快到慢、由离线到联网）：
  ///   L0 离线条码库  本地 SQLite，开源数据随包下发，无需网络，<50ms
  ///   L1 后端接口     团队服务端，当前不可用，保留兼容
  ///   L2 AI 文本兜底  智谱 glm-4-flash
  /// 任何一级失败都转成可展示的文案，绝不向上抛异常。
  Future<void> _lookup(String code) async {
    // L0：离线条码库。命中最快且断网可用，优先于一切网络请求。
    final local = await DrugDb.instance.lookupByBarcode(code);
    if (!mounted) return;
    if (local != null) {
      _saveHistory(local.drugName);
      setState(() {
        _medicine = local;
        _loading = false;
        _notice = null;
        _error = null;
      });
      return;
    }

    // L1：后端接口
    try {
      final resp = await HttpUtils()
          .post('/med/CodeSearch?code=$code')
          .timeout(const Duration(seconds: 6));
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] != null) {
        final med = Medicine.fromJson(Map<String, dynamic>.from(body['data'] as Map));
        _saveHistory(med.drugName);
        if (!mounted) return;
        setState(() {
          _medicine = med;
          _loading = false;
          _notice = null;
          _error = null;
        });
        return;
      }
      // 接口不可用或无结果：把后端给出的原因作为降级提示，再交给 AI 兜底
      final msg = (body is Map ? body['msg'] : null)?.toString();
      _tryAILookup(code, notice: (msg != null && msg.isNotEmpty) ? msg : '药品查询服务暂时不可用，已切换智能识别');
    } catch (e) {
      // 精确区分：无网/超时/服务端故障，不再一律显示「网络异常」误导用户
      _tryAILookup(code, notice: '${HttpUtils.describeError(e)}，已切换智能识别');
    }
  }

  /// AI 降级：根据条码查询
  Future<void> _tryAILookup(String code, {String? notice}) async {
    setState(() { _loading = false; _aiLoading = true; _error = null; _notice = notice; });
    final result = await ZhipuService().lookupByCode(code);
    if (!mounted) return;
    if (result != null && (result['drugName'] ?? '').toString().isNotEmpty) {
      final med = Medicine.fromJson(result);
      _saveHistory(med.drugName);
      setState(() { _medicine = med; _aiLoading = false; _notice = null; });
    } else {
      setState(() { _aiLoading = false; _error = '条码未识别，请尝试搜索药品名称'; });
    }
  }

  /// AI 拍照识药：选图 → 视觉模型读包装 → 用药名回查离线条码库补全官方说明书。
  ///
  /// [useCamera] 传 false 走相册，供模拟器/无相机设备与演示使用。
  Future<void> _recognizeByPhoto({bool useCamera = true}) async {
    HapticFeedback.mediumImpact();
    setState(() {
      _loading = false;
      _aiLoading = true;
      _error = null;
      _notice = null;
      _medicine = null;
    });
    try {
      final res = await VisionService().recognize(useCamera: useCamera);
      if (!mounted) return;
      _saveHistory(res.medicine.drugName);
      setState(() {
        _medicine = res.medicine;
        _aiLoading = false;
        // 没回查到官方库时必须如实说明，不能让用户以为说明书内容是权威来源
        _notice = res.fromOfficialDb
            ? '拍照识别成功，说明书内容来自官方药品数据库'
            : '已识别到药品，但本地库未收录该品种，说明书内容暂缺（不会由 AI 生成）';
      });
    } on VisionException catch (e) {
      if (!mounted) return;
      // 取消是正常路径，不该用红色错误吓用户，这里只静默收尾
      setState(() {
        _aiLoading = false;
        _error = e.reason == VisionFailure.cancelled ? null : e.message;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _aiLoading = false;
        _error = '拍照识别失败，请改用扫码或搜索药名';
      });
    }
  }

  /// 语音识药：录音 → 智谱 ASR 转文字 → 本地模糊匹配药名。
  ///
  /// 固定录音 3 秒后自动停止并识别；识别文字回填搜索框方便用户核对，
  /// 模糊匹配失败时降级提示改用文字搜索，绝不崩。
  Future<void> _recognizeByVoice() async {
    HapticFeedback.mediumImpact();
    if (_aiLoading) return;
    final speech = SpeechService();
    setState(() {
      _aiLoading = true;
      _error = null;
      _notice = null;
      _medicine = null;
    });
    try {
      await speech.start();
    } on SpeechException {
      if (!mounted) return;
      setState(() {
        _aiLoading = false;
        _error = '需要麦克风权限才能语音识别，请改用文字搜索或拍照识药';
      });
      return;
    }
    // 固定录音时长，让用户一次性说完药名
    await Future.delayed(const Duration(seconds: 3));
    final text = await speech.stopAndRecognize();
    if (!mounted) return;
    if (text == null || text.isEmpty) {
      setState(() {
        _aiLoading = false;
        _error = '没有听清，请靠近麦克风重试，或改用文字搜索';
      });
      return;
    }
    _searchCtrl.text = text;
    final matches = await FuzzyDrugMatcher.instance.match(text, limit: 5);
    if (!mounted) return;
    if (matches.isEmpty) {
      setState(() {
        _aiLoading = false;
        _error = '没有匹配到「$text」相关药品，可点击搜索尝试 AI 查询';
      });
      return;
    }
    final top = matches.first.medicine;
    _saveHistory(top.drugName);
    setState(() {
      _medicine = top;
      _aiLoading = false;
      _notice = '语音识别「$text」，已匹配 ${matches.length} 个候选，展示最接近的药品';
    });
  }

  /// AI 降级：关键词搜索
  Future<void> _tryAISearch(String keyword) async {
    HapticFeedback.selectionClick();
    setState(() { _aiLoading = true; _error = null; _notice = null; _medicine = null; });
    final result = await ZhipuService().searchDrugByName(keyword);
    if (!mounted) return;
    if (result != null && (result['drugName'] ?? '').toString().isNotEmpty) {
      final med = Medicine.fromJson(result);
      _saveHistory(keyword);
      setState(() { _medicine = med; _aiLoading = false; });
    } else {
      setState(() { _aiLoading = false; _error = '未找到「$keyword」相关信息'; });
    }
  }

  void _goSearch(String kw) {
    if (kw.trim().isNotEmpty) {
      HapticFeedback.lightImpact();
      _saveHistory(kw.trim());
      AppRoutes.toSearch(context, kw.trim());
    }
  }

  void _showDetail(Medicine m) {
    HapticFeedback.lightImpact();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _DetailSheet(medicine: m),
    );
  }

  void _goMap() {
    HapticFeedback.selectionClick();
    HomePage.homeKey.currentState?.switchToTab(2);
  }

  @override
  Widget build(BuildContext context) {
    return AppBackground(
      overlayColor: Colors.white,
      overlayOpacity: 0.18,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        child: Column(children: [
          // ── 品牌头 ──
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.primaryStrong, AppColors.primary],
                begin: Alignment.topLeft,
              ),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
            ),
            child: Column(children: [
              Row(children: [
                DesignIcons.eco(size: 26, color: Colors.white),
                const SizedBox(width: 10),
                const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('药清宝', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                    Text('让每一粒药都有归处', style: TextStyle(color: Colors.white60, fontSize: 12)),
                  ],
                ),
              ]),
              const SizedBox(height: 18),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.15), blurRadius: 10)],
                ),
                child: TextField(
                  controller: _searchCtrl,
                  style: const TextStyle(fontSize: 15),
                  decoration: InputDecoration(
                    hintText: '输入药品名称 / 症状 / 病症搜索',
                    hintStyle: TextStyle(color: AppColors.muted),
                    prefixIcon: DesignIcons.search(size: 20, color: AppColors.primary),
                    suffixIcon: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.mic, size: 20, color: AppColors.primary),
                          tooltip: '语音识别药名',
                          onPressed: _aiLoading ? null : _recognizeByVoice,
                        ),
                        IconButton(
                          icon: DesignIcons.arrowForward(size: 16),
                          onPressed: () => _goSearch(_searchCtrl.text),
                        ),
                      ],
                    ),
                    filled: true, fillColor: Colors.white,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                  ),
                  textInputAction: TextInputAction.search,
                  onSubmitted: _goSearch,
                ),
              ),
            ]),
          ),

          const SizedBox(height: 20),

          // ── 搜索历史 ──
          if (_history.isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(children: [
                const Text('最近搜索', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.ink)),
                const Spacer(),
                GestureDetector(
                  onTap: _clearHistory,
                  child: const Text('清除', style: TextStyle(fontSize: 13, color: AppColors.muted)),
                ),
              ]),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(
                spacing: 8, runSpacing: 8,
                children: _history.map((kw) => ActionChip(
                  avatar: DesignIcons.history(size: 14, color: AppColors.primary),
                  label: Text(kw, style: const TextStyle(fontSize: 13, color: AppColors.primaryStrong, fontWeight: FontWeight.w500)),
                  backgroundColor: AppColors.primaryTintWeak,
                  side: const BorderSide(color: AppColors.primaryTint),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  onPressed: () {
                    HapticFeedback.selectionClick();
                    _goSearch(kw);
                  },
                )).toList(),
              ),
            ),
            const SizedBox(height: 16),
          ],

          // ── 核心操作区：扫码 与 AI 拍照识药 并列同级 ──
          // 扫码命中离线库最快，但磨损条码/进口药/无码包装扫不出；
          // 拍照识药是并列的第二条路，做成同尺寸主按钮而不是附属小标签。
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildScanButton(),
              const SizedBox(width: 26),
              _buildPhotoButton(),
            ],
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text('扫描药盒条码\n自动识别药品',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.ink3, fontSize: 12, height: 1.4)),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text('条码扫不出时\nAI 直接读包装',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.ink3, fontSize: 12, height: 1.4)),
                ),
              ],
            ),
          ),

          const SizedBox(height: 10),

          // 拍照之外的补充入口：已有药盒照片时可直接从相册选
          Center(
            child: _photoChip(
                '从相册选图',
                DesignIcons.autoAwesome(size: 15, color: AppSemantic.ai),
                () => _recognizeByPhoto(useCamera: false)),
          ),

          const SizedBox(height: 24),

          // ── AI 加载中 ──
          if (_aiLoading)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Column(children: [
                CircularProgressIndicator(color: AppSemantic.ai),
                SizedBox(height: 12),
                Text('AI 智能识别中...', style: TextStyle(color: AppColors.ink3)),
              ]),
            ),

          // ── 后端加载中 ──
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Column(children: [
                CircularProgressIndicator(color: AppColors.primary),
                SizedBox(height: 12),
                Text('正在识别药品...', style: TextStyle(color: AppColors.ink3)),
              ]),
            ),

          // ── 降级提示 ──
          if (_notice != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    color: AppColors.primaryTintWeak,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.primaryTint)),
                child: Row(children: [
                  DesignIcons.info(size: 18, color: AppColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                      child: Text(_notice!,
                          style: const TextStyle(color: AppColors.primaryStrong, fontSize: 13))),
                ]),
              ),
            ),

          const SizedBox(height: 12),

          // ── 错误提示 + AI 按钮 ──
          if (_error != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                    color: AppColors.warningTint,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.warningTint)),
                child: Column(children: [
                  Row(children: [
                    DesignIcons.info(size: 18, color: AppColors.warning),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_error!, style: const TextStyle(color: AppColors.warning, fontSize: 14))),
                  ]),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        final kw = _searchCtrl.text.isNotEmpty ? _searchCtrl.text : '';
                        if (kw.isNotEmpty) _tryAISearch(kw);
                      },
                      icon: DesignIcons.autoAwesome(size: 16, color: AppSemantic.ai),
                      label: const Text('AI 智能查询', style: TextStyle(color: AppSemantic.ai)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppSemantic.ai),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ]),
              ),
            ),

          if (_medicine != null) ...[
            const SizedBox(height: 8),
            _medicineCard(_medicine!),
          ],

          // ── 知识贴士 ──
          const SizedBox(height: 20),
          _knowledgeCards(),

          // ── 免责声明 ──
          Container(
            margin: const EdgeInsets.fromLTRB(20, 16, 20, 32),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(children: [
              DesignIcons.info(size: 16, color: AppColors.ink3),
              const SizedBox(width: 8),
              Expanded(
                child: Text('本App仅提供信息查询和回收点指引\n不参与任何药品交易，回收请前往线下正规机构',
                    style: TextStyle(fontSize: AppText.sizeCaption, color: AppColors.muted)),
              ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _buildScanButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, child) {
        final scale = 1.0 + _pulseCtrl.value * 0.03;
        return GestureDetector(
          onTap: _scan,
          child: SizedBox(
            width: 104,
            child: Column(children: [
            Transform.scale(
              scale: scale,
              child: Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const SweepGradient(
                    colors: [AppColors.primaryLight, AppColors.primary, AppColors.primaryStrong, AppColors.primaryLight],
                  ),
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.primary.withValues(alpha: 0.3),
                        blurRadius: 16,
                        offset: const Offset(0, 4)),
                  ],
                ),
                child: Container(
                  margin: const EdgeInsets.all(3),
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.primaryDark,
                  ),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.primaryLight.withValues(alpha: 0.6), width: 2),
                    ),
                    child: DesignIcons.camera(
                        size: 28, color: AppColors.primaryPale),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text('扫一扫',
                style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: AppColors.primaryStrong)),
          ]),
          ),
        );
      },
    );
  }

  /// AI 拍照识药主按钮。与扫码按钮同尺寸并列，配紫蓝渐变 + AI 角标以示区分：
  /// 绿色 = 确定性路径（条码命中官方库），紫色 = 概率性路径（模型读包装）。
  Widget _buildPhotoButton() {
    return AnimatedBuilder(
      animation: _pulseCtrl,
      builder: (_, __) {
        // 与扫码按钮反相呼吸：两者交替缩放，不会同时抢视觉焦点
        final scale = 1.0 + (1.0 - _pulseCtrl.value) * 0.03;
        return GestureDetector(
          onTap: _aiLoading ? null : () => _recognizeByPhoto(useCamera: true),
          child: Opacity(
            opacity: _aiLoading ? 0.5 : 1,
            child: SizedBox(
              width: 104,
              child: Column(children: [
                Transform.scale(
                  scale: scale,
                  child: Container(
                    width: 88,
                    height: 88,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const SweepGradient(colors: [
                        AppSemantic.ai,
                        AppSemantic.ai,
                        AppSemantic.aiStrong,
                        AppSemantic.ai,
                      ]),
                      boxShadow: [
                        BoxShadow(
                            color: AppSemantic.ai.withValues(alpha: 0.35),
                            blurRadius: 18,
                            offset: const Offset(0, 5)),
                      ],
                    ),
                    child: Container(
                      margin: const EdgeInsets.all(3),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppSemantic.aiStrong,
                      ),
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            margin: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: AppSemantic.ai.withValues(alpha: 0.6),
                                  width: 2),
                            ),
                            child: DesignIcons.camera(
                                size: 26, color: AppSemantic.aiTint),
                          ),
                          Positioned(
                            right: 4,
                            top: 8,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 5, vertical: 1),
                              decoration: BoxDecoration(
                                color: AppColors.warning,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Text('AI',
                                  style: TextStyle(
                                      fontSize: AppText.sizeCaption,
                                      fontWeight: FontWeight.w800,
                                      color: Colors.white,
                                      height: 1.2)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                const Text('AI 拍照识药',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppSemantic.aiStrong)),
              ]),
            ),
          ),
        );
      },
    );
  }

  Widget _photoChip(String label, Widget icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: _aiLoading ? null : onTap,
      child: Opacity(
        opacity: _aiLoading ? 0.5 : 1,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [AppColors.primaryTintWeak, AppColors.subtleBg]),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppSemantic.aiTint),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            icon,
            const SizedBox(width: 6),
            Text(label,
                style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppSemantic.aiStrong)),
          ]),
        ),
      ),
    );
  }

  Widget _medicineCard(Medicine m) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => _showDetail(m),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [AppColors.primaryLight, AppColors.primary]),
                      borderRadius: BorderRadius.circular(14)),
                  child: DesignIcons.medication(size: 26, color: Colors.white),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(m.drugName, style: const TextStyle(fontSize: AppText.sizeTitle, fontWeight: FontWeight.w700)),
                    if (m.manu.isNotEmpty)
                      Text(m.manu, style: TextStyle(color: AppColors.ink3, fontSize: 13)),
                    const SizedBox(height: 6),
                    // 来源必须显式标注：用户要能一眼分辨官方原文与 AI 推断
                    SourceBadge(source: m.source, compact: true),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      color: AppColors.primaryTintWeak, borderRadius: BorderRadius.circular(20)),
                  child: const Text('详情 →', style: TextStyle(color: AppColors.primary, fontSize: 12)),
                ),
              ]),
              const SizedBox(height: 14),
              // 没有官方说明书时明确告知，而不是让 AI 补一段
              if (!m.hasOfficialInstruction) ...[
                SourceDisclaimer(medicine: m),
                const SizedBox(height: 12),
              ],
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _goMap,
                  icon: DesignIcons.locationOutlined(size: 18),
                  label: const Text('查看附近回收点'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.primary,
                    side: const BorderSide(color: AppColors.primaryTint),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _knowledgeCards() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('你知道吗', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        SizedBox(
          height: 110,
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _kc('过期药品\n属于危险废物', Icons.warning_amber_rounded, AppColors.warningTint, AppColors.warning),
              const SizedBox(width: 12),
              _kc('全国 131 家药店\n参与公益回收', Icons.recycling, AppColors.primaryTintWeak, AppColors.primary),
              const SizedBox(width: 12),
              _kc('一粒药可污染\n数万吨水源', Icons.water_drop, AppColors.infoTint, AppColors.info),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _kc(String text, IconData icon, Color bg, Color accent) => Container(
    width: 160,
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(16)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, size: 22, color: accent),
      const Spacer(),
      Text(text, style: TextStyle(fontSize: 12, color: accent, height: 1.4)),
    ]),
  );
}

// ── 药品详情 BottomSheet ──
class _DetailSheet extends StatelessWidget {
  final Medicine medicine;
  const _DetailSheet({required this.medicine});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
                width: 44, height: 5,
                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(3))),
          ),
          const SizedBox(height: 20),
          Row(children: [
            Container(
              width: 56, height: 56,
              decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [AppColors.primaryLight, AppColors.primaryStrong]),
                  borderRadius: BorderRadius.circular(16)),
              child: DesignIcons.medication(size: 28, color: Colors.white),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(medicine.drugName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                if (medicine.manu.isNotEmpty)
                  Text(medicine.manu, style: TextStyle(color: AppColors.ink3, fontSize: 14)),
              ]),
            ),
          ]),
          const SizedBox(height: 10),
          SourceBadge(source: medicine.source),
          const SizedBox(height: 12),
          Row(children: [
            if (medicine.type.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: AppColors.primaryTintWeak, borderRadius: BorderRadius.circular(20)),
                child: Text(medicine.type, style: const TextStyle(fontSize: 12, color: AppColors.primary)),
              ),
            if (medicine.pzwh.isNotEmpty) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(20)),
                child: Text(medicine.pzwh, style: TextStyle(fontSize: AppText.sizeCaption, color: Colors.grey[600])),
              ),
            ],
          ]),
          const SizedBox(height: 16),
          // 没有官方说明书时先摆免责说明，再展示已有的识别字段
          if (!medicine.hasOfficialInstruction) ...[
            SourceDisclaimer(medicine: medicine),
            const SizedBox(height: 14),
          ],
          _sec('功能主治', medicine.syz),
          _sec('禁忌', medicine.jj),
          _sec('用法用量', medicine.usage),
          _sec('主要成份', medicine.component),
          _sec('有效期', medicine.yxq),
          _sec('贮藏', medicine.zc),
          const SizedBox(height: 16),
          // 朗读说明书：只朗读官方原文，服务老年用户；无官方原文时隐藏
          if (medicine.hasOfficialInstruction)
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  final parts = [
                    if (medicine.syz.isNotEmpty) '功能主治：${medicine.syz}',
                    if (medicine.usage.isNotEmpty) '用法用量：${medicine.usage}',
                    if (medicine.jj.isNotEmpty) '禁忌：${medicine.jj}',
                    if (medicine.component.isNotEmpty) '主要成分：${medicine.component}',
                    if (medicine.zc.isNotEmpty) '贮藏：${medicine.zc}',
                  ];
                  TtsService.instance
                      .speak('${medicine.drugName}。${parts.join('。')}');
                },
                icon: const Icon(Icons.volume_up, size: 18),
                label: const Text('朗读说明书'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primary,
                  side: const BorderSide(color: AppColors.primaryTint),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
            ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () {
                Navigator.pop(context);
                HomePage.homeKey.currentState?.switchToTab(2);
              },
              icon: DesignIcons.location(size: 18),
              label: const Text('去附近回收点'),
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.primary,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _sec(String label, String content) {
    if (content.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: AppColors.subtleBg, borderRadius: BorderRadius.circular(12)),
          child: Text(content, style: const TextStyle(fontSize: 14, color: AppColors.ink3, height: 1.6)),
        ),
      ]),
    );
  }
}
