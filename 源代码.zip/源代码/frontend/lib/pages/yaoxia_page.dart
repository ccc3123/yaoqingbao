import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import '../data/drug_item.dart';
import '../data/med_record.dart';
import '../data/user_profile.dart';
import '../util/device_utils.dart';
import '../util/http_utils.dart';
import '../util/med_box_store.dart';
import '../util/med_record_service.dart';
import '../util/profile_service.dart';
import '../util/reminder_service.dart';
import '../routes/home_page.dart';
import 'guichu_page.dart';
import '../util/expiry_rule.dart';
import '../util/zhipu_service.dart';
import '../widgets/design_icons.dart';
import '../widgets/app_background.dart';
import '../widgets/medicine_safety.dart';
import '../widgets/med_assistant.dart';
import '../util/recycle_planner.dart';
import '../routes/app_routes.dart';
import '../theme/app_colors.dart';
import '../theme/app_dimens.dart';
import '../theme/app_text.dart';

/// 药匣 — 家庭药箱管理 + 到期提醒 + 回收记录删除（单条/批量）
class YaoXiaPage extends StatefulWidget {
  const YaoXiaPage({super.key});
  @override
  State<YaoXiaPage> createState() => _YaoXiaPageState();
}

class _YaoXiaPageState extends State<YaoXiaPage> {
  List<DrugItem> _items = [];
  String _filter = 'all';

  /// AI 服药助理所需的健康档案与服药记录
  UserProfile _profile = UserProfile();
  List<MedRecord> _records = [];

  /// 多选模式：进入后列表项左侧出现勾选圈，可全选后批量删除
  bool _selectMode = false;
  final Set<String> _selected = {};

  /// 删除请求进行中，避免重复点击导致并发删除
  bool _deleting = false;

  @override
  void initState() {
    super.initState();
    _loadItems();
    _loadProfileAndRecords();
    MedBoxStore.revision.addListener(_onBoxChanged);
  }

  @override
  void dispose() {
    MedBoxStore.revision.removeListener(_onBoxChanged);
    super.dispose();
  }

  /// 外部（如服药记录）改动药箱后，本地重新加载，保持余量实时可见
  void _onBoxChanged() {
    if (mounted) _reloadLocal();
  }

  Future<void> _reloadLocal() async {
    final items = await MedBoxStore.load();
    if (!mounted) return;
    setState(() {
      _items = items;
      _refreshAll();
    });
  }

  Future<void> _loadProfileAndRecords() async {
    final profile = await ProfileService.load();
    final records = await MedRecordService.instance.list();
    if (!mounted) return;
    setState(() {
      _profile = profile;
      _records = records;
    });
  }

  Future<void> _loadItems() async {
    final items = await MedBoxStore.load();
    if (items.isNotEmpty) {
      setState(() {
        _items = items;
        _refreshAll();
      });
    }
    await _pullFromServer();
  }

  /// 拉取服务端药箱记录并与本地合并
  /// 服务端不可用时静默降级，沿用本地数据，不打断用户
  Future<void> _pullFromServer() async {
    try {
      final devId = await DeviceUtils.deviceId();
      final familyCode = await DeviceUtils.familyCode();
      final resp = await HttpUtils().get(
        '/medbox/list',
        params: {
          if (familyCode.isNotEmpty)
            'familyCode': familyCode
          else
            'deviceId': devId,
        },
      );
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is List) {
        final remote = (body['data'] as List)
            .whereType<Map>()
            .map((e) => DrugItem.fromJson(Map<String, dynamic>.from(e)))
            .where((e) => e.medicineId.isNotEmpty)
            .toList();
        if (!mounted) return;
        setState(() {
          final map = <String, DrugItem>{
            for (final e in _items) e.medicineId: e,
          };
          for (final r in remote) {
            final local = map[r.medicineId];
            map[r.medicineId] =
                local == null ? r : local.copyWith(recycled: r.recycled);
          }
          _items = map.values.toList();
          _refreshAll();
        });
        await _saveItemsLocal();
      }
    } catch (_) {
      // 与服务端对齐失败不影响本地使用
    }
  }

  Future<void> _saveItemsLocal() async {
    await MedBoxStore.save(_items);
  }

  /// 本地保存 + 服务端同步（同步失败仅影响云端副本，本地照常可用）
  Future<void> _saveItems() async {
    await _saveItemsLocal();
    try {
      final devId = await DeviceUtils.deviceId();
      final familyCode = await DeviceUtils.familyCode();
      await HttpUtils().post(
        '/medbox/save',
        data: {
          'deviceId': devId,
          'familyCode': familyCode,
          'items': _items.map((e) => e.toJson()).toList(),
        },
      );
    } catch (_) {
      // 静默：下次进入页面时会重新拉取并补传
    }
  }

  void _refreshAll() {
    final now = DateTime.now();
    for (int i = 0; i < _items.length; i++) {
      if (_items[i].expDays > 0 && _items[i].produceTime.isNotEmpty) {
        try {
          final produce = DateTime.parse(_items[i].produceTime);
          final expire = produce.add(Duration(days: _items[i].expDays));
          final remaining = expire.difference(now).inDays;
          _items[i] = _items[i].copyWith(countDown: remaining);
        } catch (_) {}
      }
    }
  }

  List<DrugItem> get _filtered {
    final source = _filter == 'all'
        ? _items
        : _filter == 'disposable'
            ? _items.where((e) => e.countDown <= 0)
            : _items.where((e) => e.countDown > 0);
    return source.toList()..sort((a, b) => a.countDown.compareTo(b.countDown));
  }

  int get _expired => _items.where((e) => e.countDown <= 0).length;
  int get _warn =>
      _items.where((e) => e.countDown > 0 && e.countDown <= 30).length;

  /// 药箱安全快照。每次 build 现算：条目量级是家庭场景的几十条，
  /// 纯内存遍历成本可忽略，换来的是状态永远与列表一致，不需要手动失效缓存。
  SafetySnapshot get _safety => SafetySnapshot.of(_items);

  /// 打开 AI 药箱安全报告
  void _showSafetyReport() {
    HapticFeedback.selectionClick();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.4,
        maxChildSize: 0.92,
        expand: false,
        builder: (_, controller) => SingleChildScrollView(
          controller: controller,
          child: SafetyReportSheet(
            snapshot: _safety,
            service: ZhipuService(),
            onGoMap: () {
              Navigator.pop(ctx);
              _goMap();
            },
          ),
        ),
      ),
    );
  }

  /// 一键回收：读药箱过期/临期清单，聚合生成回收计划并推荐回收点。
  void _showRecyclePlan() {
    HapticFeedback.selectionClick();
    final plan = RecyclePlanner.plan(_items);
    if (plan.isEmpty) {
      _toast('药箱暂无需要回收的药品');
      return;
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        minChildSize: 0.4,
        maxChildSize: 0.9,
        expand: false,
        builder: (_, controller) => SingleChildScrollView(
          controller: controller,
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  DesignIcons.recycling(
                    size: 20,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      '一键回收',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                plan.headline,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: AppColors.primary,
                ),
              ),
              const SizedBox(height: 8),
              ...plan.categorySummary.map(
                (s) => Padding(
                  padding: const EdgeInsets.only(bottom: 4),
                  child: Text(
                    '• $s',
                    style: const TextStyle(
                      fontSize: 13,
                      color: AppColors.ink3,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              ...plan.items.map(
                (r) => Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.subtleBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          r.item.medicineName,
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      Text(
                        r.reason,
                        style: TextStyle(
                          fontSize: AppText.sizeCaption,
                          color: r.level == ExpiryLevel.expired
                              ? AppColors.danger
                              : AppColors.warning,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(ctx);
                  _goMap();
                },
                icon: DesignIcons.navigation(size: 18, color: Colors.white),
                label: const Text('去附近回收点'),
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// 当前筛选下已选中的条目
  List<DrugItem> get _selectedItems =>
      _items.where((e) => _selected.contains(e.medicineId)).toList();

  bool get _allSelected =>
      _filtered.isNotEmpty &&
      _filtered.every((e) => _selected.contains(e.medicineId));

  void _goMap() {
    HapticFeedback.selectionClick();
    HomePage.homeKey.currentState?.switchToTab(2);
  }

  void _goKnow() {
    HapticFeedback.selectionClick();
    HomePage.homeKey.currentState?.switchToTab(2);
    // 等待页面切换完成，滚动到知识科普区域
    Future.delayed(const Duration(milliseconds: 400), () {
      GuiChuPage.pageKey.currentState?.scrollToKnowledge();
    });
  }

  /// 进入服药计划页，返回后刷新服药记录（供 AI 助理使用）
  void _goMedPlan() {
    HapticFeedback.selectionClick();
    AppRoutes.toMedPlan(context, _items).then((_) => _loadProfileAndRecords());
  }

  // ============ 多选模式 ============

  void _enterSelectMode() {
    HapticFeedback.selectionClick();
    if (_items.isEmpty) {
      _toast('药箱为空，暂无可管理的记录');
      return;
    }
    setState(() {
      _selectMode = true;
      _selected.clear();
    });
  }

  void _exitSelectMode() {
    HapticFeedback.selectionClick();
    setState(() {
      _selectMode = false;
      _selected.clear();
    });
  }

  void _toggleSelect(String id) {
    HapticFeedback.selectionClick();
    setState(() {
      if (_selected.contains(id)) {
        _selected.remove(id);
      } else {
        _selected.add(id);
      }
    });
  }

  void _toggleSelectAll() {
    HapticFeedback.selectionClick();
    setState(() {
      if (_allSelected) {
        for (final e in _filtered) {
          _selected.remove(e.medicineId);
        }
      } else {
        for (final e in _filtered) {
          _selected.add(e.medicineId);
        }
      }
    });
  }

  /// 批量删除入口：二次确认 → 服务端删除 → 刷新
  Future<void> _deleteSelected() async {
    final targets = _selectedItems;
    if (targets.isEmpty) {
      _toast('请先选择要删除的记录');
      return;
    }
    final ok = await _confirmDelete(targets);
    if (ok != true) return;
    final done = await _removeItems(targets);
    if (done && mounted) {
      setState(() {
        if (_items.isEmpty) _selectMode = false;
      });
    }
  }

  /// 单条删除入口（侧滑删除走这里）
  /// 返回 bool 供 Dismissible.confirmDismiss 使用：true 才真正移除卡片
  Future<bool> _deleteOne(DrugItem item) async {
    final ok = await _confirmDelete([item]);
    if (ok != true) return false;
    return _removeItems([item]);
  }

  // ============ 删除核心逻辑 ============

  /// 二次确认弹窗，单条与批量共用，文案区分
  Future<bool?> _confirmDelete(List<DrugItem> targets) {
    final single = targets.length == 1;
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            DesignIcons.delete(size: 24, color: AppColors.danger),
            const SizedBox(width: 10),
            Text(
              single ? '删除这条记录' : '删除 ${targets.length} 条记录',
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
        content: Text(
          single
              ? '确认删除「${targets.first.medicineName}」吗？\n删除后将从药箱和云端同步移除，且不可恢复。'
              : '确认删除已选中的 ${targets.length} 条药品记录吗？\n删除后将从药箱和云端同步移除，且不可恢复。',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () {
              HapticFeedback.mediumImpact();
              Navigator.pop(ctx, true);
            },
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.danger,
            ),
            child: Text(single ? '确认删除' : '删除 ${targets.length} 条'),
          ),
        ],
      ),
    );
  }

  /// 执行删除：云端成功或确认云端不存在后才移除本地。
  /// 服务端错误、断网和超时均保留本地记录，保证失败可重试且不丢数据。
  Future<bool> _removeItems(List<DrugItem> targets) async {
    if (targets.isEmpty || _deleting) return false;
    final ids = targets.map((e) => e.medicineId).toList();
    setState(() => _deleting = true);

    String? syncNotice;
    bool remoteSuccess = false;
    bool remoteMissing = false;
    try {
      final devId = await DeviceUtils.deviceId();
      final familyCode = await DeviceUtils.familyCode();
      final response = ids.length == 1
          ? await HttpUtils().delete(
              '/medbox/delete',
              params: {
                'boxId': ids.first,
                if (familyCode.isNotEmpty)
                  'familyCode': familyCode
                else
                  'deviceId': devId,
              },
            )
          : await HttpUtils().delete(
              '/medbox/deleteBatch',
              data: {
                if (familyCode.isNotEmpty)
                  'familyCode': familyCode
                else
                  'deviceId': devId,
                'boxIds': ids,
              },
            );
      final body = response.data;
      if (body is Map && body['code'] != null) {
        final code = int.tryParse(body['code'].toString()) ?? 0;
        if (code == 200) {
          remoteSuccess = true;
        } else if (code == 404) {
          remoteMissing = true;
        } else {
          syncNotice = (body['msg'] ?? '请求失败').toString();
        }
      } else {
        remoteSuccess = true;
      }
    } catch (e) {
      final text = HttpUtils.describeError(e);
      remoteMissing = text.contains('404');
      if (!remoteMissing) syncNotice = text;
    }

    if (!mounted) return false;
    setState(() => _deleting = false);
    if (remoteSuccess || remoteMissing) {
      setState(() {
        _items.removeWhere((e) => ids.contains(e.medicineId));
        _selected.removeWhere(ids.contains);
        _refreshAll();
      });
      await _saveItemsLocal();
      if (!mounted) return true;
      _toast(remoteMissing ? '已从药箱移除（云端无对应记录）' : '已删除 ${ids.length} 条记录');
      return true;
    }

    final detail = syncNotice ?? '请稍后重试';
    _toast(
      detail == '网络连接不可用，请检查网络' ? '删除失败：$detail' : '删除失败，请稍后重试',
      error: true,
    );
    return false;
  }

  void _toast(String msg, {bool error = false}) {
    if (!mounted) return;
    // maybeOf：页面被拆离页面使用时可能没有祖先 Scaffold，
    // 直接 ScaffoldMessenger.of(context) 会抛出 assertion 导致整页崩溃。
    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger == null) return;
    messenger.showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              error ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
              size: 18,
            ),
            const SizedBox(width: 8),
            Expanded(child: Text(msg)),
          ],
        ),
        backgroundColor:
            error ? AppColors.danger : AppColors.primary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 96),
        duration: Duration(seconds: error ? 4 : 2),
      ),
    );
  }

  // ============ 录入与回收 ============

  Future<void> _edit(DrugItem original) async {
    final nameCtrl = TextEditingController(text: original.medicineName);
    final dateCtrl = TextEditingController(text: original.produceTime);
    final expCtrl = TextEditingController(
      text: (original.expDays ~/ 30).toString(),
    );
    final totalCtrl = TextEditingController(text: _fmtQty(original.total));
    final unitCtrl = TextEditingController(text: original.unit);
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(
          20,
          20,
          20,
          MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              '编辑药品',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: nameCtrl,
              decoration: const InputDecoration(labelText: '药品名称'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: dateCtrl,
              decoration: const InputDecoration(labelText: '生产日期'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: expCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: '有效期（月）'),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: totalCtrl,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: const InputDecoration(labelText: '总量'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: unitCtrl,
                    decoration: const InputDecoration(labelText: '单位'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    child: const Text('取消'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    onPressed: () => Navigator.pop(ctx, true),
                    child: const Text('保存'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    final name = nameCtrl.text.trim();
    final produce = dateCtrl.text.trim();
    final months = int.tryParse(expCtrl.text.trim());
    final total = double.tryParse(totalCtrl.text.trim());
    if (name.isEmpty ||
        months == null ||
        months <= 0 ||
        total == null ||
        total < 0) {
      _toast('请填写有效的药品名称、有效期和总量', error: true);
      return;
    }
    final updated = original.copyWith(
      medicineName: name,
      produceTime: produce,
      expDays: months * 30,
      total: total,
      remaining:
          total > original.total ? total : original.remaining.clamp(0, total),
      unit: unitCtrl.text.trim(),
    );
    setState(() {
      final index = _items.indexWhere(
        (e) => e.medicineId == original.medicineId,
      );
      if (index >= 0) _items[index] = updated;
      _refreshAll();
    });
    await _saveItems();
    _toast('药品信息已更新');
  }

  Future<void> _add() async {
    HapticFeedback.mediumImpact();
    final nameCtrl = TextEditingController();
    final dateCtrl = TextEditingController(
      text: DateFormat('yyyy-MM-dd').format(DateTime.now()),
    );
    final expCtrl = TextEditingController(text: '24');
    final totalCtrl = TextEditingController();
    final unitCtrl = TextEditingController(text: '片');

    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        padding: EdgeInsets.fromLTRB(
          24,
          24,
          24,
          MediaQuery.of(ctx).viewInsets.bottom + 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              '添加药品',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nameCtrl,
              decoration: InputDecoration(
                labelText: '药品名称',
                hintText: '如：阿莫西林胶囊',
                prefixIcon: DesignIcons.medication(size: 20),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: dateCtrl,
              decoration: InputDecoration(
                labelText: '生产日期',
                hintText: 'yyyy-MM-dd',
                prefixIcon: DesignIcons.calendar(size: 20),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: expCtrl,
              decoration: InputDecoration(
                labelText: '有效期（月）',
                prefixIcon: DesignIcons.timer(size: 20),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: totalCtrl,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: InputDecoration(
                      labelText: '总量',
                      hintText: '如 20',
                      prefixIcon: DesignIcons.medication(size: 20),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    controller: unitCtrl,
                    decoration: InputDecoration(
                      labelText: '单位',
                      hintText: '片/颗/瓶/mg/ml',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(ctx, false),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('取消'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      HapticFeedback.lightImpact();
                      Navigator.pop(ctx, true);
                    },
                    style: FilledButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: const Text('添加到药箱'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );

    if (ok == true && nameCtrl.text.isNotEmpty) {
      final m = int.tryParse(expCtrl.text) ?? 24;
      final total = double.tryParse(totalCtrl.text) ?? 0;
      final unit = unitCtrl.text.trim();
      final item = DrugItem(
        medicineId: DateTime.now().millisecondsSinceEpoch.toString(),
        medicineName: nameCtrl.text,
        produceTime: dateCtrl.text,
        addTime: DateFormat('yyyy-MM-dd').format(DateTime.now()),
        countDown: m * 30,
        expDays: m * 30,
        source: 'local',
        total: total,
        unit: unit,
        remaining: total, // 初始余量 = 总量
      );
      setState(() => _items.add(item));
      _refreshAll();
      await _saveItems();
      ReminderService.instance.scheduleExpiryReminders(_items);
    }
  }

  /// 标记已回收 → 从药箱移除（同样走服务端删除与二次确认）
  Future<void> _markRecycled(DrugItem item) async {
    HapticFeedback.lightImpact();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            DesignIcons.recycling(size: 24, color: AppColors.primary),
            const SizedBox(width: 10),
            const Text('确认回收', style: TextStyle(fontSize: 18)),
          ],
        ),
        content: Text('「${item.medicineName}」已投递到回收点了吗？\n确认后将从药箱移除。'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor: AppColors.primary,
            ),
            child: const Text('确认已回收'),
          ),
        ],
      ),
    );
    if (ok == true) await _removeItems([item]);
  }

  @override
  Widget build(BuildContext context) {
    final total = _items.length;
    final expired = _expired;
    final warn = _warn;
    final selectedCount = _selected.length;

    return AppBackground(
      overlayColor: Colors.white,
      overlayOpacity: 0.15,
      child: Stack(
        children: [
          Column(
            children: [
              // 统计与安全信息共用一个连续容器，使用间距和分隔线区分层次。
              Flexible(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: AppColors.divider),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.05),
                        blurRadius: 14,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(24),
                    child: Column(
                      children: [
                        // 统计卡片
                        Container(
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primary.withValues(
                                  alpha: 0.12,
                                ),
                                blurRadius: 10,
                                offset: const Offset(0, 3),
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(AppRadius.xl),
                            ),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                vertical: 20,
                                horizontal: 8,
                              ),
                              decoration: const BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    AppColors.primaryStrong,
                                    AppColors.primaryLight
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: _stat(
                                      '$total',
                                      '在册',
                                      DesignIcons.medication(
                                        size: 22,
                                        color: Colors.white70,
                                      ),
                                    ),
                                  ),
                                  Container(
                                      width: 1,
                                      height: 36,
                                      color: Colors.white24),
                                  Expanded(
                                    child: _stat(
                                      '$expired',
                                      '已过期',
                                      DesignIcons.dangerous(
                                        size: 22,
                                        color: AppColors.onDarkDanger,
                                      ),
                                    ),
                                  ),
                                  Container(
                                      width: 1,
                                      height: 36,
                                      color: Colors.white24),
                                  Expanded(
                                    child: _stat(
                                      '$warn',
                                      '即将到期',
                                      DesignIcons.warning(
                                        size: 22,
                                        color: AppColors.onDarkWarning,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),

                        const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Divider(height: 1, color: AppColors.divider),
                        ),
                        // AI 药箱安全区：与统计摘要位于同一容器，内容过长时只滚动本区域。
                        Flexible(
                          child: SingleChildScrollView(
                            physics: const ClampingScrollPhysics(),
                            padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                SafetyZone(snapshot: _safety, onGoMap: _goMap),

                                // AI 服药助理（药宝小形象，冒气泡主动提醒）
                                MedAssistant(
                                  profile: _profile,
                                  items: _items,
                                  records: _records,
                                ),

                                // 服药计划入口
                                GestureDetector(
                                  onTap: _goMedPlan,
                                  child: Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 12,
                                    ),
                                    decoration: BoxDecoration(
                                      gradient: const LinearGradient(
                                        colors: [
                                          AppColors.primaryTintWeak,
                                          AppColors.primaryTintWeak
                                        ],
                                      ),
                                      borderRadius: BorderRadius.circular(14),
                                      border: Border.all(
                                          color: AppColors.primaryTint),
                                    ),
                                    child: Row(
                                      children: [
                                        DesignIcons.calendar(
                                          size: 18,
                                          color: AppColors.primary,
                                        ),
                                        const SizedBox(width: 10),
                                        const Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                '服药计划',
                                                style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.w700,
                                                  color: AppColors.primaryStrong,
                                                ),
                                              ),
                                              SizedBox(height: 2),
                                              Text(
                                                '定时服药闹钟 + 服药记录，同步系统日历',
                                                style: TextStyle(
                                                  fontSize: AppText.sizeCaption,
                                                  color: AppColors.muted,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        DesignIcons.chevronRight(
                                          size: 18,
                                          color: AppColors.primary,
                                        ),
                                      ],
                                    ),
                                  ),
                                ),

                                // AI 安全报告入口
                                if (_items.isNotEmpty)
                                  GestureDetector(
                                    onTap: _showSafetyReport,
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10),
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 14,
                                        vertical: 12,
                                      ),
                                      decoration: BoxDecoration(
                                        gradient: const LinearGradient(
                                          colors: [
                                            AppColors.primaryTintWeak,
                                            AppColors.subtleBg
                                          ],
                                        ),
                                        borderRadius: BorderRadius.circular(14),
                                        border: Border.all(
                                          color: AppSemantic.aiTint,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          DesignIcons.autoAwesome(
                                            size: 18,
                                            color: AppSemantic.ai,
                                          ),
                                          const SizedBox(width: 10),
                                          const Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  'AI 药箱安全报告',
                                                  style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppSemantic.aiStrong,
                                                  ),
                                                ),
                                                SizedBox(height: 2),
                                                Text(
                                                  '生成整理优先级与收纳建议',
                                                  style: TextStyle(
                                                    fontSize: AppText.sizeCaption,
                                                    color: AppColors.muted,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          DesignIcons.chevronRight(
                                            size: 18,
                                            color: AppSemantic.ai,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                // 一键回收入口：读药箱过期/临期清单，聚合生成回收计划
                                if (_items.isNotEmpty)
                                  GestureDetector(
                                    onTap: _showRecyclePlan,
                                    child: Container(
                                      margin: const EdgeInsets.only(top: 10),
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 14,
                                        vertical: 12,
                                      ),
                                      decoration: BoxDecoration(
                                        gradient: const LinearGradient(
                                          colors: [
                                            AppColors.warningTint,
                                            AppColors.primaryTintWeak
                                          ],
                                        ),
                                        borderRadius: BorderRadius.circular(14),
                                        border: Border.all(
                                          color: AppColors.divider,
                                        ),
                                      ),
                                      child: Row(
                                        children: [
                                          DesignIcons.recycling(
                                            size: 18,
                                            color: AppColors.primary,
                                          ),
                                          const SizedBox(width: 10),
                                          const Expanded(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  '一键回收',
                                                  style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight: FontWeight.w700,
                                                    color: AppColors.primaryStrong,
                                                  ),
                                                ),
                                                SizedBox(height: 2),
                                                Text(
                                                  '自动整理过期与临期药品，推荐最近回收点',
                                                  style: TextStyle(
                                                    fontSize: AppText.sizeCaption,
                                                    color: AppColors.muted,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          DesignIcons.chevronRight(
                                            size: 18,
                                            color: AppColors.primary,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // 分类筛选 + 管理入口
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    _filterChip('全部 ($total)', 'all'),
                    const SizedBox(width: 8),
                    _filterChip('有效期内', 'reusable'),
                    const SizedBox(width: 8),
                    _filterChip('已过期', 'disposable'),
                    const Spacer(),
                    GestureDetector(
                      onTap: _selectMode ? _exitSelectMode : _enterSelectMode,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: _selectMode
                              ? AppColors.primary
                              : Colors.white,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppColors.primary),
                        ),
                        child: Text(
                          _selectMode ? '完成' : '管理',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: _selectMode
                                ? Colors.white
                                : AppColors.primaryStrong,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // 多选工具条：全选 / 已选计数 / 批量删除
              if (_selectMode)
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: AppColors.primaryTintWeak,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.primaryTint),
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: _toggleSelectAll,
                        child: Row(
                          children: [
                            Icon(
                              _allSelected
                                  ? Icons.check_circle
                                  : Icons.radio_button_unchecked,
                              size: 20,
                              color: AppColors.primary,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              _allSelected ? '取消全选' : '全选',
                              style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.primaryStrong,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '已选 $selectedCount 条',
                        style: const TextStyle(
                          fontSize: 13,
                          color: AppColors.primaryStrong,
                        ),
                      ),
                      const SizedBox(width: 10),
                      SizedBox(
                        height: 32,
                        child: FilledButton.icon(
                          onPressed: _deleting ? null : _deleteSelected,
                          icon: _deleting
                              ? const SizedBox(
                                  width: 14,
                                  height: 14,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : DesignIcons.delete(
                                  size: 16,
                                  color: Colors.white,
                                ),
                          label: Text(_deleting ? '删除中…' : '批量删除'),
                          style: FilledButton.styleFrom(
                            backgroundColor: AppColors.danger,
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 8),

              // 药品列表
              Expanded(
                child: _filtered.isEmpty
                    ? Center(
                        child: SingleChildScrollView(
                          padding: const EdgeInsets.only(bottom: 80),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              DesignIcons.medicationOutlined(
                                size: 52,
                                color: AppColors.primaryPale,
                              ),
                              const SizedBox(height: 16),
                              const Text(
                                '药箱为空',
                                style: TextStyle(
                                  fontSize: 20,
                                  color: AppColors.ink3,
                                ),
                              ),
                              const SizedBox(height: 6),
                              const Text(
                                '点击 + 添加家中药品',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.ink3,
                                ),
                              ),

                              // 家庭药品管理小贴士
                              const SizedBox(height: 24),
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: AppColors.primaryTintWeak,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                    color: AppColors.primaryTint,
                                  ),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        DesignIcons.lightbulb(
                                          size: 20,
                                          color: AppColors.primary,
                                        ),
                                        const SizedBox(width: 8),
                                        const Text(
                                          '家庭药品管理小贴士',
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w700,
                                            color: AppColors.primaryStrong,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 10),
                                    const Text(
                                      '• 每3个月检查一次家庭药箱\n• 过期药品属于危险废物，请勿随意丢弃\n• 将药品存放在阴凉干燥处，避免儿童接触\n• 不同药品分开存放，避免交叉污染',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: AppColors.ink3,
                                        height: 1.8,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              // 空药箱引导按钮
                              const SizedBox(height: 16),
                              OutlinedButton.icon(
                                onPressed: _goKnow,
                                icon: DesignIcons.menuBook(
                                  size: 16,
                                  color: AppColors.primary,
                                ),
                                label: const Text('先学回收知识'),
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: AppColors.primary,
                                  side: const BorderSide(
                                    color: AppColors.primary,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 24,
                                    vertical: 12,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 80),
                        itemCount: _filtered.length,
                        itemBuilder: (ctx, i) {
                          final item = _filtered[i];
                          // 统一走五级规则，与顶部安全区、AI 报告用的是同一套判定
                          final verdict = ExpiryRule.judge(
                            remainDays: item.countDown,
                            drugName: item.medicineName,
                            openedDays: item.openedDays,
                          );
                          final isExpired = verdict.isExpired;
                          final barColor = SafetyColors.of(verdict.level);
                          final selected = _selected.contains(item.medicineId);

                          final card = Container(
                            margin: const EdgeInsets.symmetric(vertical: 5),
                            decoration: BoxDecoration(
                              color: selected
                                  ? AppColors.primaryTintWeak
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(18),
                              border: selected
                                  ? Border.all(
                                      color: AppColors.primaryLight,
                                      width: 1.5,
                                    )
                                  : null,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withValues(alpha: 0.04),
                                  blurRadius: 6,
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(18),
                              child: IntrinsicHeight(
                                child: Row(
                                  children: [
                                    Container(width: 5, color: barColor),
                                    Expanded(
                                      child: Padding(
                                        padding: const EdgeInsets.all(16),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 44,
                                              height: 44,
                                              decoration: BoxDecoration(
                                                color: barColor.withValues(alpha: 
                                                  0.1,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(12),
                                              ),
                                              child: isExpired
                                                  ? DesignIcons.dangerous(
                                                      size: 22,
                                                      color: barColor,
                                                    )
                                                  : DesignIcons.medication(
                                                      size: 22,
                                                      color: barColor,
                                                    ),
                                            ),
                                            const SizedBox(width: 12),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    item.medicineName,
                                                    style: const TextStyle(
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w600,
                                                    ),
                                                  ),
                                                  const SizedBox(height: 4),
                                                  // 窄屏/横屏下这段信息行会溢出，两个文案都需可压缩
                                                  Row(
                                                    children: [
                                                      Expanded(
                                                        child: Text(
                                                          '生产: ${item.produceTime}',
                                                          style: TextStyle(
                                                            fontSize: 12,
                                                            color: Colors
                                                                .grey[500],
                                                          ),
                                                          overflow: TextOverflow
                                                              .ellipsis,
                                                          maxLines: 1,
                                                        ),
                                                      ),
                                                      const SizedBox(width: 8),
                                                      Text(
                                                        verdict.label,
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: barColor,
                                                        ),
                                                        overflow: TextOverflow
                                                            .ellipsis,
                                                        maxLines: 1,
                                                      ),
                                                    ],
                                                  ),
                                                  if (item.total > 0) ...[
                                                    const SizedBox(height: 3),
                                                    Text(
                                                      '剩余 ${_fmtQty(item.remaining)}${item.unit} / 总量 ${_fmtQty(item.total)}${item.unit}',
                                                      style: const TextStyle(
                                                        fontSize: AppText.sizeCaption,
                                                        color:
                                                            AppColors.primaryStrong,
                                                      ),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                    ),
                                                  ],
                                                  if (item.lastTakenAt
                                                      .isNotEmpty) ...[
                                                    const SizedBox(height: 2),
                                                    Text(
                                                      '最近服用 ${item.lastTakenAt}',
                                                      style: TextStyle(
                                                        fontSize: AppText.sizeCaption,
                                                        color: AppColors.muted,
                                                      ),
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      maxLines: 1,
                                                    ),
                                                  ],
                                                ],
                                              ),
                                            ),
                                            GestureDetector(
                                              onTap: isExpired
                                                  ? _goMap
                                                  : () => _markRecycled(item),
                                              child: Container(
                                                padding: const EdgeInsets.all(
                                                  10,
                                                ),
                                                decoration: BoxDecoration(
                                                  color: isExpired
                                                      ? AppColors.primary
                                                      : AppColors.primaryTintWeak,
                                                  borderRadius:
                                                      BorderRadius.circular(12),
                                                ),
                                                child: isExpired
                                                    ? DesignIcons.navigation(
                                                        size: 18,
                                                        color: Colors.white,
                                                      )
                                                    : DesignIcons.recycling(
                                                        size: 18,
                                                        color: AppColors.primary,
                                                      ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );

                          // 多选模式下：关闭侧滑，改为点选 + 勾选圈
                          if (_selectMode) {
                            return GestureDetector(
                              onTap: () => _toggleSelect(item.medicineId),
                              child: Row(
                                children: [
                                  Icon(
                                    selected
                                        ? Icons.check_circle
                                        : Icons.radio_button_unchecked,
                                    size: 22,
                                    color: selected
                                        ? AppColors.primary
                                        : AppColors.muted,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(child: card),
                                ],
                              ),
                            );
                          }

                          return AnimatedSwitcher(
                            duration: const Duration(milliseconds: 220),
                            switchInCurve: Curves.easeOutCubic,
                            switchOutCurve: Curves.easeInCubic,
                            transitionBuilder: (child, animation) =>
                                FadeTransition(
                              opacity: animation,
                              child: SizeTransition(
                                sizeFactor: animation,
                                axisAlignment: -1,
                                child: child,
                              ),
                            ),
                            child: GestureDetector(
                              key: ValueKey('drug-${item.medicineId}'),
                              onLongPress: () => _edit(item),
                              child: Dismissible(
                                key: Key(item.medicineId),
                                direction: DismissDirection.endToStart,
                                background: Container(
                                  margin:
                                      const EdgeInsets.symmetric(vertical: 5),
                                  alignment: Alignment.centerRight,
                                  padding: const EdgeInsets.only(right: 24),
                                  decoration: BoxDecoration(
                                    color: Colors.red[400],
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                  child: DesignIcons.delete(
                                    size: 24,
                                    color: Colors.white,
                                  ),
                                ),
                                // 删除成功才真正移除卡片，失败时卡片回弹并提示原因
                                confirmDismiss: (_) => _deleteOne(item),
                                onDismissed: (_) => _saveItemsLocal(),
                                child: card,
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
          // FAB（多选模式下隐藏，避免误触新增）
          if (!_selectMode)
            Positioned(
              right: 16,
              bottom: 16,
              child: FloatingActionButton.extended(
                onPressed: _add,
                backgroundColor: AppColors.primary,
                foregroundColor: Colors.white,
                icon: DesignIcons.add(size: 24, color: Colors.white),
                label: const Text('添加药品'),
              ),
            ),
        ],
      ),
    );
  }

  /// 格式化数量：整数不带小数点（20），小数保留（0.5）
  String _fmtQty(double v) {
    if (v == v.roundToDouble()) return v.toInt().toString();
    return v.toString();
  }

  Widget _stat(String val, String label, Widget icon) => SizedBox(
        width: double.infinity,
        child: Column(
          children: [
            icon,
            const SizedBox(height: 4),
            Text(
              val,
              style: DesignIcons.greenBgValue(fontSize: 24),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: DesignIcons.greenBgLabel(),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );

  Widget _filterChip(String label, String val) {
    final active = _filter == val;
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _filter = val);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: active ? AppColors.primaryTintWeak : Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? AppColors.primary : Colors.grey[200]!,
            width: active ? 2 : 1,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: active ? FontWeight.w600 : FontWeight.normal,
            color: active ? AppColors.primaryStrong : Colors.grey[600],
          ),
        ),
      ),
    );
  }
}
