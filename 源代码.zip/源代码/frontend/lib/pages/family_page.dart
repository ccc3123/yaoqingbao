import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../util/auth_service.dart';
import '../util/device_utils.dart';
import '../util/http_utils.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 家庭管理页 —— 一个家庭一个共享药箱。
///
/// 混合双入口：子女用账号创建家庭，父母老人凭 6 位家庭码加入。
class FamilyPage extends StatefulWidget {
  const FamilyPage({super.key});

  @override
  State<FamilyPage> createState() => _FamilyPageState();
}

class _FamilyPageState extends State<FamilyPage> {
  String _familyCode = '';
  List<Map<String, dynamic>> _members = [];
  bool _loading = true;
  final _nameCtrl = TextEditingController();
  final _joinCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _joinCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final code = await DeviceUtils.familyCode();
    if (code.isEmpty) {
      setState(() {
        _familyCode = '';
        _members = [];
        _loading = false;
      });
      return;
    }
    try {
      final resp = await HttpUtils().get('/family/members',
          params: {'familyCode': code});
      final body = resp.data;
      if (body is Map && body['code'] == 200 && body['data'] is List) {
        setState(() {
          _familyCode = code;
          _members = (body['data'] as List)
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
          _loading = false;
        });
        return;
      }
    } catch (_) {}
    setState(() {
      _familyCode = code;
      _loading = false;
    });
  }

  Future<void> _createFamily() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      _toast('请填写家庭名称');
      return;
    }
    HapticFeedback.mediumImpact();
    final code = await AuthService.instance.createFamily(familyName: name);
    if (code != null) {
      _toast('家庭创建成功，家庭码 $code');
      await _load();
    } else {
      _toast('创建失败，请检查网络');
    }
  }

  Future<void> _joinFamily() async {
    final code = _joinCtrl.text.trim();
    if (code.length != 6) {
      _toast('请输入 6 位家庭码');
      return;
    }
    HapticFeedback.mediumImpact();
    final result = await AuthService.instance.joinFamily(familyCode: code);
    if (result != null) {
      _toast('已加入家庭');
      await _load();
    } else {
      _toast('加入失败，请核对家庭码');
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.maybeOf(context)
        ?.showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('家庭药箱')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: _familyCode.isEmpty ? _buildNoFamily() : _buildFamily(),
            ),
    );
  }

  List<Widget> _buildNoFamily() {
    return [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.primaryTintWeak,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('还没有家庭',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
            SizedBox(height: 8),
            Text(
              '创建家庭后，全家共享同一个药箱；\n父母老人可凭家庭码免注册加入。',
              style: TextStyle(fontSize: 13, color: AppColors.ink3, height: 1.6),
            ),
          ],
        ),
      ),
      const SizedBox(height: 20),
      const Text('创建家庭',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      TextField(
        controller: _nameCtrl,
        decoration: const InputDecoration(labelText: '家庭名称', hintText: '如：我们一家'),
      ),
      const SizedBox(height: 10),
      FilledButton(
        onPressed: _createFamily,
        style: FilledButton.styleFrom(backgroundColor: AppColors.primary),
        child: const Text('创建家庭'),
      ),
      const SizedBox(height: 28),
      const Text('加入家庭',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      TextField(
        controller: _joinCtrl,
        keyboardType: TextInputType.number,
        maxLength: 6,
        decoration: const InputDecoration(
            labelText: '6 位家庭码', counterText: '', hintText: '向家人索取'),
      ),
      const SizedBox(height: 10),
      OutlinedButton(
        onPressed: _joinFamily,
        style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.primary,
            side: const BorderSide(color: AppColors.primary)),
        child: const Text('加入家庭'),
      ),
    ];
  }

  List<Widget> _buildFamily() {
    return [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppColors.primaryStrong, AppColors.primaryLight],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          children: [
            const Text('我的家庭码',
                style: TextStyle(fontSize: 13, color: Colors.white70)),
            const SizedBox(height: 8),
            Text(
              _familyCode,
              style: const TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 6,
              ),
            ),
            const SizedBox(height: 8),
            const Text('把家庭码告诉家人，即可共享药箱',
                style: TextStyle(fontSize: AppText.sizeCaption, color: Colors.white70)),
          ],
        ),
      ),
      const SizedBox(height: 20),
      const Text('家庭成员',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
      const SizedBox(height: 10),
      if (_members.isEmpty)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 12),
          child: Center(
              child: Text('暂无成员',
                  style: TextStyle(fontSize: 13, color: AppColors.muted))),
        )
      else
        ..._members.map((m) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.divider),
              ),
              child: Row(
                children: [
                  const Icon(Icons.person_outline,
                      size: 20, color: AppColors.primary),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      (m['memberName'] ?? '').toString(),
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w600),
                    ),
                  ),
                  if ((m['role'] ?? '') == 'owner')
                    const Text('创建者',
                        style: TextStyle(
                            fontSize: AppText.sizeCaption, color: AppColors.primary)),
                ],
              ),
            )),
    ];
  }
}
