import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/drug_item.dart';
import '../data/med_record.dart';
import '../data/user_profile.dart';
import '../util/ai_client.dart';
import '../util/med_advisor.dart';
import '../util/speech_service.dart';
import '../widgets/design_icons.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// AI 服药助理 · 问答页
///
/// 多轮对话，支持文字 + 语音输入。联网 AI 生成用药建议，断网走本地兜底。
class MedChatPage extends StatefulWidget {
  final UserProfile profile;
  final List<DrugItem> items;
  final List<MedRecord> records;

  const MedChatPage({
    super.key,
    required this.profile,
    required this.items,
    required this.records,
  });

  @override
  State<MedChatPage> createState() => _MedChatPageState();
}

class _MedChatPageState extends State<MedChatPage> {
  final List<ChatMessage> _messages = [];
  final TextEditingController _input = TextEditingController();
  final SpeechService _speech = SpeechService();
  final ScrollController _scroll = ScrollController();
  bool _thinking = false;
  bool _recording = false;

  @override
  void initState() {
    super.initState();
    _messages.add(const ChatMessage(
      role: 'assistant',
      content: '你好呀，我是你的 AI 服药助理「药宝」～\n'
          '可以问我：哪些药不能连续吃、用量会不会太大、两次服药间隔多久、'
          '哪些食物/酒/水果不能和药一起吃，我还能结合你的身体状况给你评估。',
    ));
  }

  @override
  void dispose() {
    _speech.dispose();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _input.text).trim();
    if (text.isEmpty || _thinking) return;
    _input.clear();
    setState(() {
      _messages.add(ChatMessage(role: 'user', content: text));
      _thinking = true;
    });
    _scrollToBottom();

    final reply = await MedAdvisor.instance.answer(
      question: text,
      profile: widget.profile,
      items: widget.items,
      records: widget.records,
      history: _messages.sublist(0, _messages.length - 1),
    );

    if (!mounted) return;
    setState(() {
      _messages.add(ChatMessage(role: 'assistant', content: reply));
      _thinking = false;
    });
    _scrollToBottom();
  }

  Future<void> _toggleVoice() async {
    if (_recording) {
      HapticFeedback.lightImpact();
      final text = await _speech.stopAndRecognize();
      setState(() => _recording = false);
      if (text != null && text.isNotEmpty) {
        _input.text = text;
        _input.selection = TextSelection.fromPosition(
            TextPosition(offset: _input.text.length));
      }
    } else {
      try {
        await _speech.start();
        setState(() => _recording = true);
      } catch (_) {
        _toast('未获得麦克风权限，请用文字输入');
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(_scroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 250),
            curve: Curves.easeOut);
      }
    });
  }

  void _toast(String msg) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger == null) return;
    messenger.showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 服药助理'),
        // BackButton 自带本地化 tooltip 与正确的读屏语义，手写 IconButton 会丢掉。
        leading: const BackButton(),
      ),
      body: Column(
        children: [
          // 合规提示条
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            color: AppColors.warningTint,
            child: const Row(
              children: [
                Icon(Icons.info_outline, size: 14, color: AppColors.warning),
                SizedBox(width: 6),
                Expanded(
                  child: Text(
                    '用药建议由 AI 生成，仅供参考，请遵医嘱或咨询药师',
                    style: TextStyle(fontSize: AppText.sizeCaption, color: AppSemantic.sourceLocal),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              controller: _scroll,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              itemCount: _messages.length + (_thinking ? 1 : 0),
              itemBuilder: (ctx, i) {
                if (i == _messages.length) {
                  return _typingBubble();
                }
                final m = _messages[i];
                final isUser = m.role == 'user';
                return _bubble(m.content, isUser);
              },
            ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _bubble(String text, bool isUser) {
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(
            maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          color: isUser ? AppColors.primary : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(16),
            topRight: const Radius.circular(16),
            bottomLeft: Radius.circular(isUser ? 16 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 16),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 4),
          ],
        ),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 14,
            height: 1.55,
            color: isUser ? Colors.white : AppColors.ink,
          ),
        ),
      ),
    );
  }

  Widget _typingBubble() {
    return const Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(strokeWidth: 2)),
            SizedBox(width: 10),
            Text('药宝思考中…',
                style: TextStyle(fontSize: 12, color: AppColors.ink3)),
          ],
        ),
      ),
    );
  }

  Widget _buildInputBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 8),
          ],
        ),
        child: Row(
          children: [
            // 语音按钮
            GestureDetector(
              onTap: _toggleVoice,
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: _recording
                      ? AppColors.danger
                      : AppColors.primaryTintWeak,
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _recording ? Icons.stop : Icons.mic_none,
                  color: _recording ? Colors.white : AppColors.primary,
                  size: 22,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _input,
                onSubmitted: (_) => _send(),
                textInputAction: TextInputAction.send,
                decoration: InputDecoration(
                  hintText: '输入用药问题…',
                  isDense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  filled: true,
                  fillColor: AppColors.surface,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(22),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _thinking ? null : () => _send(),
              child: Container(
                width: 44,
                height: 44,
                decoration: const BoxDecoration(
                  color: AppColors.primary,
                  shape: BoxShape.circle,
                ),
                child: DesignIcons.autoAwesome(size: 20, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
