import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import '../util/http_utils.dart';
import '../data/region_data.dart';
import '../util/geo_utils.dart';
import '../widgets/design_icons.dart';
import '../widgets/app_background.dart';
import '../widgets/station_map.dart';
import '../routes/app_routes.dart';
import '../theme/app_colors.dart';
import '../theme/app_text.dart';

/// 归处 — 地图点位 + 附近回收点 + 省市区级联 + 离线药店兜底 + 知识科普
class GuiChuPage extends StatefulWidget {
  const GuiChuPage({super.key});

  /// 用于外部跳转到知识科普区域
  static final GlobalKey<GuiChuPageState> pageKey =
      GlobalKey<GuiChuPageState>();

  @override
  State<GuiChuPage> createState() => GuiChuPageState();
}

class GuiChuPageState extends State<GuiChuPage> {
  final ScrollController _scrollCtrl = ScrollController();
  List _stations = [];
  List _articles = [];
  bool _loading = false;
  bool _locating = true;
  String _statusText = '';
  Position? _position;
  String _radius = '3000';
  String _selectedName = '';

  /// 地图与列表联动：当前选中的站点下标，-1 为未选中
  int _selectedIndex = -1;

  /// 最近一次检索使用的中心点（WGS84），用于地图标注与距离计算
  double _centerLat = 0;
  double _centerLng = 0;

  // 离线药店数据库
  List<Map<String, dynamic>> _offlineStations = [];
  bool _offlineLoaded = false;
  int _locateAttempt = 0;
  bool _isSearching = false;
  String? _locationError;
  static const _locationCacheKey = 'yaoqingbao_location_cache';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _tryLocate();
      _loadOfflineData();
    });
    _loadKnowledge();
  }

  @override
  void dispose() {
    _scrollCtrl.dispose();
    super.dispose();
  }

  /// 滚动到知识科普区域（从其他页面跳转时使用）
  void scrollToKnowledge() {
    if (_scrollCtrl.hasClients) {
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeOut,
      );
    }
  }

  // ═══════════════════════════════════════
  //  离线药店数据加载
  // ═══════════════════════════════════════
  Future<void> _loadOfflineData() async {
    try {
      final jsonStr = await DefaultAssetBundle.of(
        context,
      ).loadString('assets/data/offline_pharmacies.json');
      final data = jsonDecode(jsonStr);
      if (mounted) {
        setState(() {
          _offlineStations = List<Map<String, dynamic>>.from(
            (data['pharmacies'] as List).map(
              (e) => Map<String, dynamic>.from(e),
            ),
          );
          _offlineLoaded = true;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _offlineLoaded = true);
    }
  }

  // ═══════════════════════════════════════
  //  GPS 定位（完整三步检测链）
  // ═══════════════════════════════════════
  Future<void> _tryLocate({bool allowCache = true}) async {
    if (!mounted) return;
    setState(() {
      _locating = true;
      _locationError = null;
      _statusText = '正在定位...';
    });
    try {
      // ① 先检查系统定位服务。缓存不能绕过用户当前关闭 GPS 的状态，
      // 否则页面会显示“定位成功”而无法给出开启定位的明确引导。
      // 原生实现缺失（插件未注册/裁剪 ROM）时会出现 MissingPluginException，
      // 权限查询也可能因为系统弹窗而长久不返回，这里统一兜底到城市选择。
      final svc = await Geolocator.isLocationServiceEnabled().timeout(
        const Duration(seconds: 5),
      );
      if (!svc) {
        if (!mounted) return;
        setState(() {
          _locating = false;
          _position = null;
          _stations = [];
          _locationError = '请开启手机定位服务（GPS）';
          _statusText = _locationError!;
        });
        return;
      }
      // ③ 检查/请求权限
      var perm = await Geolocator.checkPermission().timeout(
        const Duration(seconds: 5),
      );
      if (perm == LocationPermission.denied) {
        perm = await Geolocator.requestPermission().timeout(
          const Duration(seconds: 30),
        );
        if (perm == LocationPermission.denied) {
          if (!mounted) return;
          setState(() {
            _locating = false;
            _position = null;
            _stations = [];
            _locationError = '定位权限被拒绝，请选择城市';
            _statusText = _locationError!;
          });
          return;
        }
      }
      if (perm == LocationPermission.deniedForever) {
        if (!mounted) return;
        setState(() {
          _locating = false;
          _position = null;
          _stations = [];
          _locationError = '定位权限已永久拒绝\n请在系统设置 → 应用权限中手动开启';
          _statusText = _locationError!;
        });
        return;
      }
      // ④ GPS 可用且权限正常时复用短期缓存，减少重复定位和耗电。
      if (allowCache) {
        final cached = await _readLocationCache();
        if (cached != null && mounted) {
          setState(() {
            _position = cached;
            _locating = false;
            _statusText = '使用最近定位结果';
          });
          await _searchNearby(cached.latitude, cached.longitude);
          return;
        }
      }
      // ⑤ 获取位置
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      ).timeout(const Duration(seconds: 8));
      await _writeLocationCache(pos);
      if (!mounted) return;
      setState(() {
        _position = pos;
        _locating = false;
        _statusText = '';
      });
      await _searchNearby(pos.latitude, pos.longitude);
    } on TimeoutException {
      if (_locateAttempt < 1) {
        _locateAttempt++;
        return _tryLocate(allowCache: false);
      }
      if (!mounted) return;
      setState(() {
        _locating = false;
        _position = null;
        _stations = [];
        _locationError = '定位超时，请选择省市区';
        _statusText = _locationError!;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _locating = false;
        _position = null;
        _stations = [];
        _locationError = '无法获取位置信息，请选择省市区';
        _statusText = _locationError!;
      });
    }
  }

  Future<Position?> _readLocationCache() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_locationCacheKey);
      if (raw == null) return null;
      final m = jsonDecode(raw) as Map;
      final at = DateTime.tryParse((m['at'] ?? '').toString());
      if (at == null || DateTime.now().difference(at).inHours > 6) return null;
      return Position(
        longitude: (m['lng'] as num).toDouble(),
        latitude: (m['lat'] as num).toDouble(),
        timestamp: at,
        accuracy: (m['accuracy'] as num?)?.toDouble() ?? 100,
        altitude: 0,
        altitudeAccuracy: 0,
        heading: 0,
        headingAccuracy: 0,
        speed: 0,
        speedAccuracy: 0,
      );
    } catch (_) {
      return null;
    }
  }

  Future<void> _writeLocationCache(Position pos) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _locationCacheKey,
      jsonEncode({
        'lat': pos.latitude,
        'lng': pos.longitude,
        'accuracy': pos.accuracy,
        'at': DateTime.now().toIso8601String(),
      }),
    );
  }

  // ═══════════════════════════════════════
  //  省市区三级级联选择器
  // ═══════════════════════════════════════
  void _showCascade() {
    HapticFeedback.selectionClick();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _CascadeSheet(
        onSelect: (lat, lng, name) {
          Navigator.pop(context);
          _searchAt(lat, lng, name);
        },
      ),
    );
  }

  // ═══════════════════════════════════════
  //  Haversine 距离
  // ═══════════════════════════════════════
  double _haversine(double lat1, double lon1, double lat2, double lon2) {
    const R = 6371000.0;
    final dLat = (lat2 - lat1) * math.pi / 180.0;
    final dLon = (lon2 - lon1) * math.pi / 180.0;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * math.pi / 180.0) *
            math.cos(lat2 * math.pi / 180.0) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  /// 给站点补齐直线距离（米），并按距离由近到远排序
  /// 在线（location:{lat,lng}）与离线（latitude/longitude）两种格式都兼容
  List<Map<String, dynamic>> _withDistance(List raw, double lat, double lng) {
    final list = raw.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    for (final s in list) {
      final slat = StationMap.latOf(s);
      final slng = StationMap.lngOf(s);
      s['_distance'] = (slat == 0 && slng == 0)
          ? double.infinity
          : _haversine(lat, lng, slat, slng);
    }
    list.sort(
      (a, b) => (a['_distance'] as num).compareTo(b['_distance'] as num),
    );
    return list;
  }

  /// 记录检索中心点，供地图标注与距离排序复用
  void _rememberCenter(double lat, double lng) {
    _centerLat = lat;
    _centerLng = lng;
  }

  /// 离线药店 按距离排序 → 半径过滤
  void _fallbackToOffline(double lat, double lng) {
    if (!_offlineLoaded || _offlineStations.isEmpty) {
      setState(() {
        _stations = [];
        _loading = false;
        _statusText = '暂无数据';
      });
      return;
    }
    final sorted = _withDistance(_offlineStations, lat, lng);
    final radiusM = int.tryParse(_radius) ?? 3000;
    final withinRadius =
        sorted.where((s) => (s['_distance'] as num) <= radiusM).toList();
    // 半径内为空时仍展示最近的 5 家，避免“匹配为空”阻断用户流程。
    final filtered =
        withinRadius.isNotEmpty ? withinRadius : sorted.take(5).toList();
    setState(() {
      _stations = filtered;
      _loading = false;
      _statusText = filtered.isEmpty
          ? '暂无离线药店数据，请手动打开地图搜索'
          : withinRadius.isEmpty
              ? '附近暂无药店，已展示最近 ${filtered.length} 家'
              : '离线数据 · 附近药店（${filtered.length}家）';
    });
  }

  // ═══════════════════════════════════════
  //  网络/离线 搜索
  // ═══════════════════════════════════════
  Future<void> _searchNearby(double lat, double lng) async {
    if (_isSearching) return;
    _isSearching = true;
    setState(() {
      _loading = true;
      _selectedIndex = -1;
    });
    _rememberCenter(lat, lng);
    try {
      final resp = await HttpUtils().get(
        '/position',
        params: {
          'latitude': lat.toString(),
          'longitude': lng.toString(),
          'radius': int.parse(_radius),
        },
      );
      if (resp.data['code'] == 200 && resp.data['data'] != null) {
        try {
          final json = jsonDecode(resp.data['data'] as String);
          final raw = (json['data'] as List?) ?? [];
          if (raw.isNotEmpty) {
            final sorted = _withDistance(raw, lat, lng);
            final radiusM = int.tryParse(_radius) ?? 3000;
            final filtered = sorted
                .where((s) => (s['_distance'] as num) <= radiusM)
                .toList();
            setState(() {
              _stations = filtered;
              _loading = false;
            });
            _isSearching = false;
            return;
          }
        } catch (_) {}
      }
    } catch (_) {}
    // fallback
    _fallbackToOffline(lat, lng);
    _isSearching = false;
  }

  Future<void> _searchAt(double lat, double lng, String name) async {
    HapticFeedback.lightImpact();
    setState(() {
      _loading = true;
      _selectedIndex = -1;
      _selectedName = name;
      _statusText = '搜索 $name…';
    });
    _rememberCenter(lat, lng);
    try {
      final resp = await HttpUtils().get(
        '/position',
        params: {'latitude': lat.toString(), 'longitude': lng.toString()},
      );
      if (resp.data['code'] == 200 && resp.data['data'] != null) {
        try {
          final json = jsonDecode(resp.data['data'] as String);
          final raw = (json['data'] as List?) ?? [];
          if (raw.isNotEmpty) {
            setState(() {
              _stations = _withDistance(raw, lat, lng);
              _loading = false;
              _statusText = '';
            });
            return;
          }
        } catch (_) {}
      }
    } catch (_) {}
    _fallbackToOffline(lat, lng);
  }

  /// 列表 → 地图：选中某项时地图居中高亮
  void _selectStation(int index) {
    HapticFeedback.selectionClick();
    setState(() => _selectedIndex = index);
    _showStationDetail(_stations[index]);
  }

  /// 地图 → 列表：点击标注时同步选中并弹出详情
  void _onMarkerTap(int index) {
    HapticFeedback.lightImpact();
    if (index < 0 || index >= _stations.length) return;
    setState(() => _selectedIndex = index);
    _showStationDetail(_stations[index]);
  }

  // ═══════════════════════════════════════
  //  知识
  // ═══════════════════════════════════════
  Future<void> _loadKnowledge() async {
    try {
      final resp = await HttpUtils().get('/knowledge/list');
      if (resp.data['code'] == 200) {
        final data = resp.data['data'];
        if (data is List) {
          setState(() => _articles = data.take(3).toList());
        } else if (data is Map) {
          final list = data['records'] ?? data['data'] ?? [];
          setState(() => _articles = (list as List).take(3).toList());
        }
      }
    } on DioException {
      setState(
        () => _articles = [
          {
            'id': 1,
            'title': '家庭过期药品的正确处理方式',
            'summary': '过期药品属于危险废物，请勿随意丢弃',
            'category': 'guide',
            'viewCount': 1280,
            'publishTime': '2026-06-20',
          },
          {
            'id': 2,
            'title': '国家药品回收政策解读',
            'summary': '梳理国家层面药品回收相关法规',
            'category': 'policy',
            'viewCount': 960,
            'publishTime': '2026-06-18',
          },
          {
            'id': 3,
            'title': '过期药品对环境的危害',
            'summary': '一粒过期药可污染数万吨水源',
            'category': 'science',
            'viewCount': 720,
            'publishTime': '2026-06-10',
          },
        ],
      );
    }
  }

  // ═══════════════════════════════════════
  //  外部地图 / 导航
  // ═══════════════════════════════════════
  Future<void> _openExternalMap({String? keyword}) async {
    HapticFeedback.mediumImpact();
    final kw = keyword ?? '药品回收点';
    for (final m in [
      'https://uri.amap.com/search?keyword=${Uri.encodeComponent(kw)}&callnative=1',
      'baidumap://map/search?query=${Uri.encodeComponent(kw)}',
      'qqmap://map/search?keyword=${Uri.encodeComponent(kw)}',
    ]) {
      final uri = Uri.parse(m);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        return;
      }
    }
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('请安装地图 App')));
    }
  }

  Future<void> _navigateTo(double lat, double lng, String name) async {
    HapticFeedback.lightImpact();
    final uri = Uri.parse(
      'https://uri.amap.com/marker?position=$lng,$lat&name=${Uri.encodeComponent(name)}&callnative=1',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('请安装地图 App')));
    }
  }

  IconData _typeIcon(dynamic tel, String? title) {
    final t = (title ?? '') + (tel?.toString() ?? '');
    if (t.contains('医院')) return Icons.local_hospital;
    if (t.contains('社区') || t.contains('卫生')) return Icons.home_work;
    if (t.contains('慈善') || t.contains('红会')) return Icons.volunteer_activism;
    return Icons.medication;
  }

  String _catLabel(String? cat) {
    const map = {
      'policy': '政策法规',
      'guide': '回收指南',
      'science': '科普知识',
      'news': '行业资讯',
    };
    return map[cat] ?? cat ?? '';
  }

  Color _catColor(String? cat) {
    const map = {
      'policy': AppSemantic.categoryPolicy,
      'guide': AppColors.primary,
      'science': AppSemantic.categoryScience,
      'news': AppColors.warning,
    };
    return map[cat] ?? AppColors.muted;
  }

  // ═══════════════════════════════════════
  //  UI
  // ═══════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    final locationError = _locationError;
    return AppBackground(
      overlayColor: Colors.white,
      overlayOpacity: 0.08,
      child: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: () async {
          if (_position != null) {
            await _searchNearby(_position!.latitude, _position!.longitude);
          } else {
            await _tryLocate();
          }
          await _loadKnowledge();
        },
        child: ListView(
          controller: _scrollCtrl,
          padding: const EdgeInsets.all(16),
          children: [
            // ── 一键外部地图卡片 ──
            GestureDetector(
              onTap: () => _openExternalMap(),
              child: Container(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [AppSemantic.categoryPolicy, AppColors.infoLight],
                    begin: Alignment.topLeft,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: AppSemantic.categoryPolicy.withValues(alpha: 0.25),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(20),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(20),
                    onTap: () => _openExternalMap(),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.2),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: DesignIcons.mapIcon(
                              size: 26,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(width: 14),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '打开地图查找回收点',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: AppText.sizeTitle,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                Text(
                                  '一键跳转高德/百度/腾讯地图',
                                  style: TextStyle(
                                    color: Colors.white70,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Text(
                              '打开 →',
                              style: TextStyle(
                                color: AppSemantic.categoryPolicy,
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),

            // ── 定位中 ──
            if (_locating)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primaryTintWeak,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppColors.primary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        '正在定位...',
                        style: TextStyle(color: AppColors.primary),
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        HapticFeedback.selectionClick();
                        setState(() => _locating = false);
                        _showCascade();
                      },
                      child: const Text(
                        '跳过',
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            // ── 定位成功 → 半径调节 ──
            if (!_locating && _position != null)
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: AppColors.primaryTintWeak,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  children: [
                    DesignIcons.location(
                      size: 16,
                      color: AppColors.primary,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      '范围：',
                      style: TextStyle(fontSize: 13, color: AppColors.primary),
                    ),
                    for (final r in [
                      ['1km', '1000'],
                      ['3km', '3000'],
                      ['5km', '5000'],
                    ])
                      Padding(
                        padding: const EdgeInsets.only(left: 6),
                        child: ChoiceChip(
                          selected: _radius == r[1],
                          label: Text(
                            r[0],
                            style: const TextStyle(fontSize: 12),
                          ),
                          selectedColor: AppColors.primary,
                          labelStyle: TextStyle(
                            color: _radius == r[1]
                                ? Colors.white
                                : Colors.grey[700],
                          ),
                          onSelected: (_) {
                            HapticFeedback.lightImpact();
                            setState(() => _radius = r[1]);
                            if (_position != null)
                              _searchNearby(
                                _position!.latitude,
                                _position!.longitude,
                              );
                          },
                          padding: EdgeInsets.zero,
                          materialTapTargetSize:
                              MaterialTapTargetSize.shrinkWrap,
                        ),
                      ),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => _openExternalMap(),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 7,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Text(
                          '查看',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            // ── 定位失败 → 省市区选择 ──
            if (!_locating && (_position == null || locationError != null))
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.warningTint,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        DesignIcons.info(
                          size: 16,
                          color: AppColors.warning,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            locationError ??
                                (_statusText.isNotEmpty
                                    ? _statusText
                                    : 'GPS 定位失败，请选择省市区'),
                            style: const TextStyle(
                              color: AppColors.warning,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _showCascade,
                        icon: DesignIcons.location(
                          size: 18,
                          color: AppColors.primary,
                        ),
                        label: const Text(
                          '选择省市区查找',
                          style: TextStyle(fontSize: 14),
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: AppColors.primary,
                          side: const BorderSide(color: AppColors.primary),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

            const SizedBox(height: 16),

            // ── 状态文字 ──
            if (_statusText.isNotEmpty && !_locating && locationError == null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(
                  _statusText,
                  style: TextStyle(color: AppColors.ink3, fontSize: 13),
                  textAlign: TextAlign.center,
                ),
              ),
            if (_loading)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: CircularProgressIndicator(color: AppColors.primary),
                ),
              ),

            // ── 地图点位（与下方列表联动）──
            if (!_loading && _stations.isNotEmpty) ...[
              StationMap(
                stations: _stations
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                userLat: _position?.latitude ??
                    (_centerLat != 0 ? _centerLat : null),
                userLng: _position?.longitude ??
                    (_centerLng != 0 ? _centerLng : null),
                selectedIndex: _selectedIndex,
                onMarkerTap: _onMarkerTap,
              ),
              const SizedBox(height: 14),
            ],

            // ── 回收点列表（按距离由近到远）──
            if (!_loading && _stations.isNotEmpty) ...[
              Row(
                children: [
                  const Text(
                    '附近回收点',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.primaryTintWeak,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${_stations.length} 家 · 按距离排序',
                      style: const TextStyle(
                        fontSize: AppText.sizeCaption,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ..._stations.asMap().entries.map(
                    (e) => _stationCard(e.key, e.value as Map),
                  ),
            ],

            // ── 空状态 ──
            if (!_loading && _stations.isEmpty && !_locating)
              Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      DesignIcons.mapIcon(size: 64, color: Colors.grey[400]!),
                      const SizedBox(height: 12),
                      Text(
                        _selectedName.isEmpty
                            ? '请选择城市或打开地图'
                            : '$_selectedName 暂无回收点',
                        style: TextStyle(fontSize: 16, color: AppColors.ink3),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '离线数据库覆盖全国31省主要连锁药店',
                        style: TextStyle(fontSize: 12, color: AppColors.muted),
                      ),
                    ],
                  ),
                ),
              ),

            // ── 知识科普 ──
            if (_articles.isNotEmpty) ...[
              const SizedBox(height: 20),
              Row(
                children: [
                  const Text(
                    '回收知识',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => AppRoutes.toKnowledge(context),
                    child: const Text(
                      '更多 →',
                      style: TextStyle(color: AppColors.primary),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              ..._articles.take(3).map((a) => _articleCard(a)),
            ],

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  // ═══════════════════════════════════════
  //  回收点卡片（兼容在线/离线格式）
  // ═══════════════════════════════════════
  Widget _stationCard(int index, Map s) {
    final title = (s['title'] ?? s['name'] ?? '回收点').toString();
    final address = (s['address'] ?? '').toString();
    final lat = StationMap.latOf(s);
    final lng = StationMap.lngOf(s);
    final rawDist = (s['_distance'] ?? s['_d']);
    final distance = rawDist is num ? rawDist.toDouble() : 0.0;
    final km = GeoUtils.formatDistance(distance);
    final tel = (s['tel'] ?? '').toString();
    final selected = index == _selectedIndex;

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: selected ? AppColors.primaryTintWeak : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: selected
            ? Border.all(color: AppColors.primaryLight, width: 1.5)
            : null,
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => _selectStation(index),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: selected
                        ? AppColors.primary
                        : AppColors.primaryTintWeak,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: Icon(
                      _typeIcon(tel, title),
                      size: 24,
                      color: selected ? Colors.white : AppColors.primary,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        address,
                        style: TextStyle(fontSize: 13, color: AppColors.ink3),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: AppColors.primaryTintWeak,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: const Text(
                          '可回收药品',
                          style: TextStyle(
                            fontSize: AppText.sizeCaption,
                            color: AppColors.primary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.primaryTintWeak,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        km,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    GestureDetector(
                      onTap: () => _navigateTo(lat, lng, title),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: DesignIcons.navigation(
                          size: 16,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showStationDetail(Map s) {
    final title = (s['title'] ?? s['name'] ?? '').toString();
    final address = (s['address'] ?? '').toString();
    final lat = StationMap.latOf(s);
    final lng = StationMap.lngOf(s);
    final rawDist = (s['_distance'] ?? s['_d']);
    final distance = rawDist is num ? rawDist.toDouble() : 0.0;
    final tel = (s['tel'] ?? '').toString();
    final chain = (s['chain'] ?? '').toString();

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              GeoUtils.formatDistance(distance),
              style: TextStyle(color: AppColors.ink3),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                DesignIcons.locationOutlined(size: 16, color: AppColors.ink3),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(address, style: const TextStyle(fontSize: 14)),
                ),
              ],
            ),
            if (tel.isNotEmpty) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.phone, size: 16, color: AppColors.ink3),
                  const SizedBox(width: 10),
                  Text(tel, style: const TextStyle(fontSize: 14)),
                ],
              ),
            ],
            if (chain.isNotEmpty) ...[
              const SizedBox(height: 8),
              Row(
                children: [
                  DesignIcons.eco(size: 16, color: AppColors.ink3),
                  const SizedBox(width: 10),
                  Text('连锁品牌：$chain', style: const TextStyle(fontSize: 14)),
                ],
              ),
            ],
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () => _navigateTo(lat, lng, title),
                icon: DesignIcons.navigation(size: 18),
                label: const Text('开始导航'),
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _articleCard(Map a) {
    final cat = a['category'] as String?;
    final catLabel = _catLabel(cat);
    final catColor = _catColor(cat);
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 4),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => AppRoutes.toKnowledge(context),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: catColor.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          catLabel,
                          style: TextStyle(fontSize: AppText.sizeCaption, color: catColor),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        a['title'] ?? '',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        a['summary'] ?? '',
                        style: const TextStyle(
                          fontSize: AppText.sizeCaption,
                          color: AppColors.muted,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                DesignIcons.chevronRight(size: 18, color: AppColors.ink3),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════
//  省→市→区 三级级联底部弹出选择器
// ═══════════════════════════════════════════════════
class _CascadeSheet extends StatefulWidget {
  final void Function(double lat, double lng, String name) onSelect;
  const _CascadeSheet({required this.onSelect});
  @override
  State<_CascadeSheet> createState() => _CascadeSheetState();
}

class _CascadeSheetState extends State<_CascadeSheet> {
  int? _sp, _sc;
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height * 0.75;
    final provinces = chinaRegionData;
    final query = _normalizeRegionQuery(_q);

    List filtered = provinces;
    if (query.isNotEmpty) {
      filtered = [];
      for (final p in provinces) {
        final provinceName = p['n'] as String;
        final provinceHit = _regionMatches(provinceName, query);
        List mc = [];
        for (final c in (p['c'] as List)) {
          final cityName = c['n'] as String;
          final cityHit = _regionMatches(cityName, query);
          final md = (c['d'] as List)
              .where((d) => _regionMatches(d['n'] as String, query))
              .toList();
          if (provinceHit || cityHit || md.isNotEmpty) {
            mc.add({'n': cityName, 'd': provinceHit || cityHit ? c['d'] : md});
          }
        }
        if (provinceHit || mc.isNotEmpty) {
          filtered.add({'n': provinceName, 'c': mc.isNotEmpty ? mc : p['c']});
        }
      }
    }

    return Container(
      height: h,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    style: const TextStyle(
                      color: AppColors.ink,
                      fontSize: 14,
                    ),
                    decoration: InputDecoration(
                      hintText: '搜索省/市/区',
                      hintStyle: const TextStyle(
                        color: AppColors.muted,
                        fontSize: 14,
                      ),
                      prefixIcon: const Icon(
                        Icons.search,
                        color: AppColors.primary,
                        size: 20,
                      ),
                      filled: true,
                      fillColor: AppColors.subtleBg,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 10,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    onChanged: (v) => setState(() {
                      _q = v;
                      _sp = null;
                      _sc = null;
                    }),
                  ),
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: AppColors.subtleBg,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(
                      Icons.close,
                      size: 18,
                      color: AppColors.ink3,
                    ),
                  ),
                ),
              ],
            ),
          ),
          // 面包屑
          if (_sp != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => setState(() {
                      _sp = null;
                      _sc = null;
                    }),
                    child: Text(
                      '${provinces[_sp!]['n']} › ',
                      style: const TextStyle(
                        color: AppColors.primary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  if (_sc != null)
                    GestureDetector(
                      onTap: () => setState(() {
                        _sc = null;
                      }),
                      child: Text(
                        '${(provinces[_sp!]['c'] as List)[_sc!]['n']} › ',
                        style: const TextStyle(
                          color: AppColors.primary,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.only(bottom: 20),
              children: [
                if (_sp == null)
                  ...filtered.asMap().entries.map(
                        (e) => _tile(
                          e.value['n'] as String,
                          '${(e.value['c'] as List).length} 个城市',
                          () {
                            HapticFeedback.selectionClick();
                            setState(() {
                              _sp = provinces.indexWhere(
                                (p) => p['n'] == e.value['n'],
                              );
                              _sc = null;
                            });
                          },
                        ),
                      )
                else if (_sc == null) ...[
                  for (final c
                      in (provinces[_sp!]['c'] as List).asMap().entries)
                    _tile(
                      c.value['n'] as String,
                      '${(c.value['d'] as List).length} 个区县',
                      () {
                        HapticFeedback.selectionClick();
                        setState(() => _sc = c.key);
                      },
                    ),
                ] else ...[
                  for (final d
                      in ((provinces[_sp!]['c'] as List)[_sc!]['d'] as List))
                    _tile(d['n'] as String, '点击选择此区域', () {
                      HapticFeedback.selectionClick();
                      widget.onSelect(
                        (d['t'] as num).toDouble(),
                        (d['g'] as num).toDouble(),
                        d['n'] as String,
                      );
                    }),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _normalizeRegionQuery(String value) {
    final q = value.trim().replaceAll(' ', '');
    if (q.isEmpty) return '';
    return chinaRegionAliases[q] ?? q;
  }

  bool _regionMatches(String name, String query) {
    final normalizedName = name.replaceAll(' ', '');
    if (normalizedName.contains(query) || query.contains(normalizedName)) {
      return true;
    }
    final alias = chinaRegionAliases.entries
        .where((entry) => entry.value == name)
        .map((entry) => entry.key.replaceAll(' ', ''));
    return alias.any((item) => item.contains(query) || query.contains(item));
  }

  Widget _tile(String title, String sub, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 3),
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 15,
                            color: AppColors.ink,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          sub,
                          style:
                              const TextStyle(fontSize: 12, color: AppColors.muted),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: AppColors.ink3, size: 20),
                ],
              ),
            ),
          ),
        ),
      );
}
