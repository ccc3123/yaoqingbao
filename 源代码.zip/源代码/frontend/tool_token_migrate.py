#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 lib/ 下硬编码的 Color(0x........) 迁移到 theme/ 的语义 token。

用法：
    python tool_token_migrate.py          # dry-run，只报告
    python tool_token_migrate.py --apply  # 实际改写

设计要点：
  · 语义敏感的颜色（AI 标识 / 知识分类 / 数据来源 / 风险标记）按文件覆盖映射，
    避免把承载信息含义的颜色统一掉；
  · 同时把已废弃的 withOpacity(x) 换成 withValues(alpha: x)；
  · 改写后自动补 theme/app_colors.dart 的 import。
"""
import os
import re
import sys

LIB = "lib"
# token 定义文件自身：色值就该写在这里，不参与迁移。
SKIP_FILES = {"lib/theme/app_colors.dart", "lib/theme/app_text.dart"}

# ── 全局映射：hex(不含0x) → token 表达式 ──
GLOBAL = {
    # 品牌绿
    "FF2D8A41": "AppColors.primary",
    "FF2E7D32": "AppColors.primary",
    "FF388E3C": "AppColors.primary",
    "FF1B5E20": "AppColors.primaryStrong",
    "FF146322": "AppColors.primaryStrong",
    "FF33691E": "AppColors.primaryStrong",
    "FF0D5018": "AppColors.primaryDark",
    "FF004D40": "AppColors.primaryDark",
    "FF0A3D12": "AppColors.primaryDeepest",
    "FF43A047": "AppColors.primaryLight",
    "FF4CAF50": "AppColors.primaryLight",
    "FF3E9E54": "AppColors.primaryLight",
    "FF67B378": "AppColors.primaryPale",
    "FF81C784": "AppColors.primaryPale",
    "FFA5D6A7": "AppColors.primaryPale",
    "FF8FC89C": "AppColors.primaryPale",
    "FFA8E8B0": "AppColors.onDarkMint",
    "FFC8E6C9": "AppColors.primaryTint",
    "FFE8F5E9": "AppColors.primaryTintWeak",
    "FFF1F8E9": "AppColors.primaryTintWeak",
    "FFF3FDF5": "AppColors.primaryTintWeak",
    # 中性灰
    "FF333333": "AppColors.ink",
    "FF1F2328": "AppColors.ink",
    "FF1F2937": "AppColors.ink",
    "FF444444": "AppColors.ink2",
    "FF374151": "AppColors.ink2",
    "FF555555": "AppColors.ink3",
    "FF666666": "AppColors.ink3",
    "FF5B6573": "AppColors.ink3",
    "FF4B5563": "AppColors.ink3",
    "FF8A8A8A": "AppColors.muted",
    "FF757575": "AppColors.muted",
    "FF6E8070": "AppColors.muted",
    "FF6B7280": "AppColors.muted",
    "FFE5E7EB": "AppColors.divider",
    "FFE0E0E0": "AppColors.divider",
    "FFEEEEEE": "AppColors.divider",
    "FFD1D5DB": "AppColors.divider",
    "FFF8F9FA": "AppColors.subtleBg",
    "FFF5F7FF": "AppColors.subtleBg",
    "FFF3F4F6": "AppColors.subtleBg",
    "FFF7FAF8": "AppColors.surface",
    "FFF2F6F3": "AppColors.surface",
    "FFFFFFFF": "AppColors.card",
    # 危险
    "FFD32F2F": "AppColors.danger",
    "FFC62828": "AppColors.danger",
    "FFB71C1C": "AppColors.danger",
    "FFB42318": "AppColors.danger",
    "FFFF5252": "AppColors.danger",
    "FFFFEBEE": "AppColors.dangerTint",
    "FFFFCDD2": "AppColors.dangerTint",
    "FFFFF3F3": "AppColors.dangerTint",
    "FFFF8A80": "AppColors.onDarkDanger",
    # 警告
    "FFE65100": "AppColors.warning",
    "FFEF6C00": "AppColors.warning",
    "FFF9A825": "AppColors.warning",
    "FFFF8F00": "AppColors.warning",
    "FFFFB300": "AppColors.warning",
    "FF8A5300": "AppColors.warning",
    "FFFFF3E0": "AppColors.warningTint",
    "FFFFF8E1": "AppColors.warningTint",
    "FFFFE0B2": "AppColors.warningTint",
    "FFFFE082": "AppColors.warningTint",
    "FFFFD54F": "AppColors.onDarkWarning",
    # 信息
    "FF1565C0": "AppColors.info",
    "FF1F4E79": "AppColors.info",
    "FF42A5F5": "AppColors.infoLight",
    "FFE3F2FD": "AppColors.infoTint",
    # AI 标识（原 #7C4DFF 艳紫与 #5C6BC0 靛蓝表达同一概念，统一为靛蓝）
    "FF7C4DFF": "AppSemantic.ai",
    "FF5C6BC0": "AppSemantic.ai",
    "FFB39DDB": "AppSemantic.ai",
    "FF283593": "AppSemantic.aiStrong",
    "FF241B6B": "AppSemantic.aiStrong",
    "FFDCE3FF": "AppSemantic.aiTint",
    "FFD1C4E9": "AppSemantic.aiTint",
    "FFEDF3FF": "AppSemantic.aiTint",
    # 其他语义
    "FF7B1FA2": "AppSemantic.categoryScience",
    "FFF3E5F5": "AppSemantic.categoryScienceTint",
    "FF8D6E63": "AppSemantic.sourceLocal",
}

# ── 文件级覆盖：同一色值在不同文件承载不同信息含义 ──
OVERRIDE = {
    # 数据来源徽标：三档颜色 = 三种可信度
    "lib/widgets/source_badge.dart": {
        "FF2D8A41": "AppSemantic.sourceOfficial",
        "FF7B1FA2": "AppSemantic.sourceAi",
        "FF283593": "AppSemantic.sourceMixed",
    },
    # 知识分类三色
    "lib/routes/knowledge_page.dart": {
        "FF1565C0": "AppSemantic.categoryPolicy",
        "FF2E7D32": "AppSemantic.categoryGuide",
    },
    "lib/routes/knowledge_detail_page.dart": {
        "FF1565C0": "AppSemantic.categoryPolicy",
        "FF2E7D32": "AppSemantic.categoryGuide",
    },
    "lib/pages/guichu_page.dart": {
        "FF1565C0": "AppSemantic.categoryPolicy",
        "FF2E7D32": "AppSemantic.categoryGuide",
    },
    # 用药风险：重复成分 / 相互作用
    "lib/widgets/medicine_safety.dart": {
        "FF7B1FA2": "AppSemantic.conflict",
    },
}

# 被 ClipRRect 裁掉、渲染不出来的无效阴影色，直接连同 boxShadow 一起留给人工处理，
# 这里只统计不改写。
DEAD = {"1F2E7D32"}

COLOR_RE = re.compile(r"(const\s+)?Color\(0x([0-9A-Fa-f]{8})\)")
OPACITY_RE = re.compile(r"\.withOpacity\(")


def norm(path):
    return path.replace(os.sep, "/")


def needs_semantic(text):
    return "AppSemantic." in text


def ensure_import(text, path):
    """补 theme/app_colors.dart 的 import（该文件同时导出 AppColors 与 AppSemantic）。"""
    if "theme/app_colors.dart" in text:
        return text, False
    depth = norm(path).count("/") - 1  # lib/ 之下的层数
    prefix = "../" * (depth - 0) if depth > 0 else ""
    rel = "%stheme/app_colors.dart" % prefix
    stmt = "import '%s';\n" % rel

    lines = text.split("\n")
    last_import = -1
    for i, line in enumerate(lines):
        if line.startswith("import "):
            last_import = i
    if last_import >= 0:
        lines.insert(last_import + 1, stmt.rstrip("\n"))
    else:
        # 没有任何 import：插在文件头部（跳过前导注释与 library 指令）
        idx = 0
        for i, line in enumerate(lines):
            s = line.strip()
            if s.startswith("///") or s.startswith("//") or s == "" or s.startswith("library"):
                idx = i + 1
            else:
                break
        lines.insert(idx, stmt.rstrip("\n"))
    return "\n".join(lines), True


def process(path, apply):
    with open(path, encoding="utf-8") as fh:
        original = fh.read()

    rel = norm(path)
    table = dict(GLOBAL)
    table.update(OVERRIDE.get(rel, {}))

    stats = {"color": 0, "opacity": 0, "unmapped": [], "dead": 0}

    def sub_color(m):
        hexs = m.group(2).upper()
        if hexs in DEAD:
            stats["dead"] += 1
            return m.group(0)
        token = table.get(hexs)
        if token is None:
            stats["unmapped"].append(hexs)
            return m.group(0)
        stats["color"] += 1
        return token

    text = COLOR_RE.sub(sub_color, original)

    # withOpacity(x) → withValues(alpha: x)
    def sub_op(_m):
        stats["opacity"] += 1
        return ".withValues(alpha: "

    text = OPACITY_RE.sub(sub_op, text)

    added_import = False
    if stats["color"] and text != original:
        text, added_import = ensure_import(text, rel)

    if apply and text != original:
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)

    return stats, added_import, text != original


def main():
    apply = "--apply" in sys.argv
    total = {"color": 0, "opacity": 0, "files": 0, "imports": 0, "dead": 0}
    unmapped = {}

    for root, _dirs, files in os.walk(LIB):
        for fn in sorted(files):
            if not fn.endswith(".dart"):
                continue
            path = os.path.join(root, fn)
            if norm(path) in SKIP_FILES:
                continue
            stats, added, changed = process(path, apply)
            for h in stats["unmapped"]:
                unmapped[h] = unmapped.get(h, 0) + 1
            if changed:
                total["files"] += 1
                total["color"] += stats["color"]
                total["opacity"] += stats["opacity"]
                total["dead"] += stats["dead"]
                if added:
                    total["imports"] += 1
                print(
                    "  %-46s color:%-4d opacity:%-3d %s"
                    % (norm(path), stats["color"], stats["opacity"], "+import" if added else "")
                )

    print()
    print("模式: %s" % ("APPLY 已写入" if apply else "DRY-RUN 未改动"))
    print("改动文件 %d 个 | 颜色替换 %d 处 | withOpacity→withValues %d 处 | 补 import %d 个"
          % (total["files"], total["color"], total["opacity"], total["imports"]))
    if total["dead"]:
        print("跳过无效阴影色 %d 处（被 ClipRRect 裁掉，留待人工删除）" % total["dead"])
    if unmapped:
        print("未映射色值 %d 种：" % len(unmapped))
        for h, n in sorted(unmapped.items(), key=lambda kv: -kv[1]):
            print("    #%s  %d 处" % (h, n))


if __name__ == "__main__":
    main()

