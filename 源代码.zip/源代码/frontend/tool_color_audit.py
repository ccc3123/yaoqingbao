#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""审计 lib/ 下所有硬编码 Color(0x........)，按色相族分组并算白底对比度。

只读，不改文件。用于制定 token 映射表。
"""
import collections
import os
import re

PAT = re.compile(r"Color\(0x([0-9A-Fa-f]{8})\)")


def rel(root, fn):
    return os.path.join(root, fn).replace(os.sep, "/").lstrip("./")


def scan(base="lib"):
    usage = collections.defaultdict(list)
    for root, _dirs, files in os.walk(base):
        for fn in files:
            if not fn.endswith(".dart"):
                continue
            path = os.path.join(root, fn)
            with open(path, encoding="utf-8") as fh:
                for line in fh:
                    for m in PAT.finditer(line):
                        usage[m.group(1).upper()].append(rel(root, fn))
    return usage


def _chan(c):
    c /= 255.0
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def luminance(hexs):
    r, g, b = int(hexs[2:4], 16), int(hexs[4:6], 16), int(hexs[6:8], 16)
    return 0.2126 * _chan(r) + 0.7152 * _chan(g) + 0.0722 * _chan(b)


def contrast_on_white(hexs):
    return round(1.05 / (luminance(hexs) + 0.05), 2)


def family(hexs):
    r, g, b = int(hexs[2:4], 16), int(hexs[4:6], 16), int(hexs[6:8], 16)
    if max(r, g, b) - min(r, g, b) < 20:
        return "GRAY"
    if g >= r and g >= b:
        return "GREEN"
    if b >= r and b >= g:
        return "BLUE/PURPLE"
    if r >= g and r >= b:
        return "AMBER/ORANGE" if g > b + 30 else "RED/PINK"
    return "OTHER"


def main():
    usage = scan()
    groups = collections.defaultdict(list)
    for hexs, files in usage.items():
        groups[family(hexs)].append((hexs, files))

    order = ["GREEN", "GRAY", "RED/PINK", "AMBER/ORANGE", "BLUE/PURPLE", "OTHER"]
    total = 0
    for fam in order:
        items = groups.get(fam)
        if not items:
            continue
        items.sort(key=lambda kv: -len(kv[1]))
        n_occ = sum(len(v) for _, v in items)
        total += n_occ
        print("=" * 96)
        print("%s  — %d 种色值 / %d 处使用" % (fam, len(items), n_occ))
        print("=" * 96)
        print("%-11s %4s %8s  %s" % ("HEX", "N", "白底对比", "使用最多的文件"))
        for hexs, files in items:
            cnt = collections.Counter(files)
            top = ", ".join(
                "%s(%d)" % (os.path.basename(f), c) for f, c in cnt.most_common(2)
            )
            label = "#" + (hexs[2:] if hexs[:2] == "FF" else hexs)
            print("%-11s %4d %8s  %s" % (label, len(files), contrast_on_white(hexs), top[:60]))
        print()

    print("TOTAL distinct=%d  occurrences=%d" % (len(usage), total))


if __name__ == "__main__":
    main()
