# 平台权限配置指南

## Android

### android/app/src/main/AndroidManifest.xml

```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.INTERNET" />
```

minSdkVersion 21, targetSdkVersion 33

## iOS

### ios/Runner/Info.plist

```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>需要使用位置信息查找附近药品回收点</string>
<key>NSCameraUsageDescription</key>
<string>需要使用相机扫描药品条码</string>
```
