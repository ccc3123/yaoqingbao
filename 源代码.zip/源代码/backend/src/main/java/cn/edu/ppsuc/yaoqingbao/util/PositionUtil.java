package cn.edu.ppsuc.yaoqingbao.util;

import cn.edu.ppsuc.yaoqingbao.data.po.Position;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 腾讯地图 API 工具类
 * 用于搜索附近回收点/药店
 */
@Component
public class PositionUtil {

    private static final Logger log = LoggerFactory.getLogger(PositionUtil.class);

    @Value("${app.map.key}")
    private String mapKey;

    @Value("${app.map.host}")
    private String host;

    /**
     * 搜索附近地点
     *
     * @param keyword  搜索关键词（如 "药店"、"回收站"）
     * @param position 中心点坐标+搜索半径
     */
    public Result search(String keyword, Position position) {
        String path = "/ws/place/v1/search";
        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");

        Map<String, String> querys = new HashMap<>();
        querys.put("key", mapKey);
        querys.put("keyword", keyword);
        querys.put("boundary", position.toString());
        querys.put("page_size", "20");

        try {
            HttpResponse response = HttpUtils.doGet(host, path, headers, querys);
            String body = EntityUtils.toString(response.getEntity());
            return new Result(200, body, "success");
        } catch (Exception e) {
            log.error("地图搜索失败: keyword={}, position={}", keyword, position, e);
            return new Result(500, null, "地图服务异常: " + e.getMessage());
        }
    }

    /**
     * 搜索附近多种类型的回收点
     */
    public Result searchNearbyStations(String latitude, String longitude, int radius) {
        // 合并搜索多种关键词：药店 + 医院 + 社区卫生
        Position position = new Position(
                new java.math.BigDecimal(latitude),
                new java.math.BigDecimal(longitude),
                radius
        );

        // 主要搜索药店
        return search("药店|回收站|社区卫生服务中心", position);
    }
}
