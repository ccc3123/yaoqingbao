package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.Position;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.util.PositionUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * 附近回收点搜索控制器
 */
@RestController
@RequestMapping("/position")
@Tag(name = "附近搜索", description = "搜索附近回收点/药店")
public class PositionController {

    @Autowired private PositionUtil positionUtil;

    @GetMapping
    @Operation(summary = "搜索附近回收点（多类型合并）")
    public Result getStations(
            @Parameter(description = "纬度") @RequestParam String latitude,
            @Parameter(description = "经度") @RequestParam String longitude,
            @Parameter(description = "搜索半径(米)") @RequestParam(defaultValue = "3000") int radius) {
        return positionUtil.searchNearbyStations(latitude, longitude, radius);
    }

    @GetMapping("/detail")
    @Operation(summary = "按关键词搜索附近")
    public Result searchByKeyword(
            @Parameter(description = "纬度") @RequestParam String latitude,
            @Parameter(description = "经度") @RequestParam String longitude,
            @Parameter(description = "关键词") @RequestParam(defaultValue = "药店") String keyword,
            @Parameter(description = "搜索半径") @RequestParam(defaultValue = "3000") int radius) {
        Position pos = new Position(new BigDecimal(latitude), new BigDecimal(longitude), radius);
        return positionUtil.search(keyword, pos);
    }
}
