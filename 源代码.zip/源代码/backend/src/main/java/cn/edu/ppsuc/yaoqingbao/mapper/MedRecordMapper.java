package cn.edu.ppsuc.yaoqingbao.mapper;

import cn.edu.ppsuc.yaoqingbao.data.po.MedRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 服药记录 Mapper
 */
@Mapper
public interface MedRecordMapper extends BaseMapper<MedRecord> {
}
