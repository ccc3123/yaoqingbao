package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 匿名回收记录
 * 仅存储品类+数量+回收点，不含任何个人信息
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("recycle_record")
public class RecycleRecord implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 药品品类 */
    private String drugCategory;

    /** 回收数量 */
    private Integer quantity;

    /** 回收类型: reusable=可再利用, disposable=待销毁 */
    private String recycleType;

    /** 回收点 ID */
    private Long stationId;

    /** 核验码 nonce（一次性，防重放） */
    private String nonce;

    /** 回收时间 */
    private LocalDateTime recycleTime;
}
