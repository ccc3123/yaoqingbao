package cn.edu.ppsuc.yaoqingbao.util;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * JWT 工具类 —— 账号体系令牌签发与解析。
 *
 * HS256 对称签名，密钥来自常量；生产环境务必改为外部注入并轮换。
 * 参考猎诈智脑的 JWT 鉴权模式（auth_router.py + src/auth.py）。
 */
public class JwtUtil {

    /** 签名密钥（生产环境应改为环境变量注入） */
    private static final String SECRET = "yaoqingbao-jwt-secret-2026-medrecycle";

    /** 令牌有效期：7 天 */
    private static final long EXPIRE_MS = 7L * 24 * 3600 * 1000;

    private static final SecretKey KEY =
            Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));

    private JwtUtil() {
    }

    /** 签发令牌，subject 为用户 ID，附带手机号 claim */
    public static String issue(Long userId, String phone) {
        return Jwts.builder()
                .subject(String.valueOf(userId))
                .claim("phone", phone)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + EXPIRE_MS))
                .signWith(KEY)
                .compact();
    }

    /** 解析令牌拿用户 ID；非法/过期一律返回 null，由调用方决定降级 */
    public static Long parseUserId(String token) {
        if (token == null || token.isEmpty()) return null;
        try {
            String subject = Jwts.parser()
                    .verifyWith(KEY)
                    .build()
                    .parseSignedClaims(token)
                    .getPayload()
                    .getSubject();
            return Long.parseLong(subject);
        } catch (Exception e) {
            return null;
        }
    }
}
