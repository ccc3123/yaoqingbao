package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.Station;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.StationMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 回收点信息控制器
 */
@RestController
@RequestMapping("/station")
@Tag(name = "回收点", description = "查看合作回收点信息")
public class StationController {

    @Autowired private StationMapper stationMapper;

    @GetMapping("/list")
    @Operation(summary = "获取全部运营中回收点")
    public Result list(@Parameter(description = "类型筛选") @RequestParam(required = false) String type) {
        List<Station> list = (type != null && !type.isEmpty())
                ? stationMapper.findByType(type)
                : stationMapper.findAllActive();
        return Result.success(list, "获取成功");
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取回收点详情")
    public Result detail(@Parameter(description = "回收点ID") @PathVariable Long id) {
        Station s = stationMapper.selectById(id);
        if (s == null || !"active".equals(s.getStatus()))
            return Result.notFound("回收点不存在");
        return Result.success(s, "获取成功");
    }
}
