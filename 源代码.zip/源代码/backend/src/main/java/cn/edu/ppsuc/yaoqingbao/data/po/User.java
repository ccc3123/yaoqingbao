package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 用户（账号体系：手机号验证码登录，混合双入口）
 *
 * 最小化采集：仅手机号 + 昵称，不采集姓名/性别/年龄等，
 * 健康档案（问卷）只存客户端本机，不上传后端，延续隐私定位。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("`user`")
public class User implements Serializable {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 手机号（唯一，作登录账号） */
    private String phone;

    /** 昵称（默认取手机号尾号） */
    private String nickname;
}
