package cn.edu.ppsuc.yaoqingbao.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.Contact;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * SpringDoc OpenAPI 配置
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("药清宝 V2 - 药品回收公益信息平台")
                        .version("2.0.0")
                        .description("零账户 · 零交易 · 零个人信息收集\n"
                                + "纯公益工具，连接公众与正规药品回收渠道")
                        .contact(new Contact()
                                .name("中国人民公安大学 孙铭泽团队")
                                .email("693023664@qq.com")));
    }
}
