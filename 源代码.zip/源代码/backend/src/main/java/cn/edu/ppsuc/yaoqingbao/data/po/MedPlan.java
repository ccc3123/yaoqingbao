package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 服药计划（家庭共享）
 *
 * 计划含每日服药时间点，客户端据此把闹钟写入系统日历；
 * 家庭共享后各成员在自己手机日历看到相同的服药提醒。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("med_plan")
public class MedPlan implements Serializable {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 家庭码（非空=家庭共享计划） */
    private String familyCode;

    /** 创建者设备标识 */
    private String deviceId;

    /** 药品名称 */
    private String medicineName;

    /** 剂量说明，如：1片 / 10ml */
    private String dosage;

    /** 每日服药时间，逗号分隔 HH:mm，如 08:00,12:00,20:00 */
    private String times;

    /** 开始日期 yyyy-MM-dd */
    private String startDate;

    /** 结束日期（空=长期） */
    private String endDate;

    /** 是否启用：1=启用, 0=停用 */
    private Integer enabled;
}
