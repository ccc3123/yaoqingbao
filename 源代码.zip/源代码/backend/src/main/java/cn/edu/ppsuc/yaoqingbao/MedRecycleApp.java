package cn.edu.ppsuc.yaoqingbao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 药清宝 V2.0 — 公益版
 * 药品回收公益信息平台
 * 零账户 零交易 零个人信息收集
 */
@SpringBootApplication
public class MedRecycleApp {
    public static void main(String[] args) {
        SpringApplication.run(MedRecycleApp.class, args);
    }
}
