package cn.edu.ppsuc.yaoqingbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.edu.ppsuc.yaoqingbao.data.po.Knowledge;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 科普知识 Mapper
 */
@Mapper
public interface KnowledgeMapper extends BaseMapper<Knowledge> {

    @Select("SELECT id, title, summary, category, cover_image, view_count, publish_time " +
            "FROM knowledge WHERE status = 'published' ORDER BY publish_time DESC")
    List<Knowledge> findPublishedList();

    @Select("SELECT * FROM knowledge WHERE status = 'published' AND category = #{category} " +
            "ORDER BY publish_time DESC")
    List<Knowledge> findByCategory(String category);

    @Update("UPDATE knowledge SET view_count = view_count + 1 WHERE id = #{id}")
    void incrementViewCount(Long id);
}
