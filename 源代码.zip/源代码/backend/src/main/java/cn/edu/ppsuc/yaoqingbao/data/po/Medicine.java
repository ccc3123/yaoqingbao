package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 药品信息实体
 * 数据来源：阿里云聚美智数药品条码 API + 本地缓存
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("medicine")
public class Medicine implements Serializable {

    /** 药品唯一标识（批准文号/条码） */
    private String id;

    /** 药品通用名称 */
    private String drugName;

    /** 规格型号 */
    private String ggxh;

    /** 生产厂家 */
    private String manu;

    /** 参考价格 */
    private String price;

    /** 不良反应 */
    private String blfy;

    /** 禁忌 */
    private String jj;

    /** 批准文号 */
    private String pzwh;

    /** 适用症/功能主治 */
    private String syz;

    /** 药品类型（处方药/非处方药等） */
    private String type;

    /** 性状 */
    private String xz;

    /** 用法用量 */
    private String yfyl;

    /** 药物相互作用 */
    private String ywxhzy;

    /** 有效期（如 "24个月"） */
    private String yxq;

    /** 贮藏条件 */
    private String zc;

    /** 执行标准 */
    private String zxbz;

    /** 注意事项 */
    private String zysx;

    /** 主治疾病 */
    private String zzjb;

    /** 主要成分 */
    private String zycf;

    /** 有效期天数（从有效期字符串解析，用于过期计算） */
    private Integer exp;

    /**
     * 从有效期字符串解析天数
     * 如 "24个月" → 730天, "2年" → 730天
     */
    public void refreshCD() {
        if (yxq == null || yxq.isEmpty()) {
            this.exp = 0;
            return;
        }
        try {
            // 提取数字部分
            StringBuilder numStr = new StringBuilder();
            for (char c : yxq.toCharArray()) {
                if (c >= '0' && c <= '9') {
                    numStr.append(c);
                } else {
                    break;
                }
            }
            int num = Integer.parseInt(numStr.toString());

            // 判断单位
            if (yxq.contains("年")) {
                this.exp = num * 365;
            } else if (yxq.contains("月")) {
                this.exp = num * 30;
            } else if (yxq.contains("日") || yxq.contains("天")) {
                this.exp = num;
            } else {
                this.exp = num * 30; // 默认按月
            }
        } catch (Exception e) {
            this.exp = 0;
        }
    }
}
