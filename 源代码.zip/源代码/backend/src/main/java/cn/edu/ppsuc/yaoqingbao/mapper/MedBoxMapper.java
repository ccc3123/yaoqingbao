package cn.edu.ppsuc.yaoqingbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.edu.ppsuc.yaoqingbao.data.po.MedBox;
import org.apache.ibatis.annotations.Mapper;

/**
 * 家庭药箱条目 Mapper
 */
@Mapper
public interface MedBoxMapper extends BaseMapper<MedBox> {
}
