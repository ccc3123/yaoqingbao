package cn.edu.ppsuc.yaoqingbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.edu.ppsuc.yaoqingbao.data.po.Medicine;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * 药品信息 Mapper
 */
@Mapper
public interface MedicineMapper extends BaseMapper<Medicine> {

    @Select("SELECT * FROM medicine WHERE pzwh = #{pzwh}")
    Medicine selectByPzwh(String pzwh);

    @Select("SELECT * FROM medicine WHERE id = #{code}")
    Medicine selectByCode(String code);
}
