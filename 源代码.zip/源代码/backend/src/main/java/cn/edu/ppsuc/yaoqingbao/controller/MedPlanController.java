package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.MedPlan;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.MedPlanMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 服药计划控制器（家庭共享）
 *
 * 计划含每日服药时间点，客户端据此把闹钟写入系统日历；
 * 家庭共享后各成员在自己手机日历看到相同提醒。
 */
@RestController
@RequestMapping("/medplan")
@Tag(name = "服药计划", description = "服药计划增删改查（闹钟由客户端写系统日历）")
public class MedPlanController {

    @Autowired private MedPlanMapper medPlanMapper;

    @GetMapping("/list")
    @Operation(summary = "按家庭码或设备标识拉取服药计划")
    public Result list(@RequestParam(required = false) String familyCode,
                       @RequestParam(required = false) String deviceId) {
        try {
            LambdaQueryWrapper<MedPlan> q = new LambdaQueryWrapper<>();
            if (familyCode != null && !familyCode.isEmpty()) {
                q.eq(MedPlan::getFamilyCode, familyCode);
            } else {
                q.eq(MedPlan::getDeviceId, deviceId == null ? "" : deviceId);
            }
            q.orderByDesc(MedPlan::getEnabled).orderByAsc(MedPlan::getId);
            return Result.success(medPlanMapper.selectList(q), "查询成功");
        } catch (Exception e) {
            return Result.error(500, "服药计划读取失败：" + e.getMessage());
        }
    }

    @PostMapping("/save")
    @Operation(summary = "新增或更新服药计划（带 id 则更新）")
    public Result save(@RequestBody Map<String, Object> body) {
        try {
            MedPlan p = new MedPlan();
            Object idObj = body.get("id");
            if (idObj != null) {
                Long id = toLong(idObj);
                if (id != null && id > 0) p.setId(id);
            }
            p.setFamilyCode(str(body.get("familyCode")));
            p.setDeviceId(str(body.get("deviceId")));
            p.setMedicineName(str(body.get("medicineName")));
            p.setDosage(str(body.get("dosage")));
            p.setTimes(str(body.get("times")));
            p.setStartDate(str(body.get("startDate")));
            p.setEndDate(str(body.get("endDate")));
            p.setEnabled(body.get("enabled") == null ? 1 : toInt(body.get("enabled")));
            if (p.getMedicineName().isEmpty()) {
                return Result.error(400, "药品名称不能为空");
            }
            if (p.getId() != null && p.getId() > 0) {
                medPlanMapper.updateById(p);
            } else {
                medPlanMapper.insert(p);
            }
            return Result.success(p.getId(), "已保存");
        } catch (Exception e) {
            return Result.error(500, "服药计划保存失败：" + e.getMessage());
        }
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除服药计划")
    public Result delete(@RequestParam Long id) {
        try {
            int n = medPlanMapper.deleteById(id);
            if (n == 0) return Result.error(404, "计划不存在或已删除");
            return Result.success(n, "已删除");
        } catch (Exception e) {
            return Result.error(500, "删除失败：" + e.getMessage());
        }
    }

    private String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private int toInt(Object o) {
        if (o == null) return 1;
        if (o instanceof Number) return ((Number) o).intValue();
        try {
            return Integer.parseInt(String.valueOf(o));
        } catch (Exception e) {
            return 1;
        }
    }

    private Long toLong(Object o) {
        if (o == null) return null;
        if (o instanceof Number) return ((Number) o).longValue();
        try {
            return Long.parseLong(String.valueOf(o));
        } catch (Exception e) {
            return null;
        }
    }
}
