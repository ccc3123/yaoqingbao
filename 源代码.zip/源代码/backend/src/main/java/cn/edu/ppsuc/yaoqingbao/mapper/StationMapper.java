package cn.edu.ppsuc.yaoqingbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.edu.ppsuc.yaoqingbao.data.po.Station;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 回收点 Mapper
 */
@Mapper
public interface StationMapper extends BaseMapper<Station> {

    @Select("SELECT * FROM station WHERE status = 'active' ORDER BY id")
    List<Station> findAllActive();

    @Select("SELECT * FROM station WHERE status = 'active' AND station_type = #{type}")
    List<Station> findByType(String type);
}
