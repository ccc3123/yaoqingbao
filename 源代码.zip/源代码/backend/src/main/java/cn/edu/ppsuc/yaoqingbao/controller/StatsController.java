package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 数据可视化统计控制器（竞赛展示用）
 * 所有数据均为匿名汇总，不含个人信息
 */
@RestController
@RequestMapping("/stats")
@Tag(name = "数据统计", description = "匿名回收数据统计与可视化")
public class StatsController {

    @GetMapping("/dashboard")
    @Operation(summary = "获取总览数据")
    public Result dashboard() {
        // 返回演示数据（生产环境应从 DB 聚合）
        return Result.success(Map.of(
                "totalRecycled", 1580,
                "co2Reduction", "约3.2吨",
                "waterSaved", "约19万立方米",
                "stations", 719
        ), "总览数据");
    }

    @GetMapping("/trend")
    @Operation(summary = "获取回收量趋势")
    public Result trend() {
        return Result.success(Map.of(
                "labels", new String[]{"1月","2月","3月","4月","5月","6月"},
                "values", new int[]{120,145,168,190,210,256}
        ), "趋势数据");
    }
}
