package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.MedRecord;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.MedRecordMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 服药记录控制器（家庭共享）
 *
 * 隔离规则与药箱一致：有家庭码按家庭码共享，无家庭码回退到设备标识个人维度。
 */
@RestController
@RequestMapping("/medrecord")
@Tag(name = "服药记录", description = "记录谁在什么时候服用了多少药")
public class MedRecordController {

    @Autowired private MedRecordMapper medRecordMapper;

    @GetMapping("/list")
    @Operation(summary = "按家庭码或设备标识拉取服药记录")
    public Result list(@RequestParam(required = false) String familyCode,
                       @RequestParam(required = false) String deviceId) {
        try {
            LambdaQueryWrapper<MedRecord> q = new LambdaQueryWrapper<>();
            if (familyCode != null && !familyCode.isEmpty()) {
                q.eq(MedRecord::getFamilyCode, familyCode);
            } else {
                q.eq(MedRecord::getDeviceId, deviceId == null ? "" : deviceId);
            }
            q.orderByDesc(MedRecord::getTakenAt).orderByDesc(MedRecord::getId);
            return Result.success(medRecordMapper.selectList(q), "查询成功");
        } catch (Exception e) {
            return Result.error(500, "服药记录读取失败：" + e.getMessage());
        }
    }

    @PostMapping("/save")
    @Operation(summary = "新增服药记录")
    public Result save(@RequestBody Map<String, Object> body) {
        try {
            MedRecord r = new MedRecord();
            r.setFamilyCode(str(body.get("familyCode")));
            r.setDeviceId(str(body.get("deviceId")));
            r.setMemberName(str(body.get("memberName")));
            r.setMedicineId(str(body.get("medicineId")));
            r.setMedicineName(str(body.get("medicineName")));
            r.setDose(toDouble(body.get("dose")));
            r.setUnit(str(body.get("unit")));
            r.setTakenAt(str(body.get("takenAt")));
            if (r.getMedicineName().isEmpty() && r.getMedicineId().isEmpty()) {
                return Result.error(400, "药品名称不能为空");
            }
            medRecordMapper.insert(r);
            return Result.success(r.getId(), "已记录");
        } catch (Exception e) {
            return Result.error(500, "服药记录保存失败：" + e.getMessage());
        }
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除服药记录（纠错用）")
    public Result delete(@RequestParam Long id) {
        try {
            int n = medRecordMapper.deleteById(id);
            if (n == 0) return Result.error(404, "记录不存在或已删除");
            return Result.success(n, "已删除");
        } catch (Exception e) {
            return Result.error(500, "删除失败：" + e.getMessage());
        }
    }

    private String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private Double toDouble(Object o) {
        if (o == null) return 0.0;
        if (o instanceof Number) return ((Number) o).doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return 0.0;
        }
    }
}
