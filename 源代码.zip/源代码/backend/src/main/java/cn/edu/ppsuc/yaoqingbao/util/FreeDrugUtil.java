package cn.edu.ppsuc.yaoqingbao.util;

import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 免费药品查询开放接口（可插拔数据源）
 *
 * 设计原则：
 * 1. 只做尽力而为的查询，任何异常都不向外抛出，统一降级为明确提示；
 * 2. 网络超时控制在 3 秒内，避免拖慢首屏；
 * 3. 解析采用"表格行 → 单元格"的通用策略，页面改版时只影响命中率，不会导致服务异常。
 *
 * 当前数据源：中国药品注册数据库（drugfuture.com，公开免费查询页）
 */
@Component
public class FreeDrugUtil {

    private static final Logger log = LoggerFactory.getLogger(FreeDrugUtil.class);

    /** 免费药品查询页（公开数据，无需鉴权） */
    private static final String SEARCH_URL = "https://www.drugfuture.com/cndrug/search.aspx?keyword=";
    private static final int TIMEOUT_MS = 3000;

    private static final Pattern TR = Pattern.compile("<tr[^>]*>(.*?)</tr>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TD = Pattern.compile("<t[dh][^>]*>(.*?)</t[dh]>", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern TAG = Pattern.compile("<[^>]+>");

    /**
     * 按关键词（药品名 / 条码 / 批准文号）查询
     * @return Result.data 为 List<Map>，字段：drugName、ggxh、manu、pzwh、yxq、type
     *         未命中或不可用时返回非 200 的 Result，msg 为可直接展示给用户的降级提示
     */
    public Result search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return Result.error(400, "查询关键词为空");
        }
        String html;
        try {
            html = httpGet(SEARCH_URL + URLEncoder.encode(keyword.trim(), StandardCharsets.UTF_8.name()));
        } catch (Exception e) {
            log.warn("免费药品接口请求失败: {}", e.getMessage());
            return Result.error(503, "药品查询服务暂时不可用，已切换其他方式");
        }
        if (html == null || html.isEmpty()) {
            return Result.error(503, "药品查询服务暂时不可用，已切换其他方式");
        }
        List<Map<String, Object>> list = parseTable(html);
        if (list.isEmpty()) {
            return Result.error(404, "未查询到「" + keyword + "」相关的药品信息");
        }
        return Result.success(list, "查询成功");
    }

    /**
     * 通用表格解析：首行为表头，其余为数据行
     */
    private List<Map<String, Object>> parseTable(String html) {
        List<Map<String, Object>> rows = new ArrayList<>();
        try {
            List<List<String>> table = new ArrayList<>();
            Matcher tm = TR.matcher(html);
            while (tm.find()) {
                List<String> cells = new ArrayList<>();
                Matcher cm = TD.matcher(tm.group(1));
                while (cm.find()) {
                    String text = stripTags(cm.group(1)).trim();
                    cells.add(text);
                }
                if (!cells.isEmpty()) table.add(cells);
            }
            if (table.size() < 2) return rows;

            List<String> header = table.get(0);
            for (int i = 1; i < table.size() && rows.size() < 20; i++) {
                List<String> cells = table.get(i);
                if (cells.size() < 2) continue;
                Map<String, Object> row = new LinkedHashMap<>();
                // 通用映射：优先用表头名，表头缺失时用位置兜底
                for (int c = 0; c < cells.size(); c++) {
                    String key = c < header.size() && !header.get(c).isEmpty()
                            ? normalizeKey(header.get(c)) : "col" + c;
                    row.put(key, cells.get(c));
                }
                String name = firstNonEmpty(row, "药品名称", "名称", "通用名称", "col0");
                if (name.isEmpty()) continue;
                Map<String, Object> item = new HashMap<>();
                item.put("drugName", name);
                item.put("ggxh", firstNonEmpty(row, "规格", "规格型号", "col1"));
                item.put("manu", firstNonEmpty(row, "生产企业", "生产厂家", "厂家", "企业名称", "col2"));
                item.put("pzwh", firstNonEmpty(row, "批准文号", "注册证号", "col3"));
                item.put("yxq", firstNonEmpty(row, "有效期", "col4"));
                item.put("type", firstNonEmpty(row, "药品类型", "剂型", "分类", "col5"));
                rows.add(item);
            }
        } catch (Exception e) {
            log.warn("药品结果解析失败: {}", e.getMessage());
        }
        return rows;
    }

    private String firstNonEmpty(Map<String, Object> row, String... keys) {
        for (String k : keys) {
            Object v = row.get(k);
            if (v != null && !String.valueOf(v).trim().isEmpty()) {
                return String.valueOf(v).trim();
            }
        }
        return "";
    }

    private String normalizeKey(String header) {
        String h = header.replaceAll("[\\s:：]", "");
        if (h.contains("名称")) return "药品名称";
        if (h.contains("规格")) return "规格";
        if (h.contains("企业") || h.contains("厂家")) return "生产企业";
        if (h.contains("批准文号") || h.contains("注册证号")) return "批准文号";
        if (h.contains("有效期")) return "有效期";
        if (h.contains("剂型") || h.contains("类型")) return "药品类型";
        return h;
    }

    private String stripTags(String s) {
        return TAG.matcher(s).replaceAll("").replace("&nbsp;", " ").trim();
    }

    private String httpGet(String urlStr) throws Exception {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (YaoQingBao/2.0; +public-welfare)");
            conn.setRequestProperty("Accept", "text/html");
            int code = conn.getResponseCode();
            if (code != 200) return null;
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                return new String(bos.toByteArray(), StandardCharsets.UTF_8);
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
