package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.MedBox;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.MedBoxMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 家庭药箱（待回收药品记录）控制器
 *
 * V3：药箱支持家庭共享（familyCode 优先，无家庭回退 deviceId）与科学计量
 * （total/unit/remaining），删除支持单条与批量，失败返回明确错误码。
 */
@RestController
@RequestMapping("/medbox")
@Tag(name = "家庭药箱", description = "药箱记录的增删改查（家庭共享，按家庭码/设备标识隔离）")
public class MedBoxController {

    @Autowired private MedBoxMapper medBoxMapper;

    @GetMapping("/list")
    @Operation(summary = "按家庭码或设备标识拉取药箱列表")
    public Result list(@RequestParam(required = false) String familyCode,
                       @RequestParam(required = false) String deviceId) {
        try {
            LambdaQueryWrapper<MedBox> q = new LambdaQueryWrapper<>();
            if (familyCode != null && !familyCode.isEmpty()) {
                q.eq(MedBox::getFamilyCode, familyCode);
            } else {
                q.eq(MedBox::getDeviceId, deviceId == null ? "" : deviceId);
            }
            q.orderByDesc(MedBox::getAddTime);
            return Result.success(medBoxMapper.selectList(q), "查询成功");
        } catch (Exception e) {
            return Result.error(500, "药箱列表读取失败：" + e.getMessage());
        }
    }

    @PostMapping("/save")
    @Operation(summary = "保存/覆盖药箱条目（单条或数组）")
    public Result save(@RequestBody Map<String, Object> body) {
        try {
            String deviceId = String.valueOf(body.getOrDefault("deviceId", ""));
            String familyCode = String.valueOf(body.getOrDefault("familyCode", ""));
            Object items = body.get("items");
            List<Map<String, Object>> list = new ArrayList<>();
            if (items instanceof List) {
                for (Object o : (List<?>) items) {
                    if (o instanceof Map) {
                        @SuppressWarnings("unchecked")
                        Map<String, Object> m = (Map<String, Object>) o;
                        list.add(m);
                    }
                }
            } else if (items instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> m = (Map<String, Object>) items;
                list.add(m);
            }
            if (deviceId.isEmpty() && familyCode.isEmpty()) {
                return Result.error(400, "deviceId 与 familyCode 不能同时为空");
            }

            for (Map<String, Object> m : list) {
                MedBox box = new MedBox();
                box.setBoxId(String.valueOf(m.getOrDefault("boxId", m.getOrDefault("medicineId", ""))));
                box.setDeviceId(deviceId);
                box.setFamilyCode(String.valueOf(m.getOrDefault("familyCode", familyCode)));
                box.setMedicineName(String.valueOf(m.getOrDefault("medicineName", "")));
                box.setProduceTime(String.valueOf(m.getOrDefault("produceTime", "")));
                box.setAddTime(String.valueOf(m.getOrDefault("addTime", "")));
                box.setExpDays(toInt(m.get("expDays")));
                box.setCountDown(toInt(m.get("countDown")));
                box.setRecycled(toInt(m.get("recycled")));
                box.setSource(String.valueOf(m.getOrDefault("source", "local")));
                box.setTotal(toDouble(m.get("total")));
                box.setUnit(String.valueOf(m.getOrDefault("unit", "")));
                box.setRemaining(toDouble(m.get("remaining")));
                if (box.getBoxId().isEmpty()) continue;
                MedBox exist = medBoxMapper.selectById(box.getBoxId());
                if (exist == null) {
                    medBoxMapper.insert(box);
                } else {
                    medBoxMapper.updateById(box);
                }
            }
            return Result.ok();
        } catch (Exception e) {
            return Result.error(500, "药箱保存失败：" + e.getMessage());
        }
    }

    @DeleteMapping("/delete")
    @Operation(summary = "删除单条药箱记录")
    public Result delete(@RequestParam String boxId,
                         @RequestParam(required = false) String deviceId,
                         @RequestParam(required = false) String familyCode) {
        try {
            LambdaQueryWrapper<MedBox> q = new LambdaQueryWrapper<>();
            q.eq(MedBox::getBoxId, boxId);
            if (familyCode != null && !familyCode.isEmpty()) {
                q.eq(MedBox::getFamilyCode, familyCode);
            } else if (deviceId != null && !deviceId.isEmpty()) {
                q.eq(MedBox::getDeviceId, deviceId);
            }
            int n = medBoxMapper.delete(q);
            if (n == 0) return Result.error(404, "该记录不存在或已删除");
            return Result.success(n, "已删除 1 条");
        } catch (Exception e) {
            return Result.error(500, "删除失败：" + e.getMessage());
        }
    }

    @DeleteMapping("/deleteBatch")
    @Operation(summary = "批量删除药箱记录（body: {deviceId/familyCode, boxIds:[]}）")
    public Result deleteBatch(@RequestBody Map<String, Object> body) {
        try {
            String deviceId = String.valueOf(body.getOrDefault("deviceId", ""));
            String familyCode = String.valueOf(body.getOrDefault("familyCode", ""));
            Object idsObj = body.get("boxIds");
            List<String> ids = new ArrayList<>();
            if (idsObj instanceof List) {
                for (Object o : (List<?>) idsObj) ids.add(String.valueOf(o));
            }
            if ((deviceId.isEmpty() && familyCode.isEmpty()) || ids.isEmpty()) {
                return Result.error(400, "deviceId/familyCode 与 boxIds 不能为空");
            }
            LambdaQueryWrapper<MedBox> q = new LambdaQueryWrapper<>();
            q.in(MedBox::getBoxId, ids);
            if (familyCode != null && !familyCode.isEmpty()) {
                q.eq(MedBox::getFamilyCode, familyCode);
            } else {
                q.eq(MedBox::getDeviceId, deviceId);
            }
            int n = medBoxMapper.delete(q);
            if (n == 0) return Result.error(404, "未匹配到可删除的记录");
            return Result.success(n, "已删除 " + n + " 条");
        } catch (Exception e) {
            return Result.error(500, "批量删除失败：" + e.getMessage());
        }
    }

    private int toInt(Object o) {
        if (o == null) return 0;
        if (o instanceof Number) return ((Number) o).intValue();
        try {
            return Integer.parseInt(String.valueOf(o));
        } catch (Exception e) {
            return 0;
        }
    }

    private Double toDouble(Object o) {
        if (o == null) return 0.0;
        if (o instanceof Number) return ((Number) o).doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return 0.0;
        }
    }
}
