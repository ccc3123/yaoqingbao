package cn.edu.ppsuc.yaoqingbao.data.po;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * 地理位置坐标
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Position {
    private BigDecimal latitude;
    private BigDecimal longitude;
    private int radius;

    @Override
    public String toString() {
        return "nearby(" + latitude + "," + longitude + "," + radius + ")";
    }
}
