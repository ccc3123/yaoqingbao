package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.User;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.UserMapper;
import cn.edu.ppsuc.yaoqingbao.util.JwtUtil;
import cn.edu.ppsuc.yaoqingbao.util.SmsCodeStore;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 账号控制器 —— 手机号验证码登录（混合双入口的「账号」一侧）。
 *
 * 父母老人仍可凭家庭码免注册加入家庭，本控制器只服务愿意注册的子女。
 */
@RestController
@RequestMapping("/auth")
@Tag(name = "账号", description = "手机号验证码登录，签发 JWT")
public class AuthController {

    @Autowired private UserMapper userMapper;

    @PostMapping("/sendCode")
    @Operation(summary = "发送验证码（演示模式随响应返回）")
    public Result sendCode(@RequestBody Map<String, Object> body) {
        String phone = str(body.get("phone"));
        if (!phone.matches("^1\\d{10}$")) {
            return Result.error(400, "手机号格式不正确");
        }
        String code = SmsCodeStore.generate(phone);
        // 演示模式：验证码直接随响应返回，便于竞赛演示自动填充；
        // 生产环境删除 demoCode 字段，改为真实短信下发。
        Map<String, Object> data = new HashMap<>();
        data.put("demoCode", code);
        return Result.success(data, "验证码已发送（演示模式）");
    }

    @PostMapping("/login")
    @Operation(summary = "验证码登录（不存在则自动注册）")
    public Result login(@RequestBody Map<String, Object> body) {
        String phone = str(body.get("phone"));
        String code = str(body.get("code"));
        if (phone.isEmpty()) return Result.error(400, "手机号不能为空");
        if (!SmsCodeStore.verify(phone, code)) {
            return Result.error(400, "验证码错误或已过期");
        }

        LambdaQueryWrapper<User> q = new LambdaQueryWrapper<>();
        q.eq(User::getPhone, phone);
        User user = userMapper.selectOne(q);
        if (user == null) {
            user = new User();
            user.setPhone(phone);
            user.setNickname("用户" + phone.substring(phone.length() - 4));
            userMapper.insert(user);
        }

        String token = JwtUtil.issue(user.getId(), phone);
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("userId", user.getId());
        data.put("phone", phone);
        data.put("nickname", user.getNickname());
        return Result.success(data, "登录成功");
    }

    private String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }
}
