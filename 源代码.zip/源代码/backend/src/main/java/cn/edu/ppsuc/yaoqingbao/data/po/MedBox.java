package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 家庭药箱条目（= 待回收药品记录）
 * 与客户端 DrugItem 字段一一对应，便于双向同步
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("med_box")
public class MedBox implements Serializable {

    /** 药箱条目 ID（客户端生成的时间戳字符串） */
    @TableId
    private String boxId;

    /** 设备/成员标识（匿名，不采集个人信息） */
    private String deviceId;

    /** 家庭码（非空=家庭共享药箱） */
    private String familyCode;

    /** 药品名称 */
    private String medicineName;

    /** 生产日期 yyyy-MM-dd */
    private String produceTime;

    /** 录入日期 yyyy-MM-dd */
    private String addTime;

    /** 有效期天数 */
    private Integer expDays;

    /** 剩余天数（<=0 表示已过期） */
    private Integer countDown;

    /** 是否已投递回收点：0=在册, 1=已回收 */
    private Integer recycled;

    /** 数据来源：local=本地录入, scan=扫码录入 */
    private String source;

    /** 总量（按单位计量，支持小数如半片 0.5） */
    private Double total;

    /** 计量单位：片/颗/粒/瓶/袋/支/包/盒/mg/ml/g */
    private String unit;

    /** 剩余量（服药后递减） */
    private Double remaining;
}
