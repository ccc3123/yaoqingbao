package cn.edu.ppsuc.yaoqingbao.mapper;

import cn.edu.ppsuc.yaoqingbao.data.po.MedPlan;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 服药计划 Mapper
 */
@Mapper
public interface MedPlanMapper extends BaseMapper<MedPlan> {
}
