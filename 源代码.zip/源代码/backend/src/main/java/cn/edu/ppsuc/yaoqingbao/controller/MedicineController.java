package cn.edu.ppsuc.yaoqingbao.controller;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import cn.edu.ppsuc.yaoqingbao.data.po.Medicine;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.service.MedService;
import cn.edu.ppsuc.yaoqingbao.util.FreeDrugUtil;
import cn.edu.ppsuc.yaoqingbao.util.MedicineSearchUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * 药品信息查询控制器 - 无需认证，完全公开
 */
@RestController
@RequestMapping("/med")
@Tag(name = "药品查询", description = "药品条码/关键词/批准文号查询")
public class MedicineController {

    private static final Logger log = LoggerFactory.getLogger(MedicineController.class);

    @Autowired private MedicineSearchUtil searchUtil;
    @Autowired private MedService medService;
    @Autowired private FreeDrugUtil freeDrugUtil;

    @PostMapping("/search")
    @Operation(summary = "关键词搜索药品")
    public Result searchMedicine(
            @Parameter(description = "搜索关键词") @RequestParam String keyword,
            @Parameter(description = "类型") @RequestParam(defaultValue = "1") String type,
            @Parameter(description = "页码") @RequestParam(defaultValue = "1") int pageNo) {
        Result result = searchUtil.search(keyword, type, pageNo);
        try {
            String js = JSON.toJSONString(result);
            JSONObject root = JSON.parseObject(js);
            JSONObject dataObj = root.getJSONObject("data").getJSONObject("data");
            return Result.success(dataObj.toJSONString(), "查询成功");
        } catch (Exception e) {
            return Result.success(result.getData(), "查询成功");
        }
    }

    @PostMapping("/PSearch")
    @Operation(summary = "按批准文号查询药品详情")
    public Result searchByPzwh(@Parameter(description = "批准文号") @RequestParam String pzwh) {
        Medicine medicine = medService.getMedicineByPzwh(pzwh);
        if (medicine == null) return Result.error(400, "未查询到该批准文号对应的药品信息");
        return Result.success(medicine, "药品信息");
    }

    @PostMapping("/CodeSearch")
    @Operation(summary = "扫描条码查询药品（付费接口优先，免费开放接口兜底）")
    public Result searchByCode(@Parameter(description = "药品条码") @RequestParam String code) {
        Medicine medicine = medService.getMedicineByCode(code);
        if (medicine != null) return Result.success(medicine, "药品信息");

        // 付费接口无结果 → 免费药品查询开放接口兜底
        Result free = freeDrugUtil.search(code);
        if (free.getCode() != null && free.getCode() == 200) {
            return Result.success(free.getData(), "药品信息（免费数据源）");
        }
        // 明确降级提示，交由前端切换到 AI 识别或手动录入
        return Result.error(404, free.getMsg() != null ? free.getMsg() : "未识别该条码，请尝试手动搜索");
    }

    @GetMapping("/freeSearch")
    @Operation(summary = "免费药品查询开放接口（关键词/条码/批准文号），不可用时返回明确提示而非异常")
    public Result freeSearch(@Parameter(description = "关键词/条码/批准文号") @RequestParam String keyword) {
        return freeDrugUtil.search(keyword);
    }

    @PostMapping("/analyzeRecyclable")
    @Operation(summary = "分析药品是否可回收")
    public Result analyzeRecyclable(
            @Parameter(description = "批准文号或药品名称") @RequestParam String pzwh,
            @Parameter(description = "是否已过期") @RequestParam(defaultValue = "false") boolean expired) {
        Map<String, Object> analysis = medService.analyzeRecyclable(pzwh, expired);
        return Result.success(analysis, "分析完成");
    }
}
