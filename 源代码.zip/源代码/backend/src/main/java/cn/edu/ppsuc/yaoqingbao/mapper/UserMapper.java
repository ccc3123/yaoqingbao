package cn.edu.ppsuc.yaoqingbao.mapper;

import cn.edu.ppsuc.yaoqingbao.data.po.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户 Mapper
 */
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
