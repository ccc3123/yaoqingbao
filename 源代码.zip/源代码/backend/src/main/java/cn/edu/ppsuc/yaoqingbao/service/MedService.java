package cn.edu.ppsuc.yaoqingbao.service;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import cn.edu.ppsuc.yaoqingbao.data.po.Medicine;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.MedicineMapper;
import cn.edu.ppsuc.yaoqingbao.util.MedicineSearchUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * 药品查询服务
 * 二级缓存策略：先查本地DB → 未命中则调第三方API并自动入库
 */
@Service
public class MedService {

    private static final Logger log = LoggerFactory.getLogger(MedService.class);

    @Autowired
    private MedicineMapper medicineMapper;

    @Autowired
    private MedicineSearchUtil searchUtil;

    /**
     * 按批准文号查询药品
     * 本地有则直接返回，无则调API并自动入库
     */
    public Medicine getMedicineByPzwh(String pzwh) {
        // 1. 先查本地
        Medicine medicine = medicineMapper.selectByPzwh(pzwh);
        if (medicine != null) {
            log.info("本地命中: pzwh={}", pzwh);
            return medicine;
        }

        // 2. 调用第三方API
        log.info("本地未命中，调用API: pzwh={}", pzwh);
        Result result = searchUtil.searchByPzwh(pzwh);
        if (result.getCode() != 200) {
            return null;
        }

        // 3. 解析并入库
        try {
            String jsonString = JSON.toJSONString(result);
            JSONObject root = JSON.parseObject(jsonString);
            JSONObject dataObj = root.getJSONObject("data").getJSONObject("data");
            medicine = JSON.parseObject(dataObj.toJSONString(), Medicine.class);
            medicine.refreshCD();
            medicineMapper.insert(medicine);
            log.info("API查询完成并入库: id={}", medicine.getId());
            return medicine;
        } catch (Exception e) {
            log.error("药品信息解析失败: pzwh={}", pzwh, e);
            return null;
        }
    }

    /**
     * 按条码查询药品（条码→批准文号→药品详情）
     */
    public Medicine getMedicineByCode(String code) {
        Result result = searchUtil.searchByCode(code);
        if (result.getCode() != 200) {
            return null;
        }

        try {
            String jsonString = JSON.toJSONString(result);
            JSONObject root = JSON.parseObject(jsonString);
            JSONObject dataObj = root.getJSONObject("data").getJSONObject("data");
            Map<String, String> info = JSON.parseObject(dataObj.toJSONString(), HashMap.class);
            String pzwh = info.get("approval");

            if (pzwh == null || pzwh.isEmpty()) {
                return null;
            }

            log.info("条码反查成功: code={} -> pzwh={}", code, pzwh);
            return getMedicineByPzwh(pzwh);
        } catch (Exception e) {
            log.error("条码查询解析失败: code={}", code, e);
            return null;
        }
    }

    /**
     * 检查药品是否已存在于本地库
     */
    public boolean existsById(String id) {
        return medicineMapper.selectById(id) != null;
    }

    /**
     * 分析药品可回收性
     * 判断逻辑：
     * - 根据药品类型(type)和批准文号(pzwh)判断药品类别
     * - 麻醉药品/精神药品/放射性药品/毒性药品 → 不可回收(non-recyclable)
     * - 处方药/OTC/中成药且未过期 → 可回收(recyclable)，可再利用
     * - 处方药/OTC/中成药但已过期 → 需销毁(disposable)
     * - 特殊制剂(注射剂/眼用制剂) → 需专业销毁
     */
    public Map<String, Object> analyzeRecyclable(String pzwh, boolean expired) {
        Map<String, Object> result = new HashMap<>();

        // Try to look up the medicine
        Medicine medicine = null;
        try {
            medicine = getMedicineByPzwh(pzwh);
        } catch (Exception e) {
            log.warn("药品查询失败，使用通用分析: pzwh={}", pzwh);
        }

        String type = medicine != null ? (medicine.getType() != null ? medicine.getType() : "") : "";
        String drugName = medicine != null ? (medicine.getDrugName() != null ? medicine.getDrugName() : "") : "";

        // Check for controlled substances (麻醉/精神/放射性/毒性)
        String typeLower = type.toLowerCase();
        String nameLower = drugName.toLowerCase();
        String pzwhLower = pzwh.toLowerCase();

        boolean isControlled = typeLower.contains("麻醉") || typeLower.contains("精神")
            || typeLower.contains("放射") || typeLower.contains("毒性")
            || typeLower.contains("易制毒") || nameLower.contains("麻醉")
            || nameLower.contains("吗啡") || nameLower.contains("杜冷丁")
            || nameLower.contains("芬太尼") || nameLower.contains("哌替啶");

        boolean isInjectable = typeLower.contains("注射") || typeLower.contains("针剂")
            || nameLower.contains("注射液") || nameLower.contains("注射用");

        boolean isOphthalmic = typeLower.contains("眼用") || nameLower.contains("滴眼")
            || nameLower.contains("眼膏") || nameLower.contains("眼药");

        boolean isSpecialFormulation = isInjectable || isOphthalmic;

        boolean isOTC = typeLower.contains("非处方") || typeLower.contains("otc")
            || typeLower.contains("甲类") || typeLower.contains("乙类");

        boolean isChineseMedicine = typeLower.contains("中药") || typeLower.contains("中成药")
            || typeLower.contains("天然药物") || typeLower.contains("民族药");

        if (isControlled) {
            result.put("recyclable", false);
            result.put("recycleType", "forbidden");
            result.put("reason", "该药品属于特殊管制类药品（麻醉/精神/放射性/毒性药品），严禁随意丢弃，须交由药品监督管理部门或公安机关处理");
            result.put("suggestion", "请勿自行处理。携带药品及原包装至当地药品监督管理局、社区卫生服务中心或公安机关，由专业人员处置");
            result.put("category", "特殊管制药品");
            result.put("color", "#D32F2F"); // red
        } else if (expired) {
            result.put("recyclable", false);
            result.put("recycleType", "disposable");
            if (isSpecialFormulation) {
                result.put("reason", "该药品已过期且属于特殊制剂（注射剂/眼用制剂），存在微生物污染风险，必须按医疗废物标准销毁");
                result.put("suggestion", "请勿冲入下水道或丢入生活垃圾桶。密封包装后标注「过期药品」，送至社区药品回收点或社区卫生服务中心统一销毁");
            } else {
                result.put("reason", "该药品已过期，有效成分可能分解产生有害物质，不可再使用，需安全销毁");
                result.put("suggestion", "密封包装后标注「过期药品」，送至社区药品回收点或社区卫生服务中心统一销毁处理。切勿冲入下水道或混入生活垃圾");
            }
            result.put("category", "过期药品·待销毁");
            result.put("color", "#EF6C00"); // orange
        } else {
            // Recyclable - still within expiry
            result.put("recyclable", true);
            result.put("recycleType", "reusable");

            if (isChineseMedicine) {
                result.put("category", "中成药·可再利用");
            } else if (isOTC) {
                result.put("category", "非处方药·可再利用");
            } else {
                result.put("category", "处方药·可再利用");
            }

            result.put("reason", "该药品符合回收条件，可经专业机构评估后进行再利用或安全回收");
            result.put("suggestion", "请保持药品完整包装，送至社区药品回收点、定点药店或社区卫生服务中心。回收前请确认包装无破损、药品未变质");
            result.put("color", "#2E7D32"); // green
        }

        result.put("drugName", drugName);
        result.put("drugType", type);
        result.put("expired", expired);

        return result;
    }
}
