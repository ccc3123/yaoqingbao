package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 服药记录（家庭共享）
 *
 * 记录「谁在什么时候服用了多少药」，家庭成员互相可见，实现异地照护。
 * 剂量 + 单位支持科学计量（mg/ml）与按颗计数（片/颗/半片用小数）。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("med_record")
public class MedRecord implements Serializable {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 家庭码（非空=家庭共享记录） */
    private String familyCode;

    /** 记录人设备/成员标识 */
    private String deviceId;

    /** 记录人称谓（成员名/昵称） */
    private String memberName;

    /** 药箱条目 ID（关联 med_box.box_id） */
    private String medicineId;

    /** 药品名称 */
    private String medicineName;

    /** 本次服用剂量 */
    private Double dose;

    /** 单位：片/颗/粒/瓶/袋/支/包/盒/mg/ml/g */
    private String unit;

    /** 服药时间 yyyy-MM-dd HH:mm */
    private String takenAt;
}
