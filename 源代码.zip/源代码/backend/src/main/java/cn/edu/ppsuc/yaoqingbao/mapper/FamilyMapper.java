package cn.edu.ppsuc.yaoqingbao.mapper;

import cn.edu.ppsuc.yaoqingbao.data.po.FamilyMember;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

/**
 * 家庭协同 Mapper
 * family_group 表结构极简，直接用注解 SQL 操作，不再单独建 PO
 */
@Mapper
public interface FamilyMapper extends BaseMapper<FamilyMember> {

    @Select("SELECT family_code FROM family_group WHERE family_code = #{code}")
    String existsGroup(@Param("code") String code);

    @Insert("INSERT INTO family_group (family_code, name) VALUES (#{code}, #{name})")
    int insertGroup(@Param("code") String code, @Param("name") String name);

    @Select("SELECT m.member_id AS memberId, m.user_id AS userId, m.member_name AS memberName, " +
            "m.role AS role, m.last_sync AS lastSync, " +
            "(SELECT COUNT(*) FROM med_box b WHERE b.family_code = #{code} AND b.count_down <= 0) AS expiredCount, " +
            "(SELECT COUNT(*) FROM med_box b WHERE b.family_code = #{code}) AS totalCount " +
            "FROM family_member m WHERE m.family_code = #{code}")
    List<Map<String, Object>> selectMembers(@Param("code") String code);
}
