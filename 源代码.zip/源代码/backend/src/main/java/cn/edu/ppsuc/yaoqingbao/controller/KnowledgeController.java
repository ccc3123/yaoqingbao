package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.Knowledge;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.KnowledgeMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 科普知识库控制器
 */
@RestController
@RequestMapping("/knowledge")
@Tag(name = "科普知识", description = "药品回收科普知识库")
public class KnowledgeController {

    @Autowired private KnowledgeMapper knowledgeMapper;

    @GetMapping("/list")
    @Operation(summary = "获取科普文章列表")
    public Result list(
            @Parameter(description = "分类筛选") @RequestParam(required = false) String category) {
        List<Knowledge> list = (category != null && !category.isEmpty())
                ? knowledgeMapper.findByCategory(category)
                : knowledgeMapper.findPublishedList();
        return Result.success(list, "获取成功");
    }

    @GetMapping("/{id}")
    @Operation(summary = "获取科普文章详情")
    public Result detail(@Parameter(description = "文章ID") @PathVariable Long id) {
        Knowledge k = knowledgeMapper.selectById(id);
        if (k == null || !"published".equals(k.getStatus()))
            return Result.notFound("文章不存在");
        knowledgeMapper.incrementViewCount(id);
        return Result.success(k, "获取成功");
    }
}
