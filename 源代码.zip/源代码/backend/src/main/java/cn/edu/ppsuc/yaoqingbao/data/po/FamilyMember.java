package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * 家庭成员（匿名，仅用设备标识 + 备注称谓，不采集手机号等个人信息）
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("family_member")
public class FamilyMember implements Serializable {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 6 位家庭码 */
    private String familyCode;

    /** 成员设备标识 */
    private String memberId;

    /** 关联账号用户ID（账号成员非空，匿名家庭码成员为空） */
    private Long userId;

    /** 备注称谓，如：妈妈、爷爷 */
    private String memberName;

    /** owner=创建者, member=普通成员 */
    private String role;

    /** 最近一次同步药箱的时间 */
    private String lastSync;
}
