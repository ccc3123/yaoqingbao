package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 回收点/药店实体
 * 所有回收点信息由后台管理员审核后发布
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("station")
public class Station implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 机构名称 */
    private String name;

    /** 机构类型: pharmacy=药店, hospital=医院药房, community=社区回收站, charity=慈善机构 */
    private String stationType;

    /** 详细地址 */
    private String address;

    /** 联系电话 */
    private String phone;

    /** 营业时间 */
    private String businessHours;

    /** 纬度 */
    private BigDecimal latitude;

    /** 经度 */
    private BigDecimal longitude;

    /** 回收类型: reusable=可再利用, disposable=待销毁, both=均可 */
    private String recycleType;

    /** 是否接收捐赠 */
    private Boolean acceptDonation;

    /** 状态: active=运营中, inactive=已停用 */
    private String status;
}
