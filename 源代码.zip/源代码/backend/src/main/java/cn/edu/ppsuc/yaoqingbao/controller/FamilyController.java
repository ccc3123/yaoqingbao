package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.FamilyMember;
import cn.edu.ppsuc.yaoqingbao.data.po.MedBox;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.FamilyMapper;
import cn.edu.ppsuc.yaoqingbao.mapper.MedBoxMapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 家庭协同控制器（混合双入口）
 *
 * - 账号侧：子女用手机号登录后创建/加入家庭（带 userId）
 * - 匿名侧：父母老人凭 6 位家庭码免注册加入（只有 memberId）
 *
 * V3：家庭内共享同一份药箱（med_box 按 family_code 隔离），服药记录/计划也家庭共享。
 */
@RestController
@RequestMapping("/family")
@Tag(name = "家庭协同", description = "家庭码创建/加入、成员列表、共享药箱查看")
public class FamilyController {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    @Autowired private FamilyMapper familyMapper;
    @Autowired private MedBoxMapper medBoxMapper;

    @PostMapping("/create")
    @Operation(summary = "创建家庭并生成 6 位家庭码（可带 userId）")
    public Result create(@RequestBody Map<String, Object> body) {
        try {
            String memberId = str(body.get("memberId"));
            String memberName = str(body.get("memberName"));
            String familyName = str(body.get("familyName"));
            Long userId = toLong(body.get("userId"));
            if (memberId.isEmpty() && userId == null) return Result.error(400, "memberId 不能为空");

            String code = generateCode();
            familyMapper.insertGroup(code, familyName.isEmpty() ? "我的家庭" : familyName);
            addMember(code, memberId, userId, memberName.isEmpty() ? "我" : memberName, "owner");
            Map<String, Object> data = new HashMap<>();
            data.put("familyCode", code);
            return Result.success(data, "家庭已创建");
        } catch (Exception e) {
            return Result.error(500, "创建家庭失败：" + e.getMessage());
        }
    }

    @PostMapping("/join")
    @Operation(summary = "使用家庭码加入家庭（可带 userId）")
    public Result join(@RequestBody Map<String, Object> body) {
        try {
            String code = str(body.get("familyCode"));
            String memberId = str(body.get("memberId"));
            String memberName = str(body.get("memberName"));
            Long userId = toLong(body.get("userId"));
            if (code.isEmpty() || (memberId.isEmpty() && userId == null)) {
                return Result.error(400, "家庭码与成员标识不能为空");
            }
            if (familyMapper.existsGroup(code) == null) return Result.error(404, "家庭码不存在，请核对后重试");

            // 按 userId 或 memberId 判重，避免重复加入
            LambdaQueryWrapper<FamilyMember> exist = new LambdaQueryWrapper<>();
            exist.eq(FamilyMember::getFamilyCode, code);
            if (userId != null) {
                exist.eq(FamilyMember::getUserId, userId);
            } else {
                exist.eq(FamilyMember::getMemberId, memberId);
            }
            if (familyMapper.selectCount(exist) == 0) {
                addMember(code, memberId, userId, memberName.isEmpty() ? "家人" : memberName, "member");
            }
            Map<String, Object> data = new HashMap<>();
            data.put("familyCode", code);
            return Result.success(data, "已加入家庭");
        } catch (Exception e) {
            return Result.error(500, "加入家庭失败：" + e.getMessage());
        }
    }

    @GetMapping("/my")
    @Operation(summary = "查询当前成员/账号所属家庭（无则返回空）")
    public Result my(@RequestParam(required = false) Long userId,
                     @RequestParam(required = false) String memberId) {
        try {
            LambdaQueryWrapper<FamilyMember> q = new LambdaQueryWrapper<>();
            if (userId != null) {
                q.eq(FamilyMember::getUserId, userId);
            } else {
                q.eq(FamilyMember::getMemberId, memberId == null ? "" : memberId);
            }
            FamilyMember m = familyMapper.selectOne(q);
            if (m == null) return Result.success(new HashMap<String, Object>(), "未加入家庭");
            Map<String, Object> data = new HashMap<>();
            data.put("familyCode", m.getFamilyCode());
            data.put("memberName", m.getMemberName());
            data.put("role", m.getRole());
            return Result.success(data, "查询成功");
        } catch (Exception e) {
            return Result.error(500, "家庭查询失败：" + e.getMessage());
        }
    }

    @GetMapping("/members")
    @Operation(summary = "查询家庭成员及其共享药箱统计")
    public Result members(@RequestParam String familyCode) {
        try {
            if (familyMapper.existsGroup(familyCode) == null) {
                return Result.error(404, "家庭码不存在");
            }
            return Result.success(familyMapper.selectMembers(familyCode), "查询成功");
        } catch (Exception e) {
            return Result.error(500, "成员列表读取失败：" + e.getMessage());
        }
    }

    @GetMapping("/box")
    @Operation(summary = "查看家庭共享药箱（全家同一份）")
    public Result familyBox(@RequestParam String familyCode) {
        try {
            LambdaQueryWrapper<MedBox> q = new LambdaQueryWrapper<>();
            q.eq(MedBox::getFamilyCode, familyCode).orderByAsc(MedBox::getCountDown);
            List<MedBox> boxes = medBoxMapper.selectList(q);
            List<Map<String, Object>> view = new ArrayList<>();
            for (MedBox b : boxes) {
                Map<String, Object> m = new HashMap<>();
                m.put("medicineName", b.getMedicineName());
                m.put("produceTime", b.getProduceTime());
                m.put("countDown", b.getCountDown());
                m.put("recycled", b.getRecycled());
                m.put("unit", b.getUnit());
                m.put("remaining", b.getRemaining());
                m.put("total", b.getTotal());
                view.add(m);
            }
            return Result.success(view, "查询成功");
        } catch (Exception e) {
            return Result.error(500, "家庭药箱读取失败：" + e.getMessage());
        }
    }

    @PostMapping("/sync")
    @Operation(summary = "成员上报药箱同步时间")
    public Result sync(@RequestBody Map<String, Object> body) {
        try {
            String code = str(body.get("familyCode"));
            String memberId = str(body.get("memberId"));
            LambdaQueryWrapper<FamilyMember> q = new LambdaQueryWrapper<>();
            q.eq(FamilyMember::getFamilyCode, code).eq(FamilyMember::getMemberId, memberId);
            FamilyMember m = familyMapper.selectOne(q);
            if (m == null) return Result.error(404, "成员不存在");
            m.setLastSync(LocalDateTime.now().format(FMT));
            familyMapper.updateById(m);
            return Result.ok();
        } catch (Exception e) {
            return Result.error(500, "同步失败：" + e.getMessage());
        }
    }

    private void addMember(String code, String memberId, Long userId, String memberName, String role) {
        FamilyMember m = new FamilyMember();
        m.setFamilyCode(code);
        m.setMemberId(memberId);
        m.setUserId(userId);
        m.setMemberName(memberName);
        m.setRole(role);
        m.setLastSync(LocalDateTime.now().format(FMT));
        familyMapper.insert(m);
    }

    private String generateCode() {
        for (int i = 0; i < 10; i++) {
            int v = 100000 + RANDOM.nextInt(900000);
            String code = String.valueOf(v);
            if (familyMapper.existsGroup(code) == null) return code;
        }
        return String.valueOf(100000 + RANDOM.nextInt(900000));
    }

    private String str(Object o) {
        return o == null ? "" : String.valueOf(o);
    }

    private Long toLong(Object o) {
        if (o == null) return null;
        if (o instanceof Number) return ((Number) o).longValue();
        try {
            return Long.parseLong(String.valueOf(o));
        } catch (Exception e) {
            return null;
        }
    }
}
