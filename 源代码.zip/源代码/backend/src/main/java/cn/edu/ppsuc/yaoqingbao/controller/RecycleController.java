package cn.edu.ppsuc.yaoqingbao.controller;

import cn.edu.ppsuc.yaoqingbao.data.po.RecycleRecord;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import cn.edu.ppsuc.yaoqingbao.mapper.RecycleRecordMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

/**
 * 线下回收核验控制器
 * 核验码由 App 端本地生成，回收点工作人员扫码核销
 */
@RestController
@RequestMapping("/recycle")
@Tag(name = "回收核验", description = "线下回收核验码生成与核销")
public class RecycleController {

    @Autowired private RecycleRecordMapper recordMapper;

    @PostMapping("/verify")
    @Operation(summary = "回收点核销核验码（由工作人员终端调用）")
    public Result verify(@RequestBody Map<String, Object> body) {
        String nonce = (String) body.get("nonce");
        String drugCategory = (String) body.get("drugCategory");
        Integer quantity = (Integer) body.get("quantity");
        String recycleType = (String) body.get("recycleType");
        Long stationId = body.get("stationId") != null
                ? Long.valueOf(body.get("stationId").toString()) : null;

        // 防重放：同一个 nonce 只能使用一次
        if (recordMapper.countByNonce(nonce) > 0) {
            return Result.error(400, "该核验码已被使用，请勿重复提交");
        }

        RecycleRecord record = new RecycleRecord();
        record.setDrugCategory(drugCategory);
        record.setQuantity(quantity != null ? quantity : 1);
        record.setRecycleType(recycleType != null ? recycleType : "disposable");
        record.setStationId(stationId);
        record.setNonce(nonce);
        record.setRecycleTime(LocalDateTime.now());

        recordMapper.insert(record);
        return Result.ok();
    }

    @GetMapping("/stats")
    @Operation(summary = "获取回收统计数据（匿名汇总）")
    public Result stats() {
        return Result.success(Map.of(
                "categoryStats", recordMapper.categoryStats(),
                "typeStats", recordMapper.typeStats()
        ), "统计成功");
    }

    @PostMapping("/nonce")
    @Operation(summary = "生成一次性核验码 nonce（供 App 调用）")
    public Result generateNonce() {
        return Result.success(Map.of("nonce", UUID.randomUUID().toString()), "核验码已生成");
    }
}
