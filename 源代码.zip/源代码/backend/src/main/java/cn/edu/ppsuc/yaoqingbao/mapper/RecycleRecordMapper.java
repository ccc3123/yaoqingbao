package cn.edu.ppsuc.yaoqingbao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cn.edu.ppsuc.yaoqingbao.data.po.RecycleRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
 * 匿名回收记录 Mapper
 */
@Mapper
public interface RecycleRecordMapper extends BaseMapper<RecycleRecord> {

    @Select("SELECT COUNT(*) FROM recycle_record WHERE nonce = #{nonce}")
    int countByNonce(String nonce);

    @Select("SELECT drug_category, COUNT(*) as cnt FROM recycle_record " +
            "GROUP BY drug_category ORDER BY cnt DESC")
    java.util.List<java.util.Map<String, Object>> categoryStats();

    @Select("SELECT recycle_type, COUNT(*) as cnt FROM recycle_record " +
            "GROUP BY recycle_type")
    java.util.List<java.util.Map<String, Object>> typeStats();
}
