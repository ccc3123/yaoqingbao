package cn.edu.ppsuc.yaoqingbao.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 手机验证码内存存储。
 *
 * 演示模式：验证码随 sendCode 响应返回（前端可自动填充），
 * 生产环境应改为接入真实短信服务（阿里云/腾讯云短信）下发，
 * 本类只负责生成、校验与过期回收，替换成本低。
 */
public class SmsCodeStore {

    private static final long TTL_MS = 5L * 60 * 1000; // 5 分钟有效

    private static final Map<String, CodeEntry> STORE = new ConcurrentHashMap<>();

    private SmsCodeStore() {
    }

    /** 生成并暂存验证码，返回 6 位数字字符串 */
    public static String generate(String phone) {
        String code = String.format("%06d", (int) (Math.random() * 1000000));
        STORE.put(phone, new CodeEntry(code, System.currentTimeMillis() + TTL_MS));
        return code;
    }

    /** 校验验证码；成功即作废（一次性），失败/过期返回 false */
    public static boolean verify(String phone, String code) {
        CodeEntry e = STORE.get(phone);
        if (e == null) return false;
        if (System.currentTimeMillis() > e.expireAt) {
            STORE.remove(phone);
            return false;
        }
        boolean ok = e.code.equals(code);
        if (ok) STORE.remove(phone);
        return ok;
    }

    private static class CodeEntry {
        final String code;
        final long expireAt;

        CodeEntry(String code, long expireAt) {
            this.code = code;
            this.expireAt = expireAt;
        }
    }
}
