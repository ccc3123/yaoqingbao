package cn.edu.ppsuc.yaoqingbao.util;

import com.alibaba.fastjson2.JSON;
import com.alibaba.fastjson2.JSONObject;
import cn.edu.ppsuc.yaoqingbao.data.po.Medicine;
import cn.edu.ppsuc.yaoqingbao.data.vo.Result;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * 阿里云聚美智数药品条码 API 工具类
 *
 * 提供三种查询方式：
 * 1. 关键词搜索药品
 * 2. 按批准文号查询药品详情
 * 3. 按条码反查药品
 */
@Component
public class MedicineSearchUtil {

    private static final Logger log = LoggerFactory.getLogger(MedicineSearchUtil.class);

    @Value("${app.medicine-api.app-code}")
    private String appCode;

    @Value("${app.medicine-api.host}")
    private String host;

    /**
     * 按关键词搜索药品
     */
    public Result search(String keyword, String type, int pageNo) {
        String path = "/tmcx/drug/query";
        Map<String, String> headers = buildAuthHeaders();
        Map<String, String> bodys = new HashMap<>();
        bodys.put("key", keyword);
        bodys.put("type", type);
        bodys.put("pageNo", String.valueOf(pageNo));

        try {
            HttpResponse response = HttpUtils.doPost(host, path, headers, null, bodys);
            if (response.getStatusLine().getStatusCode() == 200) {
                String body = EntityUtils.toString(response.getEntity());
                return new Result(200, body, "查询成功");
            }
            return new Result(400, null, "API返回非200");
        } catch (Exception e) {
            log.error("药品搜索失败: keyword={}", keyword, e);
            return new Result(500, null, "搜索服务异常: " + e.getMessage());
        }
    }

    /**
     * 按批准文号查询药品详情
     */
    public Result searchByPzwh(String pzwh) {
        String path = "/tmcx/drug/detail";
        Map<String, String> headers = buildAuthHeaders();
        Map<String, String> bodys = new HashMap<>();
        bodys.put("pzwh", pzwh);

        try {
            HttpResponse response = HttpUtils.doPost(host, path, headers, null, bodys);
            if (response.getStatusLine().getStatusCode() == 200) {
                String body = EntityUtils.toString(response.getEntity());
                return new Result(200, body, "success");
            }
            return new Result(400, null, "API返回非200");
        } catch (Exception e) {
            log.error("批准文号查询失败: pzwh={}", pzwh, e);
            return new Result(500, null, "查询服务异常: " + e.getMessage());
        }
    }

    /**
     * 按条码查询药品
     */
    public Result searchByCode(String code) {
        String path = "/brugs/barCode/query";
        Map<String, String> headers = buildAuthHeaders();
        Map<String, String> bodys = new HashMap<>();
        bodys.put("code", code);

        try {
            HttpResponse response = HttpUtils.doPost(host, path, headers, null, bodys);
            if (response.getStatusLine().getStatusCode() == 200) {
                String body = EntityUtils.toString(response.getEntity());
                return new Result(200, body, "success");
            }
            return new Result(400, null, "API返回非200");
        } catch (Exception e) {
            log.error("条码查询失败: code={}", code, e);
            return new Result(500, null, "查询服务异常: " + e.getMessage());
        }
    }

    /**
     * 构建认证请求头（AppCode 从环境变量注入）
     */
    private Map<String, String> buildAuthHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put("Authorization", "APPCODE " + appCode);
        headers.put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        return headers;
    }
}
