package cn.edu.ppsuc.yaoqingbao.data.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 统一 API 响应体
 * 全平台接口一致使用此格式返回
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result {
    /** 状态码: 200=成功, 400=客户端错误, 500=服务端错误 */
    private Integer code;
    /** 响应数据 */
    private Object data;
    /** 提示消息 */
    private String msg;

    // ============ 工厂方法 ============

    public static Result success(Object data, String msg) {
        return new Result(200, data, msg);
    }

    public static Result ok() {
        return new Result(200, null, "成功");
    }

    public static Result error(Integer code, String msg) {
        return new Result(code, null, msg);
    }

    public static Result notFound(String msg) {
        return new Result(404, null, msg);
    }
}
