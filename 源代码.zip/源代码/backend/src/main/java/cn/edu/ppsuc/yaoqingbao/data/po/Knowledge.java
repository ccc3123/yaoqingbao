package cn.edu.ppsuc.yaoqingbao.data.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 科普知识文章实体
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("knowledge")
public class Knowledge implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 文章标题 */
    private String title;

    /** 文章摘要 */
    private String summary;

    /** 正文内容（Markdown 格式） */
    private String content;

    /** 分类: policy=政策法规, guide=回收指南, science=科普知识, news=行业资讯 */
    private String category;

    /** 封面图片 URL */
    private String coverImage;

    /** 参考文献 */
    private String references;

    /** 浏览次数 */
    private Integer viewCount;

    /** 发布时间 */
    private LocalDateTime publishTime;

    /** 状态: published=已发布, draft=草稿 */
    private String status;
}
