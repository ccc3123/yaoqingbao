-- =====================================================
-- 药清宝 V2.0 公益版 数据库初始化脚本
-- 零账户 · 零交易 · 零个人信息收集
-- =====================================================

CREATE DATABASE IF NOT EXISTS medrecycle_v2
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE medrecycle_v2;

-- 1. 药品信息缓存表（从阿里云 API 自动沉淀）
CREATE TABLE IF NOT EXISTS medicine (
    id          VARCHAR(64)  PRIMARY KEY COMMENT '批准文号/条码',
    drug_name   VARCHAR(256) COMMENT '药品通用名称',
    ggxh        VARCHAR(128) COMMENT '规格型号',
    manu        VARCHAR(256) COMMENT '生产厂家',
    price       VARCHAR(32)  COMMENT '参考价格',
    blfy        TEXT         COMMENT '不良反应',
    jj          TEXT         COMMENT '禁忌',
    pzwh        VARCHAR(128) COMMENT '批准文号',
    syz         TEXT         COMMENT '适用症/功能主治',
    type        VARCHAR(64)  COMMENT '药品类型',
    xz          VARCHAR(256) COMMENT '性状',
    yfyl        TEXT         COMMENT '用法用量',
    ywxhzy      TEXT         COMMENT '药物相互作用',
    yxq         VARCHAR(64)  COMMENT '有效期',
    zc          VARCHAR(256) COMMENT '贮藏条件',
    zxbz        VARCHAR(256) COMMENT '执行标准',
    zysx        TEXT         COMMENT '注意事项',
    zzjb        VARCHAR(256) COMMENT '主治疾病',
    zycf        TEXT         COMMENT '主要成分',
    exp         INT          COMMENT '有效期天数',
    INDEX idx_pzwh (pzwh),
    INDEX idx_drug_name (drug_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='药品信息缓存';

-- 2. 回收点/合作机构表
CREATE TABLE IF NOT EXISTS station (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(256) NOT NULL COMMENT '机构名称',
    station_type    VARCHAR(32)  NOT NULL COMMENT '类型: pharmacy/hospital/community/charity',
    address         VARCHAR(512) COMMENT '详细地址',
    phone           VARCHAR(32)  COMMENT '联系电话',
    business_hours  VARCHAR(128) COMMENT '营业时间',
    latitude        DECIMAL(10,7) COMMENT '纬度',
    longitude       DECIMAL(10,7) COMMENT '经度',
    recycle_type    VARCHAR(32)  COMMENT '回收类型: reusable/disposable/both',
    accept_donation TINYINT(1) DEFAULT 0 COMMENT '是否接收捐赠',
    status          VARCHAR(16) DEFAULT 'active' COMMENT '状态: active/inactive',
    INDEX idx_type (station_type),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='回收点信息';

-- 3. 科普知识文章表
CREATE TABLE IF NOT EXISTS knowledge (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(256) NOT NULL COMMENT '文章标题',
    summary      VARCHAR(512) COMMENT '文章摘要',
    content      LONGTEXT     COMMENT '正文(Markdown)',
    category     VARCHAR(32)  COMMENT '分类: policy/guide/science/news',
    cover_image  VARCHAR(512) COMMENT '封面图URL',
    `references` TEXT         COMMENT '参考文献',
    view_count   INT DEFAULT 0 COMMENT '浏览次数',
    publish_time DATETIME     COMMENT '发布时间',
    status       VARCHAR(16) DEFAULT 'draft' COMMENT '状态: published/draft',
    INDEX idx_category (category),
    INDEX idx_status_time (status, publish_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='科普知识库';

-- 4. 匿名回收记录表（仅品类+数量+回收点，无个人信息）
CREATE TABLE IF NOT EXISTS recycle_record (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    drug_category VARCHAR(128) COMMENT '药品品类',
    quantity      INT COMMENT '数量',
    recycle_type  VARCHAR(32)  COMMENT '回收类型: reusable/disposable',
    station_id    BIGINT       COMMENT '回收点ID',
    nonce         VARCHAR(64)  NOT NULL COMMENT '一次性核验码',
    recycle_time  DATETIME     COMMENT '回收时间',
    UNIQUE INDEX idx_nonce (nonce),
    INDEX idx_station (station_id),
    INDEX idx_time (recycle_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='匿名回收记录';

-- =====================================================
-- 插入示例数据
-- =====================================================

-- 示例回收点
INSERT INTO station (name, station_type, address, phone, business_hours, latitude, longitude, recycle_type, accept_donation, status) VALUES
('同仁堂药店(木樨地店)', 'pharmacy', '北京市西城区木樨地北里甲1号', '010-63261155', '08:00-21:00', 39.9042, 116.3374, 'both', TRUE, 'active'),
('金象大药房(月坛店)', 'pharmacy', '北京市西城区月坛南街32号', '010-68527733', '08:30-21:30', 39.9120, 116.3415, 'both', TRUE, 'active'),
('西城区月坛社区卫生服务中心', 'community', '北京市西城区月坛街道真武庙四条', '010-68015566', '08:00-17:00', 39.9080, 116.3440, 'disposable', FALSE, 'active'),
('北京大学人民医院药房', 'hospital', '北京市西城区西直门南大街11号', '010-88326666', '08:00-17:00', 39.9330, 116.3550, 'disposable', FALSE, 'active'),
('北京市红十字基金会', 'charity', '北京市西城区广安门南街68号', '010-83539996', '09:00-17:00', 39.8920, 116.3530, 'reusable', TRUE, 'active'),
('国大药房(复兴路店)', 'pharmacy', '北京市海淀区复兴路甲49号', '010-68157722', '08:00-22:00', 39.9075, 116.3224, 'both', TRUE, 'active');

-- 示例科普文章
INSERT INTO knowledge (title, summary, content, category, cover_image, `references`, view_count, publish_time, status) VALUES
(
    '家庭过期药品的正确处理方式',
    '过期药品属于危险废物，不可随意丢弃。本文介绍科学的家庭药品处置方法。',
    '## 为什么过期药品不能随意丢弃？\n\n过期药品被列入《国家危险废物名录（2021年版）》。随意丢弃可能导致：\n\n1. **环境污染**：药品化学成分渗入土壤和水源\n2. **误食风险**：儿童或宠物误食可能导致中毒\n3. **非法回收**：被不法分子回收后流入黑市\n\n## 正确的处理步骤\n\n1. 将过期药品从原包装中取出\n2. 与废弃杂物混合（如茶叶渣、咖啡渣）\n3. 放入密封袋中\n4. 投递至正规药品回收点\n\n## 更推荐的做法\n\n通过"药清宝"App查找附近的药品回收点，将过期药品交由专业机构进行无害化处理。',
    'guide', NULL, '《国家危险废物名录（2021年版）》、《药品管理法》', 0, NOW(), 'published'
),
(
    '国家药品回收政策解读（2021-2025）',
    '梳理近年来国家层面出台的药品回收相关政策法规。',
    '## 政策背景\n\n### 《"十四五"循环经济发展规划》（2021）\n提出完善废旧物资回收网络，积极推行"互联网+回收"模式。\n\n### 《关于加快构建废弃物循环利用体系的意见》（2024）\n国务院办公厅发布，提出到2025年初步建成覆盖各领域的废弃物循环利用体系。\n\n### 《"互联网+"绿色生态三年行动实施方案》\n强调利用互联网、大数据、物联网等技术优化逆向物流布局。\n\n## 政策导向\n\n- 鼓励"互联网+回收"模式创新\n- 推动线上线下协同回收\n- 强化生产者责任延伸制度\n- 提升公众参与意识',
    'policy', NULL, '国务院相关政策文件', 0, NOW(), 'published'
),
(
    '哪些药品可以捐赠再利用？',
    '并非所有药品都适合捐赠。了解可捐赠药品的条件和流程。',
    '## 可捐赠药品的条件\n\n✅ **可以捐赠**：\n- 未开封、包装完好的非处方药\n- 有效期在6个月以上\n- 常温保存的药品\n- 片剂、胶囊等固体剂型\n\n❌ **不可捐赠**：\n- 已过期的药品\n- 处方药（需医生指导使用）\n- 需要冷藏的药品\n- 液体剂型（已开封）\n- 麻醉药品和精神药品\n\n## 捐赠流程\n\n1. 在App中扫描药品条码，确认药品信息\n2. 查看附近接收捐赠的合作机构\n3. 携带药品前往机构现场登记\n4. 机构工作人员核验药品后完成接收\n\n> ⚠️ 根据《药品管理法》，个人不得私下转让药品。请通过正规慈善机构进行捐赠。',
    'guide', NULL, '《药品管理法》、《慈善法》', 0, NOW(), 'published'
);
