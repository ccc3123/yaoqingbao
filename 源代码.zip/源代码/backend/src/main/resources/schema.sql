-- 药清宝V2 公益版 数据库建表脚本
-- Database: medrecycle_v2
-- MySQL 8.0+

CREATE DATABASE IF NOT EXISTS medrecycle_v2
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE medrecycle_v2;

-- 1. 药品信息表
CREATE TABLE IF NOT EXISTS medicine (
    id          VARCHAR(64)  PRIMARY KEY COMMENT '药品唯一标识（批准文号/条码）',
    drug_name   VARCHAR(256) DEFAULT '' COMMENT '药品通用名称',
    ggxh        VARCHAR(128) DEFAULT '' COMMENT '规格型号',
    manu        VARCHAR(256) DEFAULT '' COMMENT '生产厂家',
    price       VARCHAR(32)  DEFAULT '' COMMENT '参考价格',
    blfy        TEXT         COMMENT '不良反应',
    jj          TEXT         COMMENT '禁忌',
    pzwh        VARCHAR(64)  DEFAULT '' COMMENT '批准文号',
    syz         TEXT         COMMENT '功能主治',
    type        VARCHAR(64)  DEFAULT '' COMMENT '药品类型（处方药/非处方药/中成药）',
    xz          VARCHAR(256) DEFAULT '' COMMENT '性状',
    yfyl        TEXT         COMMENT '用法用量',
    ywxhzy      TEXT         COMMENT '药物相互作用',
    yxq         VARCHAR(64)  DEFAULT '' COMMENT '有效期描述（如24个月）',
    zc          VARCHAR(256) DEFAULT '' COMMENT '贮藏条件',
    zxbz        VARCHAR(128) DEFAULT '' COMMENT '执行标准',
    zysx        TEXT         COMMENT '注意事项',
    zzjb        VARCHAR(256) DEFAULT '' COMMENT '主治疾病',
    zycf        TEXT         COMMENT '主要成分',
    exp         INT          DEFAULT 0 COMMENT '有效期天数（解析后）',
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '入库时间',
    updated_at  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_pzwh (pzwh),
    INDEX idx_drug_name (drug_name),
    INDEX idx_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='药品信息';

-- 2. 回收点/药店表
CREATE TABLE IF NOT EXISTS station (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    name            VARCHAR(256) NOT NULL COMMENT '机构名称',
    station_type    VARCHAR(32)  DEFAULT 'pharmacy' COMMENT '类型: pharmacy=药店, hospital=医院, community=社区, charity=慈善',
    address         VARCHAR(512) DEFAULT '' COMMENT '详细地址',
    phone           VARCHAR(32)  DEFAULT '' COMMENT '联系电话',
    business_hours  VARCHAR(128) DEFAULT '' COMMENT '营业时间',
    latitude        DECIMAL(10,7) DEFAULT 0.0 COMMENT '纬度',
    longitude       DECIMAL(10,7) DEFAULT 0.0 COMMENT '经度',
    recycle_type    VARCHAR(32)  DEFAULT 'both' COMMENT '回收类型: reusable=可再利用, disposable=待销毁, both=均可',
    accept_donation TINYINT(1)   DEFAULT 0 COMMENT '是否接收捐赠',
    status          VARCHAR(16)  DEFAULT 'active' COMMENT '状态: active=运营中, inactive=已停用',
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_type (station_type),
    INDEX idx_location (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='回收点';

-- 3. 匿名回收记录表
CREATE TABLE IF NOT EXISTS recycle_record (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    drug_category   VARCHAR(128) DEFAULT '' COMMENT '药品品类',
    quantity        INT          DEFAULT 1 COMMENT '回收数量',
    recycle_type    VARCHAR(32)  DEFAULT 'disposable' COMMENT '回收类型: reusable=可再利用, disposable=待销毁',
    station_id      BIGINT       DEFAULT 0 COMMENT '回收点ID',
    nonce           VARCHAR(64)  NOT NULL COMMENT '一次性核验码（防重放）',
    recycle_time    DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '回收时间',
    UNIQUE INDEX uk_nonce (nonce),
    INDEX idx_recycle_time (recycle_time),
    INDEX idx_station (station_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='匿名回收记录';

-- 4. 科普知识表
CREATE TABLE IF NOT EXISTS knowledge (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(256) NOT NULL COMMENT '文章标题',
    summary         VARCHAR(512) DEFAULT '' COMMENT '文章摘要',
    content         MEDIUMTEXT   COMMENT '正文（Markdown）',
    category        VARCHAR(32)  DEFAULT 'guide' COMMENT '分类: policy=政策法规, guide=回收指南, science=科普知识, news=行业资讯',
    cover_image     VARCHAR(512) DEFAULT '' COMMENT '封面图片URL',
    `references`    TEXT         COMMENT '参考文献',
    view_count      INT          DEFAULT 0 COMMENT '浏览次数',
    publish_time    DATETIME     DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    status          VARCHAR(16)  DEFAULT 'published' COMMENT '状态: published=已发布, draft=草稿',
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_publish_time (publish_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='科普知识';

-- 5. 插入示例数据

-- 示例回收点
INSERT INTO station (name, station_type, address, phone, business_hours, latitude, longitude, recycle_type, accept_donation, status) VALUES
('北京同仁堂药店（前门店）', 'pharmacy', '北京市东城区前门大街42号', '010-63031155', '08:30-20:30', 39.8986, 116.4031, 'both', 1, 'active'),
('上海第一医药商店', 'pharmacy', '上海市黄浦区南京东路616号', '021-63221888', '09:00-21:00', 31.2372, 121.4811, 'both', 1, 'active'),
('广州市越秀区社区卫生服务中心', 'community', '广州市越秀区惠福东路543号', '020-83322178', '08:00-17:30', 23.1201, 113.2707, 'disposable', 0, 'active'),
('深圳市人民医院药房', 'hospital', '深圳市罗湖区东门北路1017号', '0755-25609999', '24小时', 22.5471, 114.1286, 'both', 1, 'active'),
('成都市武侯区慈善药品回收站', 'charity', '成都市武侯区一环路南四段10号', '028-85321122', '09:00-18:00', 30.6378, 104.0433, 'both', 1, 'active'),
('杭州市食品药品检验研究院', 'hospital', '杭州市拱墅区莫干山路188号', '0571-86461234', '08:30-17:00', 30.2820, 120.1536, 'disposable', 0, 'active'),
('武汉市汉阳区药品回收示范点', 'community', '武汉市汉阳区鹦鹉大道88号', '027-84621357', '08:00-17:30', 30.5420, 114.2625, 'both', 1, 'active');

-- 示例科普文章
INSERT INTO knowledge (title, summary, content, category, cover_image, `references`, view_count, publish_time, status) VALUES
('家庭过期药品的正确处理方式', '过期药品属于危险废物，不可随意丢弃。本文详细介绍正确处理流程。', '# 家庭过期药品的正确处理方式\n\n## 为什么不能随意丢弃？\n\n过期药品被列入《国家危险废物名录》（2021年版）\n\n- 随意丢弃会污染土壤和地下水\n- 一粒过期抗生素可污染30,000升水资源\n- 冲入下水道会导致抗生素耐药性\n\n## 正确处理方法\n\n1. **分类收集**：将过期药品从原包装中取出\n2. **密封包装**：使用密封袋或容器包装\n3. **标注信息**：标注"过期药品"字样\n4. **送至回收点**：送至社区药品回收点或定点药店\n5. **记录回收**：通过"药清宝"App记录回收信息\n\n## 特别提醒\n\n- 麻醉/精神类药品须交药品监督管理部门\n- 注射剂/眼用制剂需专业机构处理\n- 中成药和OTC药品可直接回收', 'guide', '', '《国家危险废物名录》（2021年版）、《药品管理法》', 1280, '2026-06-20', 'published'),
('国家药品回收政策解读', '梳理近年来国家层面出台的药品回收相关政策法规。', '# 国家药品回收政策解读\n\n## 政策背景\n\n近年来，我国不断加强对过期药品回收的管理力度...', 'policy', '', '《药品管理法》修订版', 960, '2026-06-18', 'published'),
('过期药品对环境的危害有多大？', '一粒过期药品可能污染数十吨水源，对环境造成不可逆的破坏。', '# 过期药品的环境危害\n\n## 水体污染\n\n过期药品进入水环境后...', 'science', '', 'WHO Guidelines for Safe Disposal of Medicines', 720, '2026-06-10', 'published'),
('带您了解药品回收全流程', '从家庭投递到无害化处理，一文看懂药品回收的完整链条。', '# 药品回收全流程\n\n## 第一步：家庭分类\n## 第二步：回收点收集\n## 第三步：专业运输\n## 第四步：分类处理\n## 第五步：无害化销毁', 'guide', '', '', 1540, '2026-06-15', 'published');

-- 6. 家庭药箱条目表（待回收药品记录，支持单条/批量删除与服务端同步）
-- V3：新增家庭共享（family_code）与科学计量（total/unit/remaining）
CREATE TABLE IF NOT EXISTS med_box (
    box_id        VARCHAR(64)  PRIMARY KEY COMMENT '药箱条目ID（客户端生成）',
    device_id     VARCHAR(64)  DEFAULT '' COMMENT '设备/成员标识（匿名）',
    family_code   VARCHAR(16)  DEFAULT '' COMMENT '家庭码（非空=家庭共享药箱）',
    medicine_name VARCHAR(256) DEFAULT '' COMMENT '药品名称',
    produce_time  VARCHAR(32)  DEFAULT '' COMMENT '生产日期',
    add_time      VARCHAR(32)  DEFAULT '' COMMENT '录入日期',
    exp_days      INT          DEFAULT 0 COMMENT '有效期天数',
    count_down    INT          DEFAULT 0 COMMENT '剩余天数（<=0 已过期）',
    recycled      TINYINT(1)   DEFAULT 0 COMMENT '是否已投递回收点',
    source        VARCHAR(16)  DEFAULT 'local' COMMENT '来源: local=手动, scan=扫码',
    total         DECIMAL(10,2) DEFAULT 0 COMMENT '总量（按单位计量）',
    unit          VARCHAR(16)  DEFAULT '' COMMENT '计量单位: 片/颗/粒/瓶/袋/支/包/盒/mg/ml/g',
    remaining     DECIMAL(10,2) DEFAULT 0 COMMENT '剩余量（服药后递减）',
    updated_at    DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX idx_device (device_id),
    INDEX idx_family (family_code),
    INDEX idx_countdown (count_down)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='家庭药箱条目';

-- 8. 用户表（账号体系：手机号验证码登录，混合双入口）
CREATE TABLE IF NOT EXISTS `user` (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    phone       VARCHAR(20)  NOT NULL COMMENT '手机号（唯一）',
    nickname    VARCHAR(64)  DEFAULT '' COMMENT '昵称',
    created_at  DATETIME     DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户';

-- 9. 服药记录表（家庭共享，记录谁在什么时候服用了多少药）
CREATE TABLE IF NOT EXISTS med_record (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    family_code   VARCHAR(16)  DEFAULT '' COMMENT '家庭码（非空=家庭共享记录）',
    device_id     VARCHAR(64)  DEFAULT '' COMMENT '记录人设备/成员标识',
    member_name   VARCHAR(64)  DEFAULT '' COMMENT '记录人称谓',
    medicine_id   VARCHAR(64)  DEFAULT '' COMMENT '药箱条目ID',
    medicine_name VARCHAR(256) DEFAULT '' COMMENT '药品名称',
    dose          DECIMAL(10,2) DEFAULT 0 COMMENT '本次服用剂量',
    unit          VARCHAR(16)  DEFAULT '' COMMENT '单位',
    taken_at      VARCHAR(32)  DEFAULT '' COMMENT '服药时间 yyyy-MM-dd HH:mm',
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_family (family_code),
    INDEX idx_device (device_id),
    INDEX idx_medicine (medicine_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服药记录';

-- 10. 服药计划表（家庭共享，闹钟写入各成员系统日历）
CREATE TABLE IF NOT EXISTS med_plan (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    family_code   VARCHAR(16)  DEFAULT '' COMMENT '家庭码（非空=家庭共享计划）',
    device_id     VARCHAR(64)  DEFAULT '' COMMENT '创建者设备标识',
    medicine_name VARCHAR(256) DEFAULT '' COMMENT '药品名称',
    dosage        VARCHAR(64)  DEFAULT '' COMMENT '剂量说明，如 1片/10ml',
    times         VARCHAR(256) DEFAULT '' COMMENT '每日服药时间，逗号分隔 HH:mm',
    start_date    VARCHAR(32)  DEFAULT '' COMMENT '开始日期 yyyy-MM-dd',
    end_date      VARCHAR(32)  DEFAULT '' COMMENT '结束日期（空=长期）',
    enabled       TINYINT(1)   DEFAULT 1 COMMENT '是否启用',
    created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_family (family_code),
    INDEX idx_device (device_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服药计划';

-- 7. 家庭协同（子女远程看父母药箱，纯软件实现"网联"）
CREATE TABLE IF NOT EXISTS family_group (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    family_code VARCHAR(16) NOT NULL COMMENT '6位家庭码',
    name        VARCHAR(64) DEFAULT '' COMMENT '家庭名称',
    created_at  DATETIME    DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_code (family_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='家庭';

CREATE TABLE IF NOT EXISTS family_member (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    family_code VARCHAR(16) NOT NULL COMMENT '家庭码',
    member_id   VARCHAR(64) NOT NULL COMMENT '成员设备标识（匿名）/账号用户ID',
    user_id     BIGINT       DEFAULT NULL COMMENT '关联账号用户ID（账号成员非空）',
    member_name VARCHAR(64) DEFAULT '' COMMENT '备注称谓，如：妈妈',
    role        VARCHAR(16) DEFAULT 'member' COMMENT 'owner=创建者, member=成员',
    last_sync   VARCHAR(32) DEFAULT '' COMMENT '最近同步时间',
    joined_at   DATETIME    DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_family_member (family_code, member_id),
    INDEX idx_code (family_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='家庭成员';
